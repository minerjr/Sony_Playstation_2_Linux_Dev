#include "dma.h"

Dma_Packet::Dma_Packet()
{
	Init();
}

Dma_Packet::Dma_Packet(Dma_Memory_Engine *tmpDmaMemoryEngine)
{
	DmaMemoryEngine = tmpDmaMemoryEngine;
	Init(1);
}

Dma_Packet::Dma_Packet(Dma_Memory_Engine *tmpDmaMemoryEngine, int numberOfPages)
{
	DmaMemoryEngine = tmpDmaMemoryEngine;
	Init(numberOfPages);
}

Dma_Packet::~Dma_Packet()
{

}

int Dma_Packet::Init()
{
	iQWC = 0;
	
	packetMemory = DmaMemoryEngine->getFree4KPage();//Allocate one memory page
	pCurrent = (uint128 *)currentPage->getpPageMemory();//Used for stepping through the memory

	// Get the physical address of our data
	madr.i32 = 0;
	madr.s.ADDR = currentPage->getPhysicalAddress();

	// chcr is used to control (start, stop) DMAC transfers.
	// Since we need the same chcr value each time we initialize it once.
	chcr.i32=0;                  	// Blank everything out
	chcr.s.MOD=CHCR_MOD_CHAIN;  	// We'll do a source chain dma transfer
	chcr.s.STR=1;                	// STR=1 = start transf

	pDMATag = (sps2DMATag_t *)currentPage->getpPageMemory();
	pDMATag->i64 = 0;
	pDMATag->s.ID = DMA_ID_SOURCE_CNT;

	stitch();
	pCurrent++;

	return 1;
}

int Dma_Packet::Init(int numberOfPages)
{
	packetMemory = DmaMemoryEngine->getFree4KPage(numberOfPages);

	if (packetMemory == NULL)return 0;

	currentPage = packetMemory;	
	pCurrent = (uint128 *)currentPage->getpPageMemory();	
	iQWC = 0;

	// Get the physical address of our data
	madr.i32 = 0;
	madr.s.ADDR = currentPage->getPhysicalAddress();

	// chcr is used to control (start, stop) DMAC transfers.
	// Since we need the same chcr value each time we initialize it once.
	chcr.i32=0;                  	// Blank everything out
	chcr.s.MOD=CHCR_MOD_CHAIN;  	// We'll do a source chain dma transfer
	chcr.s.STR=1;                	// STR=1 = start transfer

	pDMATag = (sps2DMATag_t *)currentPage->getpPageMemory();
	pDMATag->i64 = 0;
	pDMATag->s.ID = DMA_ID_SOURCE_CNT;

	//Inialize the stitching function first
	stitch();
	pCurrent++;

	return 1;
}

int Dma_Packet::transfer()
{
    	*EE_D2_QWC = 0;

    	// Set the physical address of our data to the tag address register
   	*EE_D2_TADR = madr.i32;

    	// Start the DMA transfer
    	*EE_D2_CHCR = chcr.i32;

	sps2WaitForDMA(2, DmaMemoryEngine->getSPS2Descriptor());

	return 1;
}

int Dma_Packet::finish()
{
	pDMATag->s.QWC = iQWC;

	pDMATag = (sps2DMATag_t *)pCurrent;
	pDMATag->i64 = 0;
	pDMATag->s.QWC = 0;
	pDMATag->s.ID = DMA_ID_SOURCE_END;

	return 1;
}



// Call this function once EVERYTIME (very important) before you write
// 1 quad word to the DMA chain
int Dma_Packet::stitch()
{
	// Do the if statement only when the pointer points to the last qword of a 4k page
	if((((int)pCurrent) & 0xFFF) == 0xFF0)
	{
		pDMATag->s.QWC = iQWC;			//set QWC of the DMA tag at the start of the page
		iQWC = 1;						//reset iQWC to zero
										//we know we are about to write one qword

		//now write the dmatag next tag at the end of the page
		pDMATag = (sps2DMATag_t *)pCurrent;		//point to the end of the page
		pDMATag->i64 = 0;					//zero the tag
		pDMATag->s.QWC = 0;					//set the QWC to zero (no data will be sent)
		pDMATag->s.ID = DMA_ID_SOURCE_NEXT;	//this is a next tag
		
		//ADDR points to the location of the next tag 
		//which is a qword ahead, just over the 4k boundary
		
		if (currentPage->getNext() == NULL)
		{
			currentPage->setNext(DmaMemoryEngine->getFree4KPage());
		}
		currentPage = currentPage->getNext();

		pDMATag->s.ADDR = currentPage->getPhysicalAddress(0x10);
		pCurrent = (uint128 *)currentPage->getpPageMemory();

		//pDMATag->s.ADDR = sps2GetPhysicalAddress((void *)(((int)pCurrent) + 0x10), pMemory);

		//now point to the tag at the start of the next page
		++pDMATag;
		pDMATag->i64 = 0;					//clear it
		pDMATag->s.QWC = 0;					//set its QWC to zero
		pDMATag->s.ID = DMA_ID_SOURCE_CNT;	//set the type

		//return 2 to say we have written 2 128bit tags
		//this is used to move the memory pointer on by 2
		pCurrent += 2;
		return 2;
	}
	
	//increment the global qword count
	iQWC++;
	
	//return 0 so - we don't want to increment the memory pointer
	return 0;
}


int Dma_Packet::add2Qword(uint128 tmp2Qword)
{
	stitch();//Stitch the memory together
	*pCurrent = tmp2Qword;//Copy the data into the 
	pCurrent++;//Increase the pointer to the next location
	return 1;
}

int Dma_Packet::add2Qword(uint128 *tmp2Qword, int count)
{
	for (int x = 0; x < count; x++)
	{
		stitch();//Stitch the memory together
		*pCurrent = *tmp2Qword;//Copy the data into the 
		pCurrent++;//Increase the pointer to the next location
		tmp2Qword++;

	}
	return 1;
}


uint128 *Dma_Packet::getCurrent()
{
	return pCurrent;

}
