#include <stdio.h>
#include "dma.h"
#include "addregisters.h"

int main()
{

	int ScreenW, ScreenH;				//width and height of screen
	int posx, posy;

	Dma_Memory_Engine *DmaMemoryEngine;
	Dma_Packet *testPacket;

	sps2GIFTag_t GifTag;
	sps2GIFTag_t *pGifTag;

	sps2GIFPackedRegister_t Register;
	sps2GIFPackedRegister_t *pRegister;


 	ScreenW = sps2UScreenGetWidth();
	ScreenH = sps2UScreenGetHeight();

	printf("\nPS2 engine - test program\n");
	
	printf("Create Memory Engine: ");
	DmaMemoryEngine = new Dma_Memory_Engine(3072);
	printf("done\n");

	printf("Create Dma Packet: ");
	testPacket = new Dma_Packet(DmaMemoryEngine);
	printf("done\n");

	printf("Inilising the screen: ");
	sps2UScreenInit(0);
	printf("done\n");

	GifTag = AddGifTag(3, 1, 1, 11, GIF_FLG_PACKED, 0);
	
	SPS2_SET_GIF_REG(pGifTag, pGifTag->s.NREG++, GIF_REG_RGBAQ);
	// Add the XYZ2 register to the giftag. 
	SPS2_SET_GIF_REG(pGifTag, pGifTag->s.NREG++, GIF_REG_XYZ2);

	testPacket->add2Qword((uint128)GifTag.i128);

	Register = AddColor(0,128,0,0x80);
	
	testPacket->add2Qword((uint128)Register);


	posx = rand()%ScreenW - (ScreenW/2);
	posy = rand()%ScreenH - (ScreenH/2);

	Register = AddVertex( (2048 + posx - 40) << 4, (2048 + posy - 40) << 4, 128,0);
	
	testPacket->add2Qword((uint128)Register.128);

	Register = AddColor(0,128,0,0x80);
	
	testPacket->add2Qword((uint128)Register.i128);


	posx = rand()%ScreenW - (ScreenW/2);
	posy = rand()%ScreenH - (ScreenH/2);

	Register = AddVertex( (2048 + posx - 40) << 4, (2048 + posy - 40) << 4, 128,0);
	
	testPacket->add2Qword((uint128)Register.i128);


	Register = AddColor(0,128,0,0x80);
	
	testPacket->add2Qword((uint128)Register.i128);


	posx = rand()%ScreenW - (ScreenW/2);
	posy = rand()%ScreenH - (ScreenH/2);

	Register = AddVertex( (2048 + posx - 40) << 4, (2048 + posy - 40) << 4, 128,0);
	
	testPacket->add2Qword((uint128)Register.i128);

	testPacket->finish();

	do
	{
	sps2UScreenClear(0x10, 0, 0x20);

	testPacket->transfer();

	sps2UScreenSwap();

	}while(1);

	sps2UScreenShutdown();

	printf("Deleting Dma Packet: ");
	delete testPacket;
	printf("done\n");


	printf("Deleting Memory Engine: ");
	delete DmaMemoryEngine;
	printf("done\n");

	return 0;

}
