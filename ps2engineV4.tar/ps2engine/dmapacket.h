#include "sps2inc.h"
#include "dmamemory.h"
#include "globals.h"
#include "dma4kpage.h"
#include "structs.h"

#ifndef DMAPACKET_H
#define DMAPACKET_H

/*
/Class Dma_Packet
/This class is used all dma packets. Used for schedaling of packets and also
/for storing of the packets.
*/

class Dma_Packet
{
private:
	int IDNumber;//Packet ID number given when a new packet is created
	int IsInUse;

	int channelNumber;

	sps2DMATag_t *pDMATag;//Link to the dma tag
	Dn_CHCR_t	chcr;// Channel control register used to control the DMA transfer
	Dn_MADR_t	madr;//Address of the first packet's psycial address
	int iQWC;	//Number of qwords

	Dma_4KPage *packetMemory;
	Dma_4KPage *currentPage;

	uint128 *pCurrent;//Used for stepping through the 
	
	int stitch();

	int Init(int numberOfPages);


public:
	Dma_Packet();
	
	Dma_Packet(int numberOfPages, int tmpchannelNumber);
	~Dma_Packet();
	
	int finish();

	int transfer();

	//int addQword(u_long64 tmpQword);
	int add2Qword(uint128 tmp2Qword);

	//int addQword(u_long64 *tmpQword, int count);
	int add2Qword(uint128 *tmp2Qword, int count);

	int setChannel(int tmpchannelNumber);

	uint128 *getCurrent();
	void dump();
};

#endif
