#include <stdio.h>
#include "dmapacket.h"
#include "dmamemory.h"
#include "addregisters.h"
extern "C" {
#include "joypadlib.h"
}

Dma_Memory_Engine *DmaMemoryEngine;

int main()
{
	bool done = false;
	int active_joypad = 0;
	int buttons;
	float button_pressure[PS2PAD_NUM_PRESSURE_BUTTONS];
	float joysticks1[ 2 ][ 2 ];
	float joysticks2[ 2 ][ 2 ];
	int x,y;
	int posx, posy;

	Dma_Packet *testPacket;
	Dma_Packet *testPacket1;
	Dma_Packet *testPacket2;
	Dma_Packet *testPacket3;

	sps2GIFTag_t GifTag;

	sps2GIFPackedRegister_t Register;


	joypadlib_initialize();

	printf("\nPS2 engine - test program\n");
	
	printf("Create Memory Engine: ");
	DmaMemoryEngine = new Dma_Memory_Engine(3072);
	printf("done\n");

	printf("Create Dma Packet: ");
	testPacket1 = new Dma_Packet(1,2);
	testPacket2 = new Dma_Packet(1,2);
	testPacket3 = new Dma_Packet(1,2);
	


	printf("done\n");

	printf("Inilising the screen: ");


	printf("done\n");

	for (y = 0; y < 3; y++)
	{

	if (y == 0)testPacket = testPacket1;
	if (y == 1)testPacket = testPacket2;
	if (y == 2)testPacket = testPacket3;
	//Draw 200 triangles per screen;
	GifTag = AddGifTag(3 * 8000, 1, 1, 11, GIF_FLG_PACKED, 0);
	
	SPS2_SET_GIF_REG(GifTag, GifTag.s.NREG++, GIF_REG_RGBAQ);
	// Add the XYZ2 register to the giftag. 
	SPS2_SET_GIF_REG(GifTag, GifTag.s.NREG++, GIF_REG_XYZ2);

	testPacket->add2Qword((uint128)GifTag.i128);

	for (x = 0; x < 8000; x++)
	{
		Register = AddColour(0,0,255,0x80);
	
		testPacket->add2Qword((uint128)Register.i128);

		posx = -320 + (rand() % 640);
		posy = -240 + (rand() % 480);
		/*
		printf("Enter the first Vertex: X ");
		scanf("%d",&posx);
		printf("Enter the first Vertex: Y ");
		scanf("%d",&posy);
		*/

		
		Register = AddVertex( posx, posy, 102,0);
	
		testPacket->add2Qword((uint128)Register.i128);

		Register = AddColour(255,0,0,0xff);
	
		testPacket->add2Qword((uint128)Register.i128);


		posx = -320 + (rand() % 640);
		posy = -240 + (rand() % 480);
		/*
		printf("Enter the second Vertex: X: ");
		scanf("%d",&posx);
		printf("Enter the second Vertex: Y: ");
		scanf("%d",&posy);
		*/
		Register = AddVertex( posx, posy, 102,0);
	
		testPacket->add2Qword((uint128)Register.i128);


		Register = AddColour(0,255,0,0x80);
	
		testPacket->add2Qword((uint128)Register.i128);


		posx = -320 + (rand() % 640);
		posy = -240 + (rand() % 480);

		/*
		printf("Enter the third Vertex: X: ");
		scanf("%d",&posx);
		printf("Enter the third Vertex: Y: ");
		scanf("%d",&posy);
		*/
		Register = AddVertex( posx, posy, 102,0);
	
		testPacket->add2Qword((uint128)Register.i128);

	}

	testPacket->finish();

	}
	printf("Drawing Started\n");


	sps2UScreenInit(0);
	y = 0;
	while(!done)
	{

		joypadlib_update();
		buttons = joypadlib_get_joypad_buttons( active_joypad, button_pressure, PRESSURE_TYPE_FLOAT );
		if( button_pressure[ PS2PAD_PRESSURE_TRIANGLE ] > 0.0f )
			done = true;
		else if( button_pressure[ PS2PAD_PRESSURE_SQUARE ] > 0.0f )
			printf("Square Pressed\n");
		else if( button_pressure[ PS2PAD_PRESSURE_CIRCLE ] > 0.0f )
		{

			if (y == 0)testPacket = testPacket1;
			if (y == 1)testPacket = testPacket2;
			if (y == 2)testPacket = testPacket3;
			y++;
			if (y >= 3) y = 0;

		}

		sps2UScreenClear(0x10, 0, 0x20);

		//testPacket2->transfer();
		//testPacket1->transfer();
		//testPacket3->transfer();
		testPacket->transfer();

		sps2UScreenSwap();

	}

	
	joypadlib_shutdown();

	//testPacket->dump();	
	printf("Drawing Finished\n");

	sps2UScreenShutdown();

	printf("Deleting Dma Packet: ");
	delete testPacket;
	printf("done\n");


	printf("Deleting Memory Engine: ");
	delete DmaMemoryEngine;
	printf("done\n");

	return 0;

}

