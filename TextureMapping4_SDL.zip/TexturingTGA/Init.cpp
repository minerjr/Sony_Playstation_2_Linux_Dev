//***********************************************************************//
//                                                                       //
//      - "Talk to me like I'm a 3 year old!" Programming Lessons -      //
//                                                                       //
//      $Author:        DigiBen     digiben@gametutorials.com            //
//                                                                       //
//      $Program:       TexturingIV                                      //
//                                                                       //
//      $Description:   Texture maps a QUAD with a TGA image             //
//                                                                       //
//      $Date:          4/24/02                                          //
//                                                                       //
//***********************************************************************//

#include "main.h"                                       // includes our function protoypes and globals                        

int VideoFlags = 0;                                     // Video Flags for the Create Window function
SDL_Surface * MainWindow = NULL;                        // drawing surface on the SDL window

typedef unsigned char  byte;
typedef unsigned short WORD;
typedef unsigned int   UINT;

/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *


///////////////////////////////// LOAD TGA \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////   This loads the TGA file and returns it's data in a tImageTGA struct
/////
///////////////////////////////// LOAD TGA \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

tImageTGA *LoadTGA(const char *filename)
{
    tImageTGA *pImageData = NULL;       // This stores our important image data
    int width = 0, height = 0;          // The dimensions of the image
    byte length = 0;                    // The length in bytes to the pixels
    byte imageType = 0;                 // The image type (RLE, RGB, Alpha...)
    byte bits = 0;                      // The bits per pixel for the image (16, 24, 32)
    FILE *pFile = NULL;                 // The file pointer
    int channels = 0;                   // The channels of the image (3 = RGA : 4 = RGBA)
    int stride = 0;                     // The stride (channels * width)
    int i = 0;                          // A counter
        
    // This function loads in a TARGA (.TGA) file and returns its data to be
    // used as a texture or what have you.  This currently loads in a 16, 24
    // and 32-bit targa file, along with RLE compressed files.  Eventually you
    // will want to do more error checking to make it more robust.  This is
    // also a perfect start to go into a modular class for an engine.
    // Basically, how it works is, you read in the header information, then
    // move your file pointer to the pixel data.  Before reading in the pixel
    // data, we check to see the if it's an RLE compressed image.  This is because
    // we will handle it different.  If it isn't compressed, then we need another
    // check to see if we need to convert it from 16-bit to 24 bit.  24-bit and
    // 32-bit textures are very similar, so there's no need to do anything special.
    // We do, however, read in an extra bit for each color.

    // Open a file pointer to the targa file and check if it was found and opened 
    if((pFile = fopen(filename, "rb")) == NULL) 
    {
        cout << "Could not open the tga file : " << filename << endl;
        return NULL;
    }
        
    // Allocate the structure that will hold our eventual image data (must free it!)
    pImageData = (tImageTGA*)malloc(sizeof(tImageTGA));

    // Read in the length in bytes from the header to the pixel data
    fread(&length, sizeof(byte), 1, pFile);
    
    // Jump over one byte
    fseek(pFile,1,SEEK_CUR); 

    // Read in the imageType (RLE, RGB, etc...)
    fread(&imageType, sizeof(byte), 1, pFile);
    
    // Skip past general information we don't care about
    fseek(pFile, 9, SEEK_CUR); 

    // Read the width, height and bits per pixel (16, 24 or 32)
    fread(&width,  sizeof(WORD), 1, pFile);
    fread(&height, sizeof(WORD), 1, pFile);
    fread(&bits,   sizeof(byte), 1, pFile);
    
    // Now we move the file pointer to the pixel data
    fseek(pFile, length + 1, SEEK_CUR); 

    // Check if the image is RLE compressed or not
    if(imageType != TGA_RLE)
    {
        // Check if the image is a 24 or 32-bit image
        if(bits == 24 || bits == 32)
        {
            // Calculate the channels (3 or 4) - (use bits >> 3 for more speed).
            // Next, we calculate the stride and allocate enough memory for the pixels.
            channels = bits / 8;
            stride = channels * width;
            pImageData->data = new unsigned char[stride * height];

            // Load in all the pixel data line by line
            for(int y = 0; y < height; y++)
            {
                // Store a pointer to the current line of pixels
                unsigned char *pLine = &(pImageData->data[stride * y]);

                // Read in the current line of pixels
                fread(pLine, stride, 1, pFile);
            
                // Go through all of the pixels and swap the B and R values since TGA
                // files are stored as BGR instead of RGB (or use GL_BGR_EXT verses GL_RGB)
                for(i = 0; i < stride; i += channels)
                {
                    int temp     = pLine[i];
                    pLine[i]     = pLine[i + 2];
                    pLine[i + 2] = temp;
                }
            }
        }
        // Check if the image is a 16 bit image (RGB stored in 1 unsigned short)
        else if(bits == 16)
        {
            unsigned short pixels = 0;
            int r=0, g=0, b=0;

            // Since we convert 16-bit images to 24 bit, we hardcode the channels to 3.
            // We then calculate the stride and allocate memory for the pixels.
            channels = 3;
            stride = channels * width;
            pImageData->data = new unsigned char[stride * height];

            // Load in all the pixel data pixel by pixel
            for(int i = 0; i < width*height; i++)
            {
                // Read in the current pixel
                fread(&pixels, sizeof(unsigned short), 1, pFile);
                
                // To convert a 16-bit pixel into an R, G, B, we need to
                // do some masking and such to isolate each color value.
                // 0x1f = 11111 in binary, so since 5 bits are reserved in
                // each unsigned short for the R, G and B, we bit shift and mask
                // to find each value.  We then bit shift up by 3 to get the full color.
                b = (pixels & 0x1f) << 3;
                g = ((pixels >> 5) & 0x1f) << 3;
                r = ((pixels >> 10) & 0x1f) << 3;
                
                // This essentially assigns the color to our array and swaps the
                // B and R values at the same time.
                pImageData->data[i * 3 + 0] = r;
                pImageData->data[i * 3 + 1] = g;
                pImageData->data[i * 3 + 2] = b;
            }
        }   
        // Else return a NULL for a bad or unsupported pixel format
        else
            return NULL;
    }
    // Else, it must be Run-Length Encoded (RLE)
    else
    {
        // First, let me explain real quickly what RLE is.  
        // For further information, check out Paul Bourke's intro article at: 
        // http://astronomy.swin.edu.au/~pbourke/dataformats/rle/
        // 
        // Anyway, we know that RLE is a basic type compression.  It takes
        // colors that are next to each other and then shrinks that info down
        // into the color and a integer that tells how much of that color is used.
        // For instance:
        // aaaaabbcccccccc would turn into a5b2c8
        // Well, that's fine and dandy and all, but how is it down with RGB colors?
        // Simple, you read in an color count (rleID), and if that number is less than 128,
        // it does NOT have any optimization for those colors, so we just read the next
        // pixels normally.  Say, the color count was 28, we read in 28 colors like normal.
        // If the color count is over 128, that means that the next color is optimized and
        // we want to read in the same pixel color for a count of (colorCount - 127).
        // It's 127 because we add 1 to the color count, as you'll notice in the code.

        // Create some variables to hold the rleID, current colors read, channels, & stride.
        byte rleID = 0;
        int colorsRead = 0;
        channels = bits / 8;
        stride = channels * width;

        // Next we want to allocate the memory for the pixels and create an array,
        // depending on the channel count, to read in for each pixel.
        pImageData->data = new unsigned char[stride * height];
        byte *pColors = new byte [channels];

        // Load in all the pixel data
        while(i < width*height)
        {
            // Read in the current color count + 1
            fread(&rleID, sizeof(byte), 1, pFile);
            
            // Check if we don't have an encoded string of colors
            if(rleID < 128)
            {
                // Increase the count by 1
                rleID++;

                // Go through and read all the unique colors found
                while(rleID)
                {
                    // Read in the current color
                    fread(pColors, sizeof(byte) * channels, 1, pFile);

                    // Store the current pixel in our image array
                    pImageData->data[colorsRead + 0] = pColors[2];
                    pImageData->data[colorsRead + 1] = pColors[1];
                    pImageData->data[colorsRead + 2] = pColors[0];

                    // If we have a 4 channel 32-bit image, assign one more for the alpha
                    if(bits == 32)
                        pImageData->data[colorsRead + 3] = pColors[3];

                    // Increase the current pixels read, decrease the amount
                    // of pixels left, and increase the starting index for the next pixel.
                    i++;
                    rleID--;
                    colorsRead += channels;
                }
            }
            // Else, let's read in a string of the same character
            else
            {
                // Minus the 128 ID + 1 (127) to get the color count that needs to be read
                rleID -= 127;

                // Read in the current color, which is the same for a while
                fread(pColors, sizeof(byte) * channels, 1, pFile);

                // Go and read as many pixels as are the same
                while(rleID)
                {
                    // Assign the current pixel to the current index in our pixel array
                    pImageData->data[colorsRead + 0] = pColors[2];
                    pImageData->data[colorsRead + 1] = pColors[1];
                    pImageData->data[colorsRead + 2] = pColors[0];

                    // If we have a 4 channel 32-bit image, assign one more for the alpha
                    if(bits == 32)
                        pImageData->data[colorsRead + 3] = pColors[3];

                    // Increase the current pixels read, decrease the amount
                    // of pixels left, and increase the starting index for the next pixel.
                    i++;
                    rleID--;
                    colorsRead += channels;
                }
                
            }
                
        }
    }

    // Close the file pointer that opened the file
    fclose(pFile);

    // Fill in our tImageTGA structure to pass back
    pImageData->channels = channels;
    pImageData->sizeX    = width;
    pImageData->sizeY    = height;

    // Return the TGA data (remember, you must free this data after you are done)
    return pImageData;
}

/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *


///////////////////////////////// CREATE TEXTURE \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////   This creates a texture in OpenGL that we can use as a texture map
/////
///////////////////////////////// CREATE TEXTURE \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void CreateTexture(UINT textureArray[],char * strFileName, int textureID)
{
    if(!strFileName)                                    // Return from the function if no file name was passed in
        return;

/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *   
    
    // Just like the other image loaders, we return a pointer to some image data,
    // which needs to be freed once we are finished with it, along with it's data.

    tImageTGA *pImage = LoadTGA(strFileName);           // Load the image and store the data

/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *
    

    if(pImage == NULL)                                  // If we can't load the file, quit!
        exit(0);

    // Generate a texture with the associative texture ID stored in the array
    glGenTextures(1, &textureArray[textureID]);

    // Bind the texture to the texture arrays index and init the texture
    glBindTexture(GL_TEXTURE_2D, textureArray[textureID]);


/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *

    // Assume that the texture is a 24 bit RGB texture (We convert 16-bit ones to 24-bit)
    int textureType = GL_RGB;

    // If the image is 32-bit (4 channels), then we need to specify GL_RGBA for an alpha
    if(pImage->channels == 4)
        textureType = GL_RGBA;
        
    // Build Mipmaps (builds different versions of the picture for distances - looks better)
    gluBuild2DMipmaps(GL_TEXTURE_2D, pImage->channels, pImage->sizeX, 
                      pImage->sizeY, textureType, GL_UNSIGNED_BYTE, pImage->data);

/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *


    // Lastly, we need to tell OpenGL the quality of our texture map.  GL_LINEAR is the smoothest.
    // GL_NEAREST is faster than GL_LINEAR, but looks blochy and pixilated.  Good for slower computers though.
    // Read more about the MIN and MAG filters at the bottom of main.cpp
        
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 

    // Now we need to free the image data that we loaded since OpenGL stored it as a texture

    if (pImage)                                     // If we loaded the image
    {
        if (pImage->data)                           // If there is texture data
        {
            free(pImage->data);                     // Free the texture data, we don't need it anymore
        }

        free(pImage);                               // Free the image structure
    }
}

/////////////////////////////////// TOGGLE FULL SCREEN \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////   This function TOGGLES between FULLSCREEN and WINDOWED mode
/////
/////////////////////////////////// TOGGLE FULL SCREEN \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void ToggleFullScreen(void)
{
    if(SDL_WM_ToggleFullScreen(MainWindow) == 0)        // try to toggle fullscreen mode for window 'main_window' 
    {
        cerr << "Failed to Toggle Fullscreen mode : " << SDL_GetError() << endl;   // report error in case toggle fails
        Quit(0);
    }
}


///////////////////////////////   CREATE MY WINDOW   \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////  This function CREATES our WINDOW for drawing the GL stuff
/////
///////////////////////////////   CREATE MY WINDOW   \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void CreateMyWindow(const char * strWindowName, int width, int height, int VideoFlags)
{
    MainWindow = SDL_SetVideoMode(width, height, SCREEN_DEPTH, VideoFlags);     // SCREEN_DEPTH is macro for bits per pixel

    if( MainWindow == NULL )                            // if window creation failed
    {
        cerr << "Failed to Create Window : " << SDL_GetError() << endl;         // report error 
        Quit(0);
    }

    SDL_WM_SetCaption(strWindowName, "GameTutorials");  // set the window caption (first argument) and icon caption (2nd arg)
}


/////////////////////////////   SETUP PIXEL FORMAT   \\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////  Sets the pixel format for openGL and video flags for SDL
/////
/////////////////////////////   SETUP PIXEL FORMAT   \\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void SetupPixelFormat(void)
{
    //////// SURFACE IS THE DRAWABLE PORTION OF AN SDL WINDOW \\\\\\\\*
    
    /////////////  we set the common flags here
    VideoFlags    = SDL_OPENGL;                         // it's an openGL window
    VideoFlags   |= SDL_HWPALETTE;                      // exclusive access to hardware colour palette
    VideoFlags   |= SDL_RESIZABLE;                      // the window must be resizeable

    const SDL_VideoInfo * VideoInfo = SDL_GetVideoInfo();     // query SDL for information about our video hardware

    if(VideoInfo == NULL)                                     // if this query fails
    {
        cerr << "Failed getting Video Info : " << SDL_GetError() << endl;          // report error
        Quit(0);
    }

    ///////////// we set the system dependant flags here
    if(VideoInfo -> hw_available)                      // is it a hardware surface
        VideoFlags |= SDL_HWSURFACE;
    else
        VideoFlags |= SDL_SWSURFACE;

    // Blitting is fast copying / moving /swapping of contiguous sections of memory
    // for more about blitting check out : http://www.csc.liv.ac.uk/~fish/HTML/blitzman/bm_blitter.html
    if(VideoInfo -> blit_hw)                            // is hardware blitting available
        VideoFlags |= SDL_HWACCEL;

    SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );      // tell SDL that the GL drawing is going to be double buffered
    SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE,   SCREEN_DEPTH);         // size of depth buffer 
    SDL_GL_SetAttribute( SDL_GL_STENCIL_SIZE, 0);       // we aren't going to use the stencil buffer
    SDL_GL_SetAttribute( SDL_GL_ACCUM_RED_SIZE, 0);     // this and the next three lines set the bits allocated per pixel -
    SDL_GL_SetAttribute( SDL_GL_ACCUM_GREEN_SIZE, 0);   // - for the accumulation buffer to 0
    SDL_GL_SetAttribute( SDL_GL_ACCUM_BLUE_SIZE, 0);
    SDL_GL_SetAttribute( SDL_GL_ACCUM_ALPHA_SIZE, 0);
}


//////////////////////////// RESIZE OPENGL SCREEN \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////    This function resizes the viewport for OpenGL.
/////
//////////////////////////// RESIZE OPENGL SCREEN \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void SizeOpenGLScreen(int width, int height)            // Initialize The GL Window
{
    if (height==0)                                        // Prevent A Divide By Zero error
    {
        height=1;                                        // Make the Height Equal One
    }

    glViewport(0,0,width,height);                        // Make our viewport the whole window
                                                        // We could make the view smaller inside
                                                        // Our window if we wanted too.
                                                        // The glViewport takes (x, y, width, height)
                                                        // This basically means, what our our drawing boundries

    glMatrixMode(GL_PROJECTION);                        // Select The Projection Matrix
    glLoadIdentity();                                    // Reset The Projection Matrix

                                                        // Calculate The Aspect Ratio Of The Window
                                                        // The parameters are:
                                                        // (view angle, aspect ration of the width to the height, 
                                                        //  The closest distance to the camera before it clips, 
                  // FOV        // Ratio                //  The farthest distance before it stops drawing)
    gluPerspective(45.0f,(GLfloat)width/(GLfloat)height, .5f ,150.0f);

    glMatrixMode(GL_MODELVIEW);                            // Select The Modelview Matrix
    glLoadIdentity();                                    // Reset The Modelview Matrix
}


/////////////////////////////////   INITIALIZE OPENGL  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
/////
/////         This function handles all the initialization for openGL
/////
/////////////////////////////////   INITIALIZE OPENGL  \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void InitializeOpenGL(int width, int height)
{
   glEnable( GL_DEPTH_TEST );                             // Enables Depth Test i.e enables use of depth buffer for drawing

 /////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *

    // This allows us to use texture mapping, otherwise we just use colors.

    glEnable(GL_TEXTURE_2D);                            // Enable Texture Mapping

/////// * /////////// * /////////// * NEW * /////// * /////////// * /////////// *

    SizeOpenGLScreen(width, height);                       // resize the OpenGL Viewport to the given height and width
}

//////////////////////////////////      HANDLE KEY PRESS EVENT    \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
//////
//////     This function handles the keypress events generated when the user presses a key
//////
//////////////////////////////////      HANDLE KEY PRESS EVENT    \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void HandleKeyPressEvent(SDL_keysym * keysym)
{
    switch(keysym -> sym)                                  // which key have we got
    {
        case SDLK_F1 :                                     // if it is F1
            ToggleFullScreen();                            // toggle between fullscreen and windowed mode
            break;

        case SDLK_ESCAPE:                                  // if it is ESCAPE
            Quit(0);                                       // quit after cleaning up
    }
}
////////////////////////////////      MAIN      \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
//////
//////     create the window and calling the initialization functions
//////
////////////////////////////////      MAIN      \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

int main(void)
{
    // print user instructions
    cout << " Hit the F1 key to Toggle between Fullscreen and windowed mode" << endl;
    cout << " Hit ESC to quit" << endl;

    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )                      // try to initialize SDL video module
    {
        cerr << "Failed initializing SDL Video : " << SDL_GetError() << endl;      // report error if it fails
        return 1;                                             // we use this instead of Quit because SDL isn't yet initialized
    }

    // Set up the format for the pixels of the OpenGL drawing surface
    SetupPixelFormat();
    // Create our window, we pass caption for the window, the width, height and video flags required
    CreateMyWindow("www.GameTutorials.com - TextureMapping", SCREEN_WIDTH, SCREEN_HEIGHT, VideoFlags);

    // Initializes our OpenGL drawing surface
    
    Init();

    // Run our message loop
    MainLoop();

    // quit main returning success
    return 0;
}


////////////////////////////////    QUIT    \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*
//////
//////      This will shutdown SDL and quit the program
//////
////////////////////////////////    QUIT    \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*

void Quit(int ret_val)
{
    SDL_Quit();                                            // shuts down SDL stuff

    exit(ret_val);                                         // quit the program
}

/////////////////////////////////////////////////////////////////////////////////
//
// * QUICK NOTES * 
//
// In this version of our texture mapping tutorials, we added a TGA loader.  In
// main.h you will find the tImageTGA structure that will contain the image info.  
// Only 1 new function was added to this tutorial:
//
// tImageTGA *LoadTGA(const char *filename);
//
//
// Ben Humphrey (DigiBen)
// Game Programmer
// DigiBen@GameTutorials.com
// Co-Web Host of www.GameTutorials.com
//
//
