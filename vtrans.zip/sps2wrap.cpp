#include "sps2.h"
#include "sps2wrap.h"
#include <assert.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <asm/ioctl.h>
#include "PS2Defines.h"

// These defines are the only ones that are needed from libps2dev
// They are needed for the ioctl calls
// They are extracted from <linux/ps2/dev.h>
#define PS2EV_N_VBSTART		0
#define PS2EV_N_FINISH		9

#define PS2EV_VBSTART		(1 << PS2EV_N_VBSTART)
#define PS2EV_FINISH		(1 << PS2EV_N_FINISH)

#define PS2IOC_MAGIC		0xee

#define PS2IOC_ENABLEEVENT	_IO(PS2IOC_MAGIC, 0)
#define PS2IOC_GETEVENT		_IO(PS2IOC_MAGIC, 1)
#define PS2IOC_WAITEVENT	_IO(PS2IOC_MAGIC, 2)


CSPS2Manager::CSPS2Manager()
{
	m_Running = true;
	m_pMemCached = NULL;
	m_SS_Number = 0;
	m_SS_Event_FD = -1;
	// Write the disk cache to the HDD for safety
	printf("Writing cache to HDD\n");
	system("sync");
}

CSPS2Manager::~CSPS2Manager()
{
	printf("Shutting down CSPS2Manager\n");
	sps2UScreenShutdown();
	if(m_pMemCached)sps2Free(m_pMemCached);
	sps2Release(m_iSPS2Desc);
}

void CSPS2Manager::Initialise(const int iAllocPages)
{
	// The minimum needed
	assert(iAllocPages >= 640);
	
	// Maximum of about 12MB although possibly more is ok
	assert(iAllocPages <= 3000);
	
	printf("Initilising CSPS2Manager with %d 4k Blocks (%d kBytes)\n", 
				iAllocPages, (iAllocPages*4));
	
	m_iNumPages = iAllocPages;

	m_iSPS2Desc = sps2Init();

	if(m_iSPS2Desc < 0)
	{
		fprintf(stderr, "Failed to initialise SPS2 library." \
				"Please check that the module is loaded.\n");
		exit(-1);
	}
	
	m_pMemCached = sps2Allocate(iAllocPages * PAGE4K,
			SPS2_MAP_BLOCK_4K | SPS2_MAP_CACHED, m_iSPS2Desc);
			
	if(m_pMemCached < 0)
	{
		fprintf(stderr, "Failed to Allocate SPS2 memory.\n");
		exit(-1);
	}
			
	m_pCached = (char *)m_pMemCached->pvStart;
	
	// This arrangement needs 640 4k blocks minimum
	
	m_FontDmaBase = (void *)(&m_pCached[(m_iNumPages - 32) * PAGE4K]);
	
	m_Tex1DmaBase = (void *)(&m_pCached[(m_iNumPages - 32 - 1) * PAGE4K]);
	m_Tex2DmaBase = (void *)(&m_pCached[(m_iNumPages - 32 - 2) * PAGE4K]);
	m_Tex3DmaBase = (void *)(&m_pCached[(m_iNumPages - 32 - 3) * PAGE4K]);
	m_Tex4DmaBase = (void *)(&m_pCached[(m_iNumPages - 32 - 4) * PAGE4K]);
	
	m_SShotDmaBase = (void *)(&m_pCached[(m_iNumPages - 32 - 5) * PAGE4K]);
	m_SShotBase =    (void *)(&m_pCached[(m_iNumPages - 32 - 6) * PAGE4K]);
	
	// Some free memory at this point
		
	m_Prim4DmaBase = (void *)(&m_pCached[(m_iNumPages - 64 + 3) * PAGE4K]);
	m_Prim3DmaBase = (void *)(&m_pCached[(m_iNumPages - 64 + 2) * PAGE4K]);
	m_Prim2DmaBase = (void *)(&m_pCached[(m_iNumPages - 64 + 1) * PAGE4K]);
	m_Prim1DmaBase = (void *)(&m_pCached[(m_iNumPages - 64 + 0) * PAGE4K]);
	
	
	
	m_FontTexBase = (void *)(&m_pCached[(m_iNumPages - 64 * 2) * PAGE4K]);
	
	m_Tex1Base = 	(void *)(&m_pCached[(m_iNumPages - 64 * 3) * PAGE4K]);
	m_Tex2Base = 	(void *)(&m_pCached[(m_iNumPages - 64 * 4) * PAGE4K]);
	m_Tex3Base = 	(void *)(&m_pCached[(m_iNumPages - 64 * 5) * PAGE4K]);
	m_Tex4Base = 	(void *)(&m_pCached[(m_iNumPages - 64 * 6) * PAGE4K]);
	
	m_Prim4Base = 	(void *)(&m_pCached[64 * 3 * PAGE4K]);
	m_Prim3Base = 	(void *)(&m_pCached[64 * 2 * PAGE4K]);
	m_Prim2Base = 	(void *)(&m_pCached[64 * 1 * PAGE4K]);
	m_Prim1Base = 	(void *)(&m_pCached[0]);
	
	sps2UScreenInit(0);
	
	// Get the video mode
	m_VideoMode = sps2UScreenGetVideoMode();
}

sps2Memory_t * CSPS2Manager::GetMemoryStruct(void)
{
	return m_pMemCached;
}

int CSPS2Manager::GetSPS2Handle(void)
{
	return m_iSPS2Desc;
}

unsigned long CSPS2Manager::GetPhysicalAddress(void * pMemory)
{
	return sps2GetPhysicalAddress(pMemory, m_pMemCached);	
}

int CSPS2Manager::GetScreenWidth()
{ 
	return sps2UScreenGetWidth(); 
}

int CSPS2Manager::GetScreenHeight()
{ 
	return sps2UScreenGetHeight(); 
}

void * CSPS2Manager::GetTex1Base(void)
{
	return m_Tex1Base;
}

void * CSPS2Manager::GetTex2Base(void)
{
	return m_Tex2Base;
}

void * CSPS2Manager::GetTex3Base(void)
{
	return m_Tex3Base;
}

void * CSPS2Manager::GetTex4Base(void)
{
	return m_Tex4Base;
}
		
void * CSPS2Manager::GetTex1DmaBase(void)
{ 
	return m_Tex1DmaBase; 
}

void * CSPS2Manager::GetTex2DmaBase(void)
{ 
	return m_Tex2DmaBase; 
}

void * CSPS2Manager::GetTex3DmaBase(void)
{ 
	return m_Tex3DmaBase; 
}

void * CSPS2Manager::GetTex4DmaBase(void)
{ 
	return m_Tex4DmaBase; 
}
		
void * CSPS2Manager::GetPrim1Base(void)
{
	return m_Prim1Base;
}

void * CSPS2Manager::GetPrim2Base(void)
{
	return m_Prim2Base;
}

void * CSPS2Manager::GetPrim3Base(void)
{
	return m_Prim3Base;
}

void * CSPS2Manager::GetPrim4Base(void)
{
	return m_Prim4Base;
}

void * CSPS2Manager::GetPrim1DmaBase(void)
{ 
	return m_Prim1DmaBase; 
}

void * CSPS2Manager::GetPrim2DmaBase(void)
{ 
	return m_Prim2DmaBase; 
}

void * CSPS2Manager::GetPrim3DmaBase(void)
{ 
	return m_Prim3DmaBase; 
}

void * CSPS2Manager::GetPrim4DmaBase(void)
{ 
	return m_Prim4DmaBase; 
}

void * CSPS2Manager::GetFontTexBase(void)
{ 
	return m_FontTexBase; 
}
		
void * CSPS2Manager::GetFontDmaBase(void)
{ 
	return m_FontDmaBase; 
}

void * CSPS2Manager::GetSShotDmaBase(void)
{ 
	return m_SShotDmaBase; 
}

void * CSPS2Manager::GetSShotBase(void)
{ 
	return m_SShotBase; 
}

unsigned int CSPS2Manager::GetVideoMode(void)
{ 
	return m_VideoMode; 
}

unsigned int CSPS2Manager::GetFirstFreeGSPage(void)
{
	return sps2UScreenGetFirstFreeGSPage();
}

void CSPS2Manager::FirePacketToGS(void * const pStart, void * const pEnd, void * const pDMA)
{
	Dn_CHCR_t chcr;				// channel control register 
	Dn_TADR_t tadr;				// Tag address register
	
	// Use a REF tags to point the DMAC to the data
	sps2DMATag_t DMARef;
	uint64 * pDMATag = (uint64 *)(pDMA);

	//calculate how many bytes in the packet
	int iWC = (int)pEnd - (int)pStart;
	
	//printf("Packet Size = %d\n", iWC); 
	
	// return if no data
	if(iWC == 0) return;

	// Assert that we haven't written more data than 256k
	assert(iWC < (1024*256));	
	
	// Check if the packet extends over a 4k Page
	if(iWC > PAGE4K)
	{	
		// Configure the Ref Tags to send 4k of data
		DMARef.i64 = 0;
		DMARef.s.QWC =  PAGE4K >> 4;	// Transfer 4K 
		DMARef.s.ID = DMA_ID_SOURCE_REF;
		
		// Now set up all the 4k pages	
		int i = 0;
		do
		{
			// Get the physical address of each 4K page, and put it into the ref tag.
			// **********  look at this again
			DMARef.s.ADDR = GetPhysicalAddress((void *)(((char *)pStart) + (i*PAGE4K)));
	
			// Add the ref tag to the DMA chain.
			*pDMATag = DMARef.i64;
			pDMATag += 2;
			i++;
			// Find out how much data is left
			iWC -= PAGE4K;
		}while(iWC > PAGE4K);
		
		// If there is remaining data, send it with a ref tag
		if(iWC > 0)
		{
			// Get the physical address of each 4K page, and put it into the ref tag.
			// **********  look at this again
			DMARef.s.ADDR = GetPhysicalAddress((void *)(((char *)pStart) + (i*PAGE4K)));
			DMARef.s.QWC =  iWC >> 4;	// Transfer 4K 
			// Add the ref tag to the DMA chain.
			*pDMATag = DMARef.i64;
			pDMATag += 2;
		}
	}
	// The Packet is less than 4k - send it with one ref tag
	else
	{
		DMARef.i64 = 0;
		DMARef.s.QWC = iWC >> 4;	// Transfer all the data
		DMARef.s.ID = DMA_ID_SOURCE_REF;
	
		// Get the physical address of the data and put it into the ref tag.
		DMARef.s.ADDR = GetPhysicalAddress(pStart);
	
		// Add the ref tag to the DMA chain.
		*pDMATag = DMARef.i64;
		pDMATag += 2;
	}

	// Now that we have uploaded the data, the DMA chain needs to be ended.
	sps2DMATag_t DMAEnd;

	DMAEnd.i64 = 0;
	DMAEnd.s.QWC = 0;	
	DMAEnd.s.ID = DMA_ID_SOURCE_END;

	// Add the DMA tag to the chain
	*pDMATag = DMAEnd.i64;

	// Importand - Try to remember this!!!!!!!!!!!!!!!!!!!!
	FlushCache();
			
	// Set the address of the first tag (right at the start of the chain)
	tadr.i32 = 0;
	tadr.s.SPR = 0;
	tadr.s.ADDR = GetPhysicalAddress(pDMA);
	*EE_D2_TADR = tadr.i32;

	// Don't transfer any data from MADR
	*EE_D2_QWC = 0;

	// Set the channel control register
	chcr.i32 = 0;
	chcr.s.MOD = CHCR_MOD_CHAIN;
	chcr.s.STR = 1;

	// Fire off the packet!
	*EE_D2_CHCR = chcr.i32;

	// Wait for it to complete
	WaitForDMA(2);
	
	//while((*EE_D2_CHCR)&0x0100); 

}

void CSPS2Manager::FirePacketToVIF(void * const pStart, void * const pEnd, void * const pDMA)
{
	Dn_CHCR_t chcr;				// channel control register 
	Dn_TADR_t tadr;				// Tag address register
	
	// Use a REF tags to point the DMAC to the data
	sps2DMATag_t DMARef;
	uint64 * pDMATag = (uint64 *)(pDMA);
		
	//calculate how many bytes in the packet
	int iWC = (int)pEnd - (int)pStart;
	
	//printf("Packet Size = %d\n", iWC); 
	
	// return if no data
	if(iWC == 0) return;

	// Assert that we haven't written more data than 256k
	assert(iWC < (1024*256));	
	
	// Check if the packet extends over a 4k Page
	if(iWC > PAGE4K)
	{	
		// Configure the Ref Tags to send 4k of data
		DMARef.i64 = 0;
		DMARef.s.QWC =  PAGE4K >> 4;	// Transfer 4K 
		DMARef.s.ID = DMA_ID_SOURCE_REF;
		
		// Now set up all the 4k pages	
		int i = 0;
		do
		{
			// Get the physical address of each 4K page, and put it into the ref tag.
			// **********  look at this again
			DMARef.s.ADDR = GetPhysicalAddress((void *)(((char *)pStart) + (i*PAGE4K)));
	
			// Add the ref tag to the DMA chain.
			*pDMATag = DMARef.i64;
			pDMATag += 2;
			i++;
			// Find out how much data is left
			iWC -= PAGE4K;
		}while(iWC > PAGE4K);
		
		// If there is remaining data, send it with a ref tag
		if(iWC > 0)
		{
			// Get the physical address of each 4K page, and put it into the ref tag.
			// **********  look at this again
			DMARef.s.ADDR = GetPhysicalAddress((void *)(((char *)pStart) + (i*PAGE4K)));
			DMARef.s.QWC =  iWC >> 4;	// Transfer 4K 
			// Add the ref tag to the DMA chain.
			*pDMATag = DMARef.i64;
			pDMATag += 2;
		}
	}
	// The Packet is less than 4k - send it with one ref tag
	else
	{
		DMARef.i64 = 0;
		DMARef.s.QWC = iWC >> 4;	// Transfer all the data
		DMARef.s.ID = DMA_ID_SOURCE_REF;
	
		// Get the physical address of the data and put it into the ref tag.
		DMARef.s.ADDR = GetPhysicalAddress(pStart);
	
		// Add the ref tag to the DMA chain.
		*pDMATag = DMARef.i64;
		pDMATag += 2;
	}

	// Now that we have uploaded the data, the DMA chain needs to be ended.
	sps2DMATag_t DMAEnd;

	DMAEnd.i64 = 0;
	DMAEnd.s.QWC = 0;	
	DMAEnd.s.ID = DMA_ID_SOURCE_END;

	// Add the DMA tag to the chain
	*pDMATag = DMAEnd.i64;

	// Importand - Try to remember this!!!!!!!!!!!!!!!!!!!!
	FlushCache();
			
	// Set the address of the first tag (right at the start of the chain)
	tadr.i32 = 0;
	tadr.s.SPR = 0;
	tadr.s.ADDR = GetPhysicalAddress(pDMA);
	*EE_D1_TADR = tadr.i32;

	// Don't transfer any data from MADR
	*EE_D1_QWC = 0;

	// Set the channel control register
	chcr.i32 = 0;
	chcr.s.MOD = CHCR_MOD_CHAIN;
	chcr.s.STR = 1;
	chcr.s.DIR = 1;			// We are going FROM main memory
	chcr.s.TTE = 0; 		// Don't transfer the tag

	// Fire off the packet!
	*EE_D1_CHCR = chcr.i32;

	// Wait for it to complete
	WaitForDMA(1);
}


int CSPS2Manager::FileExists(const char * const FileName)
{
	FILE * f;
	f = fopen(FileName, "rb");	// Try to open the file
	if (f == NULL) return 0; 	// File doesn't exist
	fclose (f);
	return 1;					// File exists
}	

void CSPS2Manager::ScreenShot(const int ImageType)
{
	char name[256];
	unsigned char * data;
	unsigned char tmp;
	unsigned short Width, Height;
	int BytesPerPixel = 4;
	
	// Open the PS2Event device to capture the finish event
	m_SS_Event_FD = open("/dev/ps2event", O_RDWR);
	if(m_SS_Event_FD < 0)
	{
		printf("Error -- open(/dev/ps2event) -- in screenshot function");
		return;
	}
	
	// Current Screen width and height
	Width = (unsigned short)GetScreenWidth();
	Height = (unsigned short)GetScreenHeight();
	
	//printf("%x %x", Width, Height);
	
	// Get an unused filename
	do
	{
		sprintf (name, "sshot_%02d.tga", m_SS_Number++);
	} while (FileExists(name));
	
	// Print the filename to the console with some stats
	if(ImageType == IMAGE_RGB)
		printf("Dumping Screen to File %s. Dimensions %d x %d - RGB\n", name, Width, Height);
	if(ImageType == IMAGE_RGBA)
		printf("Dumping Screen to File %s. Dimensions %d x %d - RGBA\n", name, Width, Height);
	
	
	// Open the file for writing to	
	FILE * f = fopen(name, "wb");

	// Create a targa header for a 640x480, 32bit picture
	unsigned char header[18] = {
		0,				// Field 1 - Number of Bytes in Field 6
		0, 				// Field 2 - Colour Map Type 0 = no colour map
		2, 				// Field 3 - Image Type = Uncompressed true colour image
		0, 0, 0, 0, 0,	// Field 4 - Colour map specification
						// Field 5 - The remaining 10 bytes
		0, 0, 			// X origin
		0, 0, 			// Y origin
		0x80, 2, 		// Width 640
		0xe0, 1, 		// Height 480
		32, 			// Pixel colour depth
		8				// Number of alpha channel bits
	};
	
	//for(int i =0; i< 18; i++)printf("%x ", header[i]);printf("\n");
		
	//Change the width and height in the header to the correct dimensions
	unsigned char * pDimension = (unsigned char *)(&Width);
	//printf("%x %x\n", pDimension[0], pDimension[1]);
	header[12] = pDimension[0];
	header[13] = pDimension[1];
	
	pDimension = (unsigned char *)(&Height);
	header[14] = pDimension[0];
	header[15] = pDimension[1];
	
	// Change header and bytes per pixel if RGB
	if(ImageType == IMAGE_RGB)
	{
		header[16] = 24;
		header[17] = 0;
		BytesPerPixel = 3;
	}
	
	
	//for(int i =0; i< 18; i++)printf("%x ", header[i]);printf("\n");
	
	// write the header to the file	
	fwrite(header, 18, 1, f);
	
	// Now Download the Frame buffer, from the bottom up
	for(int y = 0; y < Height; y++)
	{
		DownloadVram(GetSShotDmaBase(), GetSShotBase(), 0, 10, 0, (Height - 1 - y), Width, 1);

		// convert RGBA to BGRA
		data = (unsigned char *)GetSShotBase();
		for(int x = 0; x < Width; x++)
		{
			tmp = data[0];
			data[0] = data[2];
			data[2] = tmp;
			
			// Write pixel to file
			fwrite(data, BytesPerPixel, 1, f);
			
			data += 4;
		}
		// Write data to file
		//fwrite(GetSShotBase(), 4, Width, f);
	}
	
	// Close the file
	fclose(f);
	
	// Close the PS2Event device
	close(m_SS_Event_FD);
}

void CSPS2Manager::DownloadVram(void * const pDmaBase, void * const pMemBase, 
								int addr, int bufw, int x, int y, int w, int h)
{
	// Ensure the VBlank event is enabled
	ioctl(m_SS_Event_FD, PS2IOC_ENABLEEVENT, PS2EV_VBSTART);
	
	// Pointer to sps2 allocated unswapable memory.
	uint32 * pDmaMem = (uint32 *)pDmaBase;	

	uint32 uSrcPtr = addr;
	uint32 uQSize = (w*h*4)/16; // assuming 32bit framebuffer

	// Setup transfer texture back to memory
	pDmaMem[0] = 0; //NOP;
	pDmaMem[1] = 0x06008000; //MSKPATH3(0x8000);
	pDmaMem[2] = 0x13000000; //FLUSHA;
	pDmaMem[3] = 0x50000006; //DIRECT(6);

	// Add GifTag Data
	uint64 * pDmaMem64 = (uint64 *) (pDmaMem + 4);
	
	// QW1: The Giftag for A+D mode
	sps2GIFTag_t * pGIFTag = (sps2GIFTag_t *)pDmaMem64;
	pGIFTag->i128 = 0;
	pGIFTag->s.NLOOP = 5;	// We want to set 5 registers
	pGIFTag->s.PRE = 0;
	pGIFTag->s.EOP = 1;		// This is the end of the GS Packet
	pGIFTag->s.PRIM = 0;
	pGIFTag->s.FLG = GIF_FLG_PACKED;
	pGIFTag->s.NREG = 1;
	pGIFTag->s.REGS = GIF_REG_A_D;
	
	//pDmaMem64[0] = (GS_GIFTAG(5, 1, 0, 0, 0, 1)); // GIFTAG(NLOOP, EOP, PRE, PRIM, FLG, NREG)
	//pDmaMem64[1] = (0xe);

	pDmaMem64[2] = (BITBLTBUF_SET( uSrcPtr, bufw, 0, 0, 0, 0 ));
	pDmaMem64[3] = (GIF_A_D_REG_BITBLTBUF);

	pDmaMem64[4] = (TRXPOS_SET(x, y, 0, 0, 0)); // SSAX, SSAY, DSAX, DSAY, DIR
	pDmaMem64[5] = (GIF_A_D_REG_TRXPOS);

	pDmaMem64[6] = (TRXREG_SET(w, h)); // RRW, RRh
	pDmaMem64[7] = (GIF_A_D_REG_TRXREG);

	pDmaMem64[8] = (0);
	pDmaMem64[9] = (GIF_A_D_REG_FINISH);

	pDmaMem64[10] = (TRXDIR_SET(1)); // XDIR
	pDmaMem64[11] = (GIF_A_D_REG_TRXDIR);

	uint32 prev_chcr = *EE_D1_CHCR;

	// vif1 must be available
	if ((*EE_D1_CHCR & 0x0100) != 0)
	{
		printf("VIF1 is not available for the Screen Shot\n");
		exit(-1);
	}	
	
	// set the FINISH event
	// PS2IOC_ENABLEEVENT enable the code to read a particular event
	ioctl(m_SS_Event_FD, PS2IOC_ENABLEEVENT, PS2EV_FINISH);
	// PS2IOC_GETEVENT Reset to zero the event,
	ioctl(m_SS_Event_FD, PS2IOC_GETEVENT, PS2EV_FINISH);

	// Make sure all cache is writen to main memory
	FlushCache();
	
	// Setup and start DMA transfer to VIF1
	*EE_D1_QWC = 0x7;
	*EE_D1_MADR = GetPhysicalAddress(pDmaBase);
	//             DIR      MOD       ASP     TTE       TIE      STR
	*EE_D1_CHCR = (1<<0) | (0<<2) | (0<<4) | (0<<6) | (0<<7) | (1<<8);

	// Wait till memory load is complete
	asm __volatile__( " sync.l " );
	
	// Wait till DMA is complete (STR=0)
	while ( *EE_D1_CHCR & 0x0100 );

	// Wait for the GS to finish loading the registers
	ioctl(m_SS_Event_FD, PS2IOC_WAITEVENT, PS2EV_FINISH);
		
	// START! The actual download to memory 

	// wait for VIF1-FIFO to empty and become idle 
	while(*EE_VIF1_STAT & 0x1f000003); 
	
	// Change the VIF1 direction to VIF1->Memory
	*((volatile uint32 *) EE_VIF1_STAT) = (1<<23);
	
	// Change direction of VIF1 FIF0 Local->Host
	DPUT_GS_BUSDIR( ( uint64 ) 0x00000001 );
	
	// Setup and start DMA transfer from VIF1
	*EE_D1_QWC = uQSize;
	*EE_D1_MADR = GetPhysicalAddress(pMemBase);
	//          DIR    MOD       ASP     TTE       TIE      STR
	*EE_D1_CHCR = 0 | (0<<2) | (0<<4) | (0<<6) | (0<<7) | (1<<8);

	// Wait till memory load is complete
	asm __volatile__( " sync.l " );

	// check if DMA is complete (STR=0)
	while ( *EE_D1_CHCR & 0x0100 );
	
	// Restore CHCR and wait for it to complete
	*EE_D1_CHCR = prev_chcr;
	asm __volatile__( " sync.l " );
	
	// wait for VIF1-FIFO to empty and become idle 
	while ( *EE_VIF1_STAT & 0x1f000003 ); 

	
	// Change the VIF1 and VIF1 FIFO Direction back to normal
	*((volatile uint32 *) EE_VIF1_STAT) = 0;
	DPUT_GS_BUSDIR( ( uint64 ) 0 );
	
	// Re-enable path3 transfers
	static uint32 enable_path3[4] ALIGN_QW = {
	0x06000000, //MSKPATH3(0),
	0,
	0,
	0};

	DPUT_EE_VIF1_FIFO( *( uint128 * ) enable_path3 );

	// Re-enable the VBSTART event
	// This gets messed up with the FINISH event calls
	ioctl(m_SS_Event_FD, PS2IOC_ENABLEEVENT, PS2EV_VBSTART);
	
	// Make sure data is written to main memory
	FlushCache();
}

unsigned int CSPS2Manager::GetTimeDelta(void)
{
	static unsigned int LastTime;
	unsigned int Change;
	unsigned int Time = *EE_T3_COUNT;
	
	if(Time < LastTime)// The counter has wrapped
	{
		Change = Time + (0x10000 - LastTime);
	}
	else
	{
		Change = Time - LastTime;
	}

	LastTime = Time;
	
	return Change;
}

// The numbers in this function are the horizontal blank rates in Hz
// See Page 84 of the GS Users manual

float CSPS2Manager::GetFPS(void)
{
	unsigned int TimeDelta = GetTimeDelta();
	
	if(TimeDelta == 0)return -1.0f;
	
	switch(m_VideoMode)
	{
		case SPS2U_SCR_VESA:
			return 31469.0f / (float)TimeDelta;	
	
		case SPS2U_SCR_PAL:
			return 15625.0f / (float)TimeDelta;
	
		case SPS2U_SCR_NTSC:
			return 15734.0f / (float)TimeDelta;
	
		default:
			return 0.0f;
	}
}
