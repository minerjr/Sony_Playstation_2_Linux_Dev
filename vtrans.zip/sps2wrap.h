#ifndef __SPS2WRAP_H__
#define __SPS2WRAP_H__

#include "sps2.h"

#define IMAGE_RGBA	(0)
#define IMAGE_RGB	(1)


// Set up SPS2 and do initial allocation of memory block
// 1 Page = 4k Bytes
class CSPS2Manager
{
	public:
	
		CSPS2Manager();
		
		~CSPS2Manager();

		void Initialise(const int iAllocPages);

		void BeginScene(int R, int G, int B);
		
		void EndScene(void);

		void FlushCache(void);
		
		void WaitForDMA(int Channel);

		int GetScreenWidth(void);
		
		int GetScreenHeight(void);
		
		unsigned int GetFirstFreeGSPage(void);
				
		unsigned long GetPhysicalAddress(void * pMemory);
		
		void FirePacketToGS(void * const pStart, void * const pEnd, void * const pDMA);
		void FirePacketToVIF(void * const pStart, void * const pEnd, void * const pDMA);
		
		void ScreenShot(const int ImageType);
		
		void * GetTex1Base(void);
		void * GetTex2Base(void);
		void * GetTex3Base(void);
		void * GetTex4Base(void);
				
		void * GetTex1DmaBase(void);
		void * GetTex2DmaBase(void);
		void * GetTex3DmaBase(void);
		void * GetTex4DmaBase(void);
				
		void * GetPrim1Base(void);
		void * GetPrim2Base(void);
		void * GetPrim3Base(void);
		void * GetPrim4Base(void);
		
		void * GetPrim1DmaBase(void);
		void * GetPrim2DmaBase(void);
		void * GetPrim3DmaBase(void);
		void * GetPrim4DmaBase(void);
				
		void * GetFontTexBase(void);
		void * GetFontDmaBase(void);
		
		void * GetSShotDmaBase(void);
		void * GetSShotBase(void);
		
		bool GetRunningStatus(void);
		void SetRunningStatus(bool Status);
		
		sps2Memory_t * GetMemoryStruct(void);
		
		int GetSPS2Handle(void);
		
		unsigned int GetVideoMode(void);
		
		// Performance timer metheds
		unsigned int GetTimeDelta(void);
		float GetFPS(void);
		
	private:
	
		// Pointer to memory structure used to define memory allocated by SPS2
		sps2Memory_t * m_pMemCached;
		
		// Pointer to the start of allocated sps2 memory		
		char * m_pCached;
		
		// The SPS2 Kernel Module handle
		int m_iSPS2Desc;
		
		// Number of 4k Pages allocated
		int m_iNumPages;
		
		void * m_Tex1Base;
		void * m_Tex2Base;
		void * m_Tex3Base;
		void * m_Tex4Base;
		
		void * m_Tex1DmaBase;
		void * m_Tex2DmaBase;
		void * m_Tex3DmaBase;
		void * m_Tex4DmaBase;
		
		void * m_FontTexBase;
		void * m_FontDmaBase;
		
		void * m_Prim1Base;
		void * m_Prim2Base;
		void * m_Prim3Base;
		void * m_Prim4Base;
		
		void * m_Prim1DmaBase;
		void * m_Prim2DmaBase;
		void * m_Prim3DmaBase;
		void * m_Prim4DmaBase;
		
		void * m_SShotDmaBase;
		void * m_SShotBase;
		
		// Running status of program
		bool m_Running;
		
		// The current video mode
		unsigned int m_VideoMode;
		
		// Screen Shot variables
		int m_SS_Number;
		int m_SS_Event_FD;
		
		// Screen shot functions
		int FileExists(const char * const FileName);
		void DownloadVram(void * const pDmaBase, void * const pMemBase, int addr, int bufw, int x, int y, int w, int h);
};

inline void CSPS2Manager::BeginScene(int R, int G, int B)
{
	sps2UScreenClear(R, G, B);
}

inline void CSPS2Manager::EndScene()
{
	sps2UScreenSwap();
}

inline void CSPS2Manager::FlushCache()
{
	sps2FlushCache(m_iSPS2Desc);
}

inline void CSPS2Manager::WaitForDMA(int Channel)
{
	sps2WaitForDMA(Channel, m_iSPS2Desc);
}

inline void CSPS2Manager::SetRunningStatus(bool Status)
{
	m_Running = Status;
}

inline bool CSPS2Manager::GetRunningStatus(void)
{
	return m_Running;
}


//extern CSPS2Manager Manager;



#endif
