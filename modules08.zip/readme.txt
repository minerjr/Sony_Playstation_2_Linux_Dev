Authors
_______
[RO]man, Herben, others


Description
___________
These are some decompiled modules from ps2 bios scph10000.
Only from IRXes, for now.
Developers could find them usefull as there is not much info
about how ps2 works and how can it be programmed.

I hope this will cast some light on iop insides.
I think that they are enough accurate.
Some of them are compilable (e.g. sysmem) and also
some of them will change in the future as I'll have more info.


Disclaimer
__________
No warranties, use it on your own risk, etc.


Thanks
______
Herben & others [they know;)]


Maintainer
__________
[RO]man (roman_ps2dev@hotmail.com)
