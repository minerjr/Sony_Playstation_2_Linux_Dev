//[module]	FILEIO
//[processor]	IOP
//[type]	ELF-IRX
//[size]	8437(0x20F5)
//[bios]	10000(0x61A40-0x63B40)
//[iopboot]	26
//[name]	"FILEIO_service"
//[version]	0x101
//[memory map]	-
//[handlers]	80000001(RPC,Multi Threaded Fileio module.(99/11/15))
//		80000003(RPC,iop heap service (99/11/03))
//[entry point]	start
//[made by]	[RO]man (roman_ps2dev@hotmail.com) 2002-07-30

#include "..\include\sysmem.h"		//(0x101,AllocSysMemory,FreeSysMemory,Kprintf)
#include "..\include\loadcore.h"	//(0x101,FlushDcache,QueryBootMode)
#include "..\include\intrman.h"		//(0x102,CpuEnableIntr,CpuSuspendIntr,CpuResumeIntr)
#include "..\include\sifman.h"		//(0x101,sceSifInit,sceSifSetDma,sceSifDmaStat,sceSifCheckInit)
#include "..\include\thbase.h"		//(0x101,CreateThread,StartThread,GetThreadId)
#include "..\include\sifcmd.h"		//(0x101,sceSifInitRpc,sceSifRegisterRpc,sceSifSetRpcQueue,sceSifRpcLoop,sceSifGetOtherData)
#include "..\include\stdio.h"		//(0x102,printf)
#include "..\include\ioman.h"		//(0x102,open,close,read,write,lseek,ioctl,remove,mkdir,rmdir,dopen,dclose,dread,getstat,chstat,format,AddDrv,DelDrv)

#define MIN(a, b)	(((a)<(b))?(a):(b))

struct _rests{
	struct _rest{
		int  ssize;
		int  esize;
		void *sbuf;
		void *ebuf;
	} rest;
	char	sbuffer[16];
	char	ebuffer[16];
} rests;
int  fd_rw;
int  size;
char buffer[300];
int  _res1;
int  return_code;
int  _res2[3];
struct sifcmd_RPC_DATA_QUEUE _dq;
struct sifcmd_RPC_SERVER_DATA _sd;
int  _svrbuf[274];
int  return_result;
int  _res3[3];
struct sifcmd_RPC_DATA_QUEUE  _dq_;
struct sifcmd_RPC_SERVER_DATA _sd_;
int  _svrbuf_[64];

//////////////////////////////entrypoint///////////////////////////////
int  start(){
     struct ThreadParam	threadParam;
     register int	*v;
     register int	thid;
	FlushDcache();						//loadcore

	if (v=QueryBootMode(3)){				//loadcore
		if (v[1] & 1){
			printf(" No SIF service(fileio)\n");	//stdio
			return 1;
		}
		if (v[1] & 2){
			printf(" No FILEIO service\n");		//stdio
			return 1;
		}
	}
	CpuEnableIntr();					//intrman
	threadParam.entry	= thread_entry_fileio;
	threadParam.attr 	= 0x2000000;
	threadParam.initPriority= 96;			//0x60
	threadParam.stackSize	= 0x1000;
	threadParam.option	= 0;
	if ((thid=CreateThread(&threadParam))<=0)		//thbase
		return 1;
	StartThread(thid, 0);					//thbase
	threadParam.entry	= thread_entry_iopheap;
	threadParam.attr 	= 0x2000000;
	threadParam.initPriority= 96;			//0x60
	threadParam.stackSize	= 0x800;
	threadParam.option	= 0;
	if ((thid=CreateThread(&threadParam))<=0)		//thbase
		return 1;
	StartThread(thid, 0);					//thbase
	return 0;
}

///////////////////////////////////////////////////////////////////////
int rw_alloc(){
    register int i;
	size=0x4000;	// internal buffer has 16KB;
			// any read/write is performed in chunks of 16KB
	for (i=0; i<8; i++){
		if (fd_rw=AllocSysMemory(1, size, 0)){		//sysmem
			printf("read/write allocate memory %x\n", size);//stdio
			break;
		}
		size=(size + ((unsigned)size >> 31))>>1;
	}
	return fd_rw;
}

///////////////////////////////////////////////////////////////////////
void _open(struct fileio_OPEN *d, int a1, int *result){
	if ((result==0) && ((result=rw_alloc())==0)){
		printf("Error:Cannot alloc r/w buffer\n");	//stdio
		*result=-1;
	}

	printf("open name %s flag %x data %x\n", d->name, d->mode, d);//stdio
	printf("open fd = %d\n", *result=open(d->name, d->mode));//stdio,ioman
}

///////////////////////////////////////////////////////////////////////
void _close(int *fd, int a1, int *result){
	*result=close(*fd);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _lseek(struct fileio_LSEEK *l, int a1, int *result){
	*result=lseek(l->fd, l->offset, l->ref);		//ioman
}

///////////////////////////////////////////////////////////////////////
void _read(struct fileio_READ *r, int a1, int *result){
     register int srest;			//s6 start_rest
     register int erest;			//s7 end_rest
     register int asize;			//s2 aligned size=end-start
     register int abuffer;			//s3 aligned start
     register int rlen;				//s0 length of data read
     register int total;			//s5
     register int readlen;			//s1 length to read
     register int status;			//s4 ?!?
     struct sifman_DMA_TRANSFER dmat;
     void *buffer;
     void *aebuffer;				//aligned end
     int x;

	total = 0;

	if (r->size < 16){
		srest = r->size;
		erest = asize = abuffer = 0;
		buffer = r->buffer;
		aebuffer = 0;
	}else{
		if (r->buffer & 0xF == 0)	//aligned
			srest=0;						
		else				//unaligned
			srest=((r->buffer >> 4) << 4) - r->buffer + 16;
		buffer = r->buffer;
		abuffer = r->buffer + srest;			//round up
		aebuffer=((r->buffer + r->size) >> 4) << 4;	//round down
		asize = aebuffer - abuffer;
		erest = r->buffer + r->size - aebuffer;			
	}
/******************************* -= EXAMPLE =- ************************
 buffer=0x159�����������������������������TO�READ���������ͻ
 size  =0x01D     0x150      �    0x160           0x170    �     0x180
       ...������������������������������������������������������������...
       ...          �        <�����ĺ������size����ĺ������>        � ...
       ...          �        <srest>�<����asize����>�<erest>        � ...
          ��MEMORY����������������������������������������������������
                                    �               �
                         abuffer�����               �����aebuffer
**********************************************************************/
	if (srest>0)
		if (srest!=(rlen=read(r->fd, rests.sbuffer, srest))){//ioman
			total += srest = (rlen>0 ? rlen:0);
			goto EXIT;
		else
			total += srest;
	}
	status=0;
	while (asize>0){
		readlen=MIN(size, asize);

		while(sceSifDmaStat(status)>=0);		//sifman

		rlen=read(r->fd, fd_rw, readlen);		//ioman
		if (readlen!=rlen){
			if (rlen<=0)goto EXIT;
			dmat.dest=abuffer;
			dmat.size=rlen;
			dmat.attr=0;
			dmat.src =fd_rw;
			CpuSuspendIntr(&x);			//intrman
			sceSifSetDma(&dmat, 1);			//sifman
			CpuResumeIntr(x);			//intrman
			total	+=rlen;
			goto EXIT;
		}else{			//read ok
			total   += rlen;
			asize   -=rlen;
			dmat.dest=abuffer;
			abuffer +=rlen;
			dmat.size=rlen;
			dmat.attr=0
			dmat.src =fd_rw;
			CpuSuspendIntr(&x);			//intrman
			status=sceSifSetDma(&dmat, 1);		//sifman
			CpuResumeIntr(x);			//intrman
	};
	if (erest>0)
		rlen = read(r->fd, rests.ebuffer, erest);	//ioman
		//total += (erest != rlen ? (rlen>0 ? rlen : 0) : erest);//this was the original stupid code
		total += (rlen>0 ? rlen : 0);
	}

EXIT:
	rests.rest.ssize=srest;           // size to write starting at ���ͻ
	rests.rest.esize=erest;           // size to write starting at ��Ŀ�
	rests.rest.sbuf =buffer;          //  <���������������������������ؼ
	rests.rest.ebuf =aebuffer;        //  <����������������������������
        dmat.src =&rests;
	dmat.size=sizeof(struct _rests);
	dmat.attr=0;
	dmat.dest=r->_intr_data;
	CpuSuspendIntr(&x);					//intrman
	sceSifSetDma(&dmat, 1)					//sifman
	CpuResumeIntr(x);					//intrman

	*result=total;
}

///////////////////////////////////////////////////////////////////////
void _write(struct fileio_WRITE *w, int a1, int *result){
     struct sifcmd_RPC_RECEIVE_DATA receive;
     register int left;			//s1
     register int wlen;			//v1
     register int writelen;		//s0
     int pos;

	if ((fd_rw==0) && ((fd_rw=rw_alloc())==0)){
		Kprintf("Error:Cannot alloc r/w buffer\n");	//sysmem
		*result=-1;
		return;
	}
	left  = w->size;
	total = 0;
	if (w->mis>0){           //FIXME: ?((char*)w+16)? is the structure longer?
		wlen=write(w->fd, ((char*)w+16), w->mis);	//ioman
		if (wlen != w->mis){
			if (wlen>0)
				total +=wlen;
			*result=total;
			return;
		}
		total +=wlen;
	}

	left-=w->mis;
	pos=w->buffer+w->mis;
	while(left){
		writelen = MIN(size, left);
		sceSifGetOtherData(&receive, pos, fd_rw, writelen, 0);//sifcmd
		wlen=write(w->fd, fd_rw, writelen);		//ioman
		if (wlen != writelen){
			if (wlen>0)
				total+=wlen;
			*result=total;
			return;
		}
		left -=writelen;
		pos  +=writelen;
		total+=writelen;
	}
	*result=total;
}

///////////////////////////////////////////////////////////////////////
void _ioctl(struct fileio_IOCTL *i, int a1, int *result){
	*result=ioctl(i->fd, i->io_code);			//ioman
}

///////////////////////////////////////////////////////////////////////
void _remove(char *name, int a1, int *result){
	printf("remove file %s \n", name);			//stdio
	*result=remove(name);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _mkdir(char *name, int a1, int *result){
	printf("mkdir name %s \n", name);			//stdio
	*result=mkdir(name);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _rmdir(char *name, int a1, int *result){
	printf("rmdir name %s \n", name);			//stdio
	*result=rmdir(name);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _format(char *name, int a1, int *result){
	printf("format name %s \n", name);			//stdio
	*result=format(name);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _AddDrv(struct fileio_DRIVER *d, int a1, int *result){
	printf("adddrv device addr %x\n", d->driver);		//stdio
	*result=AddDrv(d->driver);				//ioman
}

///////////////////////////////////////////////////////////////////////
void _DelDrv(char *name, int a1, int *result){
	printf("deldrv device name %s \n", name);		//stdio
	*result=DelDrv(name);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _dopen(char *name, int a1, int *result){
	printf("dopen name %s \n", name);			//stdio
	printf("dopen fd = %d\n", *result=dopen(name));		//stdio,ioman
}

///////////////////////////////////////////////////////////////////////
void _dclose(int *fd, int a1, int *result){
	*result=dclose(*fd);					//ioman
}

///////////////////////////////////////////////////////////////////////
void _dread(int *a0, int a1, int *result){
     struct sifman_DMA_TRANSFER	dmat;
     register int		r;
	if ((r=dread(a0[0], &buffer))>=0){			//ioman
		dmat.src =&buffer;
		dmat.dest=a0[1];
		dmat.size=300;
		dmat.attr=0;
		if (sceSifSetDma(&dmat, 1)==0)			//sifman
			r=-1;
	}
	*result=r;
}

///////////////////////////////////////////////////////////////////////
void _getstat(int *a0, int a1, int *result){
     struct sifman_DMA_TRANSFER	dmat;
     register int	r;
	if ((r=getstat(&a0[1], &buffer))>=0){			//ioman
		dmat.src =&buffer;
		dmat.dest=a0[0];
		dmat.size=40;
		dmat.attr=0;
		if (sceSifSetDma(&dmat, 1)==0)			//sifman
			r=-1;
	}
	*result=r;
}

///////////////////////////////////////////////////////////////////////
void _chstat(int *a0, int a1, int *result){
	*result=chstat(&a0[11], &a0[1], a0[0]);			//ioman
}

///////////////////////////////////////////////////////////////////////
int  *fileio_mt_80000001(int code, int param1, int param2){
	switch(code){
		case FILEIO_OPEN:   _open  (param1, param2, &return_code);break;
		case FILEIO_CLOSE:  _close (param1, param2, &return_code);break;
		case FILEIO_READ:   _read  (param1, param2, &return_code);break;
		case FILEIO_WRITE:  _write (param1, param2, &return_code);break;
		case FILEIO_LSEEK:  _lseek (param1, param2, &return_code);break;
		case FILEIO_IOCTL:  _ioctl (param1, param2, &return_code);break;
		case FILEIO_REMOVE: _remove(param1, param2, &return_code);		//BUG? they forgot to put a break here
		case FILEIO_MKDIR:  _mkdir (param1, param2, &return_code);break;
		case FILEIO_RMDIR:  _rmdir (param1, param2, &return_code);break;
		case FILEIO_DOPEN:  _dopen (param1, param2, &return_code);break;
		case FILEIO_DCLOSE: _dclose(param1, param2, &return_code);break;
		case FILEIO_DREAD:  _dread (param1, param2, &return_code);break;
		case FILEIO_GETSTAT:_getstat(param1, param2, &return_code);break;
		case FILEIO_CHSTAT: _chstat(param1, param2, &return_code);break;
		case FILEIO_FORMAT: _format(param1, param2, &return_code);break;
		case FILEIO_ADDDRV: _AddDrv(param1, param2, &return_code);break;
		case FILEIO_DELDRV: _DelDrv(param1, param2, &return_code);break;
		default:	printf("sce_fileio: unrecognized code %x\n", code);//stdio
	}
	return &return_code;
}

///////////////////////////////////////////////////////////////////////
int  thread_entry_fileio(){
	if (sceSifCheckInit()==0)				//sifman
		sceSifInit();					//sifman
	printf("Multi Threaded Fileio module.(99/11/15) \n");	//stdio
	result=0;
	sceSifInitRpc(0);					//sifcmd
	sceSifSetRpcQueue(&_dq, GetThreadId());			//sifcmd,thbase
	sceSifRegisterRpc(&_sd, 0x80000001, fileio_mt_80000001, &_svrbuf,//sifcmd
							     0,        0, &_dq);
	sceSifRpcLoop(&_dq);					//sifcmd
	return 0;
}

///////////////////////////////////////////////////////////////////////
void __3_sceSifLoadIopHeap(struct fileio_LOADIOPHEAP *lih, int b, int *result){
     register int fd;
     register int fsize;
	if ((fd=open(lih->name, 1))<0){				//ioman
		printf("load heap :error \n");			//stdio
		*result = -1;
	}
	fsize=lseek(fd, 0, 2);					//ioman
	lseek(fd, 0, 0);					//ioman
	read(fd, lih->buffer, fsize);	//read whole file	//ioman
	close(fd);						//ioman
	*result=0;
}

///////////////////////////////////////////////////////////////////////
void __1_sceSifAllocIopHeap(int *size, int b, int *result){
	*result=AllocSysMemory(0, *size, 0);			//sysmem
}

///////////////////////////////////////////////////////////////////////
void __2_sceSifFreeIopHeap(int *handle, int b, int *result){
	*result=FreeSysMemory(*handle);				//sysmem
}

///////////////////////////////////////////////////////////////////////
int  *iopmem_80000003(int code, int param1, int param2){
	if (code == IOPHEAP_FREE)
		__2_sceSifFreeIopHeap(param1, param2, &return_result);
	else
	if (code == IOPHEAP_LOAD)
		__3_sceSifLoadIopHeap(param1, param2, &return_result);
	else
	if (code == IOPHEAP_ALLOC)
		__1_sceSifAllocIopHeap(param1, param2, &return_result);
	else
		printf("sce_iopmem: unrecognized code %x\n", code);//stdio
	return &return_result;
}

///////////////////////////////////////////////////////////////////////
int  thread_entry_iopheap(){
	if (sceSifCheckInit()==0)				//sifman
		sceSifInit();					//sifman
	printf("iop heap service (99/11/03)\n");		//stdio
	result=0;
	sceSifInitRpc(0);					//sifcmd
	sceSifSetRpcQueue(&_dq_, GetThreadId());		//sifcmd,thbase
	sceSifRegisterRpc(&_sd_, 0x80000003, iopmem_80000003, &_svrbuf_,//sifcmd
							     0,        0, &_dq_);
	sceSifRpcLoop(&_dq);					//sifcmd
	return 0;
}
