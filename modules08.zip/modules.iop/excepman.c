//[module]	EXCEPMAN
//[processor]	IOP
//[type]	ELF-IRX
//[size]	3033(0xBD9)
//[bios]	10000(0x21FD0-0x22BB0)
//[iopboot]	02
//[loaded @]	00003430-00003D00
//[name]	Exception_Manager
//[version]	0x101
//[memory map]	0x400->
//[handlers]	-
//[entry point]	excepman_start, excepman_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com) 2003-03-05

#include "..\include\sysmem.h"		//(0x101,AllocSysMemory)
#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries)

#define LWK00K0	0x8F5A0000	//lw $k0, 0($k0)
#define LWK10K1	0x8F7B0000	//lw $k1, 0($k1)

struct excepman_EH *common, *handlers[16], *default, list={0, 0};

//////////////////////////////entrypoint///////////////////////////////[00]
int excepman_start(){
	register int *src, *dst, i;

	for (i=15; i>=0; i--)
		handlers[i]=0;
	default=0;
	allocPage();
	common=0x440;

//lw      $k0, 0x440($k0)	//8F5A0440
//lw      $k1, 0x440($k1)	//8F7B0440
	for (src=&thebegginning, dst=0; src<&defaultEH; src++, dst++)
		*dst=*src | ((*src==LWK00K0) || (*src==LWK10K1) ? common : 0);

	RegisterDefaultExceptionHandler(&defaultEH);
	RegisterLibraryEntries(&excepman_stub);
	return 0;
}

///////////////////////////////////////////////////////////////////////[02]
int excepman_deinit(){
	return 0;
}

///////////////////////////////////////////////////////////////////////[01]
int excepman_reinit{
	excepman_deinit();
	return excepman_start();
}

///////////////////////////////////////////////////////////////////////[04]
int RegisterExceptionHandler(int code, void (*handler)()){
	return RegisterPriorityExceptionHandler(code, 2, handler);
}

///////////////////////////////////////////////////////////////////////[05]
int RegisterPriorityExceptionHandler(int code, int priority, void (*handler)()){
	struct excepman_EH	*n, *p;

	if (handler->next)	return ERROR_USED_EXCODE;
	if (code>=16)		return ERROR_BAD_EXCODE;

	priority &= 3;
	n=unlink();
	p=&handlers[code];

	n->info=(0xFFFFFFFC & handler) | priority;

	while (p->next && ((p->next->info & 3) < priority)))
		p=p->next;

	n->next=p->next;
	p->next=n;

	register();
	return 0;
}

///////////////////////////////////////////////////////////////////////[06]
int RegisterDefaultExceptionHandler(void (*handler)()){
	if (handler->next)	return ERROR_USED_EXCODE;
	
	handler->next=default;
	default=&handler->function;

	register();
	return 0;
}

///////////////////////////////////////////////////////////////////////[07]
int ReleaseExceptionHandler(int code, void (*handler)()){
	if (code>=16)	return ERROR_BAD_EXCODE;

	for (p=&handlers[code]; p->next; p=a;){
		a=p->next;
		if (a->info & 0xFFFFFFFC == handler){
			p->next=a->next;
			*(a->info & 0xFFFFFFFC)=0;
			link(a);
			register();
			return 0;
		}
	}
	return	ERROR_EXCODE_NOTFOUND;
}

///////////////////////////////////////////////////////////////////////[08]
int ReleaseDefaultExceptionHandler(void (*handler)()){
	for (a1=&default; a1->next; a1=a1->next-8)
		if (a1->next==&handler->func){
			a1->next=handler->next;
			handler->next=0;
			register();
			return 0;
		}
	return ERROR_EXCODE_NOTFOUND;
}

///////////////////////////////////////////////////////////////////////[03]
void *excepman_getcommon(){
	return &common;
}

///////////////////////////////////////////////////////////////////////
void register(){
	register int i;

	for (i=0; i<16; i++)
		if (a0=handlers[i]){
			for ( ; a0->next; a0=a0->next)
				(a0->info & 0xFFFFFFFC)->next=
					(a0->next->info & 0xFFFFFFFC) + 8;
			(a0->info & 0xFFFFFFFC)->next=default;
		}
	for (i=0; i<16; i++)
		if (handlers[i]==0)
			common[i]=default;
		else
			common[i]=(handlers[i]->info & 0xFFFFFFFC)+8;
}

///////////////////////////////////////////////////////////////////////
int unlink(){
	int r;
	if (list==0)	allocPage();
	if (r=list)	list=r->next;
	return r;
}

///////////////////////////////////////////////////////////////////////
void link(int a){
	a->next=list;
	list=a;
}

///////////////////////////////////////////////////////////////////////
void allocPage(){
	register int i;

	list=AllocSysMemory(0, 0x100, 0);
	for (i=0; i<31; i++)
		list[i].next=&list[i+1];
	list[i]->next=0;
}

///////////////////////////////////////////////////////////////////////
///////////////////// 2b copied to 0x00000000 /////////////////////////
///////////////////////////////////////////////////////////////////////
thebegginning:
00000000:                nop
00000004:                nop
00000008:                nop
0000000C:                nop
00000010:                break    #0x400
00000014:                break    #0x400
00000018:                break    #0x400
0000001C:                break    #0x400
00000020:                break    #0x400
00000024:                break    #0x400
00000028:                break    #0x400
0000002C:                break    #0x400
00000030:                break    #0x400
00000034:                break    #0x400
00000038:                break    #0x400
0000003C:                break    #0x400
//////////////////////////////////////////////////////////////////////////
//////////////////////////// sub_00000040 ////////////////////////////////
00000040:		sw      $k0, first._k0($0)	//first._k0=k0;
00000044:		mfc0    $k1, EPC
00000048:		mfc0    $k0, Cause
0000004C:		sw      $k1, first._EPC($0)	//first._EPC=cop0.EPC
00000050:		sw      $k0, first._Cause($0)	//first._Cause=cop0.Cause
00000054:		mfc0    $k1, SR
00000058:		mfc0    $k0, $7
0000005C:		sw      $k1, first._SR($0)	//first._SR=cop0.SR
00000060:		sw      $k0, first.cop0_7($0)	//first.cop0_7=cop0.$7
00000064:		li      $k1, 0x3C
00000068:		lw      $k1, 0($k1)      	//lw $k1, 0x440($k1) //patched by copy routine
0000006C:		mtc0    $0, $7
00000070:		jr      $k1			//[0x440 + 0x3C]();
00000074:		nop
//////////////////////////////////////////////////////////////////////////
00000078:		nop
0000007C:		nop
//////////////////////////////////////////////////////////////////////////
//////////////////////////// sub_00000080 ////////////////////////////////
00000080:		sw      $1, first.AT($0)	//first.AT=AT;
00000084:		sw      $k0, first.k0($0)	//first.k0=k0;
00000088:		mfc0    $k0, EPC
0000008C:		mfc0    $1, SR
00000090:		sw      $k0, first.EPC($0)	//first.EPC=cop0.EPC;
00000094:		sw      $1, first.SR($0)	//first.SR =cop0.SR;
00000098:		mfc0    $k0, Cause
0000009C:		nop
000000A0:		sw      $k0, first.Cause($0)	//first.Cause=cop0.Cause
000000A4:		andi    $k0, 0x3C
000000A8:		lw      $k0, 0($k0)		//lw $k0, 0x440($k0) //patched by copy routine
000000AC:		nop
000000B0:		jr      $k0			//[0x440 + Cause & 0x3C]();
000000B4:		nop
//////////////////////////////////////////////////////////////////////////
000000B8:		nop
000000BC:		nop
000000C0:		nop
000000C4:		nop
000000C8:		nop
000000CC:		nop
//////////////////////////////////////////////////////////////////////////
struct link defaultEH={0, 0};
void        defaultEHfunc(){
		defaultEHfunc();
}

//////////////////////////////entrypoint///////////////////////////////
struct export excepman_stub={
	0x41C00000,
	0,
	VER(1, 1),	// 1.1 => 0x101
	0,
	"excepman",
	(func)excepman_start,	// entrypoint
	(func)excepman_reinit,
	(func)excepman_deinit,
	(func)excepman_getcommon,
	(func)RegisterExceptionHandler,
	(func)RegisterPriorityExceptionHandler,
	(func)RegisterDefaultExceptionHandler,
	(func)ReleaseExceptionHandler,
	(func)ReleaseDefaultExceptionHandler,
	0
};

/*************************************** iopmem struct placed @ 0x400
0400 first           struc  # (sizeof=0x40)
0400 AT:             .word ?
0404 EPC:            .word ?
0408 SR:             .word ?
040C Cause:          .word ?
0410 k0:             .word ?
0414 field_14:       .word ?
0418 field_18:       .word ?
041C field_1C:       .word ?
0420 _k0:            .word ?
0424 _EPC:           .word ?
0428 _Cause:         .word ?
042C _SR:            .word ?
0430 cop0_7:         .word ?
0434 field_34:       .word ?
0438 field_38:       .word ?
043C field_3C:       .word ?
0440 first           ends
******************************************/
