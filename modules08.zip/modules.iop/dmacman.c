//[module]	DMACMAN
//[processor]	IOP
//[type]	ELF-IRX
//[size]	14069(0x36F5)
//[bios]	10000(0x28380-0x2BA80)
//[iopboot]	06
//[loaded @]	00006000-00007D00
//[name]	dmacman
//[version]	0x101
//[memory map]	0xBF801080,0xBF801084,0xBF801088,		00 mdec in
//		0xBF801090,0xBF801094,0xBF801098,		01 mdec out
//		0xBF8010A0,0xBF8010A4,0xBF8010A8,		02 gpu
//		0xBF8010B0,0xBF8010B4,0xBF8010B8,		03 cdrom/dvd
//		0xBF8010C0,0xBF8010C4,0xBF8010C8, 0xBF8010CC,	04 spu
//		0xBF8010D0,0xBF8010D4,0xBF8010D8,		05 pio
//		0xBF8010E0,0xBF8010E4,0xBF8010E8,		06 gpu otc
//  
//		0xBF8010F0,0xBF8010F4,
//
//		0xBF801500,0xBF801504,0xBF801508,		07 SPU2
//		0xBF801510,0xBF801514,0xBF801518,		08 
//		0xBF801520,0xBF801524,0xBF801528, 0xBF80152C,	09 SIF0
//		0xBF801530,0xBF801534,0xBF801538,		10 SIF1
//		0xBF801540,0xBF801544,0xBF801548,		11 SIO2in
//		0xBF801550,0xBF801554,0xBF801558,		12 SIO2out
//
//		0xBF801560,0xBF801564,0xBF801568,		   //sifman
//                    sif0	sif1	   spu
//
//		0xBF801570, 0xBF801574,0xBF801578,0xBF80157C,	   //sifman
//		0xBF8015F0
//[handlers]	-
//[entry point]	dmacman_start, dmacman_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\sysmem.h"		//(0x101,Kprintf)
#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries)
#include "..\include\intrman.h"		//(0x102,CpuSuspendIntr,CpuResumeIntr)

#include "..\include\dmacman.h"

func setD_MADR[]={_setBF801080, _setBF801090, _setBF8010A0, _setBF8010B0,
		  _setBF8010C0, _setBF8010D0, _setBF8010E0,
		  _setBF801500, _setBF801510, _setBF801520,
		  _setBF801530, _setBF801540, _setBF801550,	0
};

func getD_MADR[]={_getBF801080, _getBF801090, _getBF8010A0, _getBF8010B0,
		  _getBF8010C0, _getBF8010D0, _getBF8010E0,
		  _getBF801500, _getBF801510, _getBF801520,
		  _getBF801530, _getBF801540, _getBF801550,	0
};

func setD_BCR[]={_setBF801084, _setBF801094, _setBF8010A4, _setBF8010B4,
		 _setBF8010C4, _setBF8010D4, _setBF8010E4,
		 _setBF801504, _setBF801514, _setBF801524,
		 _setBF801534, _setBF801544, _setBF801554,	0
};

func getD_BCR[]={_getBF801084, _getBF801094, _getBF8010A4, _getBF8010B4,
		 _getBF8010C4, _getBF8010D4, _getBF8010E4,
		 _getBF801504, _getBF801514, _getBF801524,
		 _getBF801534, _getBF801544, _getBF801554,	0
};

func setD_CHCR[]={_setBF801088, _setBF801098, _setBF8010A8, _setBF8010B8,
		  _setBF8010C8, _setBF8010D8, _setBF8010E8,
		  _setBF801508, _setBF801518, _setBF801528,
		  _setBF801538, _setBF801548, _setBF801558,	0
};

func getD_CHCR[]={_getBF801088, _getBF801098, _getBF8010A8, _getBF8010B8,
		  _getBF8010C8, _getBF8010D8, _getBF8010E8,
		  _getBF801508, _getBF801518, _getBF801528,
		  _getBF801538, _getBF801548, _getBF801558,	0
};

///////////////////////////////////////////////////////////////////////
void dmacman_call4_SetD_MADR(unsigned int ch, int value){
	if (ch<13)
		setD_MADR[ch](ch, value);	//function call
}

///////////////////////////////////////////////////////////////////////
void _setBF801080(unsigned int ch, int value){
	*(int*)0xBF801080=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801090(unsigned int ch, int value){
	*(int*)0xBF801090=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010A0(unsigned int ch, int value){
	*(int*)0xBF8010A0=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010B0(unsigned int ch, int value){
	*(int*)0xBF8010B0=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010C0(unsigned int ch, int value){
	*(int*)0xBF8010C0=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010D0(unsigned int ch, int value){
	*(int*)0xBF8010D0=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010E0(unsigned int ch, int value){
	*(int*)0xBF8010E0=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801500(unsigned int ch, int value){
	*(int*)0xBF801500=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801510(unsigned int ch, int value){
	*(int*)0xBF801510=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801520(unsigned int ch, int value){
	*(int*)0xBF801520=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801530(unsigned int ch, int value){
	*(int*)0xBF801530=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801540(unsigned int ch, int value){
	*(int*)0xBF801540=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801550(unsigned int ch, int value){
	*(int*)0xBF801550=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call5_GetD_MADR(unsigned int ch){
	if (ch<13)
		return getD_MADR[ch](ch);	//function call
	return 0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801080(unsigned int ch){
	return *(int*)0xBF801080;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801090(unsigned int ch){
	return *(int*)0xBF801090;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010A0(unsigned int ch){
	return *(int*)0xBF8010A0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010B0(unsigned int ch){
	return *(int*)0xBF8010B0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010C0(unsigned int ch){
	return *(int*)0xBF8010C0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010D0(unsigned int ch){
	return *(int*)0xBF8010D0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010E0(unsigned int ch){
	return *(int*)0xBF8010E0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801500(unsigned int ch){
	return *(int*)0xBF801500;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801510(unsigned int ch){
	return *(int*)0xBF801510;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801520(unsigned int ch){
	return *(int*)0xBF801520;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801530(unsigned int ch){
	return *(int*)0xBF801530;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801540(unsigned int ch){
	return *(int*)0xBF801540;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801550(unsigned int ch){
	return *(int*)0xBF801550;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call6_SetD_BCR(unsigned int ch, int value){
	if (ch<13)
		setD_BCR[ch](ch, value);	//function call
}

///////////////////////////////////////////////////////////////////////
void _setBF801084(unsigned int ch, int value){
	*(int*)0xBF801084=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801094(unsigned int ch, int value){
	*(int*)0xBF801094=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010A4(unsigned int ch, int value){
	*(int*)0xBF8010A4=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010B4(unsigned int ch, int value){
	*(int*)0xBF8010B4=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010C4(unsigned int ch, int value){
	*(int*)0xBF8010C4=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010D4(unsigned int ch, int value){
	*(int*)0xBF8010D4=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010E4(unsigned int ch, int value){
	*(int*)0xBF8010E4=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801504(unsigned int ch, int value){
	*(int*)0xBF801504=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801514(unsigned int ch, int value){
	*(int*)0xBF801514=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801524(unsigned int ch, int value){
	*(int*)0xBF801524=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801534(unsigned int ch, int value){
	*(int*)0xBF801534=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801544(unsigned int ch, int value){
	*(int*)0xBF801544=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801554(unsigned int ch, int value){
	*(int*)0xBF801554=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call7_GetD_BCR(unsigned int ch){
	if (ch<13)
		return getD_BCR[ch](ch);	//function call
	return 0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801084(unsigned int ch){
	return *(int*)0xBF801084;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801094(unsigned int ch){
	return *(int*)0xBF801094;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010A4(unsigned int ch){
	return *(int*)0xBF8010A4;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010B4(unsigned int ch){
	return *(int*)0xBF8010B4;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010C4(unsigned int ch){
	return *(int*)0xBF8010C4;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010D4(unsigned int ch){
	return *(int*)0xBF8010D4;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010E4(unsigned int ch){
	return *(int*)0xBF8010E4;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801504(unsigned int ch){
	return *(int*)0xBF801504;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801514(unsigned int ch){
	return *(int*)0xBF801514;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801524(unsigned int ch){
	return *(int*)0xBF801524;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801534(unsigned int ch){
	return *(int*)0xBF801534;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801544(unsigned int ch){
	return *(int*)0xBF801544;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801554(unsigned int ch){
	return *(int*)0xBF801554;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call8_SetD_CHCR(unsigned int ch, int value){
	if (ch<13)
		setD_CHCR[ch](ch, value);	//function call
}

///////////////////////////////////////////////////////////////////////
void _setBF801088(unsigned int ch, int value){
	*(int*)0xBF801088=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801098(unsigned int ch, int value){
	*(int*)0xBF801098=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010A8(unsigned int ch, int value){
	*(int*)0xBF8010A8=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010B8(unsigned int ch, int value){
	*(int*)0xBF8010B8=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010C8(unsigned int ch, int value){
	*(int*)0xBF8010C8=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010D8(unsigned int ch, int value){
	*(int*)0xBF8010D8=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF8010E8(unsigned int ch, int value){
	*(int*)0xBF8010E8=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801508(unsigned int ch, int value){
	*(int*)0xBF801508=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801518(unsigned int ch, int value){
	*(int*)0xBF801518=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801528(unsigned int ch, int value){
	*(int*)0xBF801528=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801538(unsigned int ch, int value){
	*(int*)0xBF801538=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801548(unsigned int ch, int value){
	*(int*)0xBF801548=value;
}

///////////////////////////////////////////////////////////////////////
void _setBF801558(unsigned int ch, int value){
	*(int*)0xBF801558=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call9_GetD_CHCR(unsigned int ch){
	if (ch<13)
		return getD_CHCR[ch](ch);	//function call
	return 0;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801088(unsigned int ch){
	return *(int*)0xBF801088;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801098(unsigned int ch){
	return *(int*)0xBF801098;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010A8(unsigned int ch){
	return *(int*)0xBF8010A8;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010B8(unsigned int ch){
	return *(int*)0xBF8010B8;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010C8(unsigned int ch){
	return *(int*)0xBF8010C8;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010D8(unsigned int ch){
	return *(int*)0xBF8010D8;
}

///////////////////////////////////////////////////////////////////////
int  _getBF8010E8(unsigned int ch){
	return *(int*)0xBF8010E8;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801508(unsigned int ch){
	return *(int*)0xBF801508;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801518(unsigned int ch){
	return *(int*)0xBF801518;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801528(unsigned int ch){
	return *(int*)0xBF801528;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801538(unsigned int ch){
	return *(int*)0xBF801538;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801548(unsigned int ch){
	return *(int*)0xBF801548;
}

///////////////////////////////////////////////////////////////////////
int  _getBF801558(unsigned int ch){
	return *(int*)0xBF801558;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call10_SetD_TADR(unsigned int ch, int value){
	if (ch==DMAch_SPU)
		*(int*)0xBF8010CC=value;	else
	if (ch==DMAch_SIF0)
		*(int*)0xBF80152C=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call11_GetD_TADR(unsigned int ch){
	if (ch==DMAch_SPU)
		return *(int*)0xBF8010CC;
	if (ch==DMAch_SIF0)
		return *(int*)0xBF80152C;
	return 0;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call12_Set_4_9_A(unsigned int ch, int value){
	if (ch==DMAch_SPU)
		*(int*)0xBF801568=value;	else
	if (ch==DMAch_SIF0)
		*(int*)0xBF801560=value;	else
	if (ch==DMAch_SIF1)
		*(int*)0xBF801564=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call13_Get_4_9_A(unsigned int ch){
	if (ch==DMAch_SPU)
		return *(int*)0xBF801568;
	if (ch==DMAch_SIF0)
		return *(int*)0xBF801560;
	if (ch==DMAch_SIF1)
		return *(int*)0xBF801564;
	return 0;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call14_SetDPCR(int value){
	*(int*)0xBF8010F0=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call15_GetDPCR(){
	return *(int*)0xBF8010F0;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call16_SetDPCR2(int value){
	*(int*)0xBF801570=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call17_GetDPCR2(){
	return *(int*)0xBF801570;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call18_SetDPCR3(int value){
	*(int*)0xBF8015F0=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call19_GetDPCR3(){
	return *(int*)0xBF8015F0;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call20_SetDICR(int value){
	*(int*)0xBF8010F4=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call21_GetDICR(){
	return *(int*)0xBF8010F4;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call22_SetDICR2(int value){
	*(int*)0xBF801574=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call23_GetDICR2(){
	return *(int*)0xBF801574;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call24_SetBF80157C(int value){
	*(int*)0xBF80157C=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call25_GetBF80157C(){
	return *(int*)0xBF80157C;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call26_SetBF801578(int value){
	*(int*)0xBF801578=value;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call27_GetBF801578(){
	return *(int*)0xBF801578;
}

// Note: it is not a true extern variable
// it only allows me to use dmacman_stub reference in 'start' function
extern struct export dmacman_stub;

//////////////////////////////entrypoint///////////////////////////////
int  dmacman_start(int argc, char* argv[]){
     int x;
     register int ch;

	if (RegisterLibraryEntries(&dmacman_stub))		//loadcore
		return 1;

	CpuSuspendIntr(&x);					//intrman

	dmacman_call14_SetDPCR(0x07777777);
	dmacman_call16_SetDPCR2(0x07777777);
	dmacman_call18_SetDPCR3(0x00000777);
	for (ch=0; ch<13; ch++){
		dmacman_call4_SetD_MADR(ch, 0);
		dmacman_call6_SetD_BCR (ch, 0);
		dmacman_call8_SetD_CHCR(ch, 0);
	}
	dmacman_call10_SetD_TADR( DMAch_SPU, 0);
	dmacman_call10_SetD_TADR( DMAch_SIF0,0);
	dmacman_call12_Set_4_9_A( DMAch_SPU, 0);
	dmacman_call12_Set_4_9_A( DMAch_SIF0,0);
	dmacman_call12_Set_4_9_A( DMAch_SIF1,0);
	dmacman_call26_setBF801578(1);

	CpuResumeIntr(x);					//intrman
	return 0;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_deinit(){
     int x;
     register int ch, value;

	CpuSuspendIntr(&x);					//intrman

	dmacman_call26_setBF801578(0);
	for (ch=0; ch<13; ch++){
		value=dmacman_call9_GetD_CHCR(ch);
		if (value & DMAf_TR)				//sysmem
			Kprintf("WARNING:DMA %dch has been continued until shutdown\n", ch);
		dmacman_call8_SetD_CHCR(ch, value & 0xFEFFFFFF);
	}

	CpuResumeIntr(x);					//intrman
	return 1;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call28_SetDMA(int ch, int address, int size, int count, int dir){
	if (ch<13 && ch != DMAch_GPUotc){
		dmacman_call4_SetD_MADR(ch, 0x00FFFFFF & address);
		dmacman_call6_SetD_BCR (ch, (count << 16) | (size & 0xFFFF));
		dmacman_call8_SetD_CHCR(ch, (dir & DMAf_DR) | DMAf_CO |
						(dir == 0 ? DMAf_30 : 0));
		return 1;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call29_SetDMA_chainedSPU_SIF0(int ch, int size, int tadr){
	if (ch != DMAch_SPU && ch != DMAch_SIF0)
		return 0;
	dmacman_call6_SetD_BCR (ch, size & 0x0000FFFF);
	dmacman_call8_SetD_CHCR(ch, DMAf_LI | DMAf_CO | DMAf_DR);	//0x601
	dmacman_call10_SetD_TADR (ch, tadr & 0x00FFFFFF);
	return 1;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call30_SetDMA_SIF0(int ch, int size, int tadr){
	if (ch != DMAch_9)
		return 0;
	dmacman_call6_SetD_BCR ( DMAch_9, size & 0x0000FFFF)
	dmacman_call8_SetD_CHCR( DMAch_9, DMAf_LI | DMAf_CO | DMAf_08 | DMAf_DR); //0x701
	dmacman_call10_SetD_TADR ( DMAch_9, tadr & 0x00FFFFFF);
	return 1;
}

///////////////////////////////////////////////////////////////////////
int  dmacman_call31_SetDMA_SIF1(int ch, int size){
	if (ch != DMAch_10)
		return 0;
	dmacman_call6_SetD_BCR (DMAch_10, size & 0x0000FFFF);
	dmacman_call8_SetD_CHCR(DMAch_10, DMAf_30 | DMAf_CO | DMAf_08); //0x40000300
	return 1;
}

///////////////////////////////////////////////////////////////////////
void dmacman_call32_StartTransfer(int ch){
	if (ch < 15)
		dmacman_call8_SetD_CHCR(ch, DMAf_TR | dmacman_call9_GetD_CHCR(ch));
}

///////////////////////////////////////////////////////////////////////
// set 3-bit value of channel
void dmacman_call33_SetVal(int ch, int value){
     int x;
	CpuSuspendIntr(&x);					//intrman

	switch (ch){
	case DMAch_MDECin: dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xFFFFFFF8) |
		(        value                &          7));		break;
	case DMAch_MDECout:dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xFFFFFF8F) |
		((       value                &          7) <<  4));	break;
	case DMAch_GPU: dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xFFFFF8FF) |
		((       value                &          7) <<  8));	break;
	case DMAch_CD:  dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xFFFF8FFF) |
		((       value                &          7) << 12));	break;
	case DMAch_SPU: dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xFFF8FFFF) |
		((       value                &          7) << 16));	break;
	case DMAch_PIO: dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xFF8FFFFF) |
		((       value                &          7) << 20));	break;
	case DMAch_GPUotc:dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0xF8FFFFFF) |
		((       value                &          7) << 24));	break;
	case DMAch_SPU2:dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xFFFFFFF8) |
		(        value                &          7));		break;
	case DMAch_8: dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xFFFFFF8F) |
		((       value                &          7) <<  4));	break;
	case DMAch_SIF0: dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xFFFFF8FF) |
		((       value                &          7) <<  8));	break;
	case DMAch_SIF1: dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xFFFF8FFF) |
		((       value                &          7) << 12));	break;
	case DMAch_SIO2in: dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xFFF8FFFF) |
		((       value                &          7) << 16));	break;
	case DMAch_SIO2out:dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xFF8FFFFF) |
		((       value                &          7) << 20));	break;
	case DMAch_13: dmacman_call18_SetDPCR3(
		(dmacman_call19_GetDPCR3() & 0xFFFFFFF8) |
		(        value                &          7));		break;
	case DMAch_14: dmacman_call18_SetDPCR3(
		(dmacman_call19_GetDPCR3() & 0xFFFFFF8F) |
		((       value                &          7) <<  4));	break;
	case DMAch_15: dmacman_call18_SetDPCR3(
		(dmacman_call19_GetDPCR3() & 0xFFFFF8FF) |
		((       value                &          7) <<  8));	break;
	case DMAch_67: dmacman_call14_SetDPCR(
		(dmacman_call15_GetDPCR() & 0x8FFFFFFF) |
		((       value                &          7) << 28));	break;
	case DMAch_85: dmacman_call16_SetDPCR2(
		(dmacman_call17_GetDPCR2() & 0xF8FFFFFF) |
		((       value                &          7) << 24));	break;
	}

	CpuResumeIntr(x);					//intrman
}

///////////////////////////////////////////////////////////////////////
// set 4th bit of channel
void dmacman_call34_EnableDMAch(int ch){
     int x;
	CpuSuspendIntr(&x);					//intrman

	switch (ch){
	case DMAch_MDECin: dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x00000008));	break;
	case DMAch_MDECout:dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x00000080));	break;
	case DMAch_GPU:  dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x00000800));	break;
	case DMAch_CD:   dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x00008000));	break;
	case DMAch_SPU:  dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x00080000));	break;
	case DMAch_PIO:  dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x00800000));	break;
	case DMAch_GPUotc:dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() | 0x08000000));	break;
	case DMAch_SPU2: dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x00000008));	break;
	case DMAch_8:    dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x00000080));	break;
	case DMAch_SIF0: dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x00000800));	break;
	case DMAch_SIF1: dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x00008000));	break;
	case DMAch_SIO2in:dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x00080000));	break;
	case DMAch_SIO2out:dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x00800000));	break;
	case DMAch_13:   dmacman_call18_SetDPCR3(
			(dmacman_call19_GetDPCR3() | 0x00000008));	break;
	case DMAch_14:   dmacman_call18_SetDPCR3(
			(dmacman_call19_GetDPCR3() | 0x00000080));	break;
	case DMAch_15:   dmacman_call18_SetDPCR3(
			(dmacman_call19_GetDPCR3() | 0x00000800));	break;
	case DMAch_85:   dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() | 0x08000000));	break;
	}

	CpuResumeIntr(x);					//intrman
}

///////////////////////////////////////////////////////////////////////
// reset 4th bit of channel
void dmacman_call35_DisableDMAch(int ch){
     int x;
	CpuSuspendIntr(&x);					//intrman

	switch (ch){
	case DMAch_MDECin: dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xFFFFFFF7));	break;
	case DMAch_MDECout:dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xFFFFFF7F));	break;
	case DMAch_GPU:  dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xFFFFF7FF));	break;
	case DMAch_CD:   dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xFFFF7FFF));	break;
	case DMAch_SPU:  dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xFFF7FFFF));	break;
	case DMAch_PIO:  dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xFF7FFFFF));	break;
	case DMAch_GPUotc:dmacman_call14_SetDPCR(
			(dmacman_call15_GetDPCR() & 0xF7FFFFFF));	break;
	case DMAch_SPU2: dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xFFFFFFF7));	break;
	case DMAch_8:    dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xFFFFFF7F));	break;
	case DMAch_SIF0: dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xFFFFF7FF));	break;
	case DMAch_SIF1: dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xFFFF7FFF));	break;
	case DMAch_SIO2in:dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xFFF7FFFF));	break;
	case DMAch_SIO2out:dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xFF7FFFFF));	break;
	case DMAch_13:   dmacman_call18_SetDPCR3(
			(dmacman_call19_GetDPCR3() & 0xFFFFFFF7));	break;
	case DMAch_14:   dmacman_call18_SetDPCR3(
			(dmacman_call19_GetDPCR3() & 0xFFFFFF7F));	break;
	case DMAch_15:   dmacman_call18_SetDPCR3(
			(dmacman_call19_GetDPCR3() & 0xFFFFF7FF));	break;
	case DMAch_85:   dmacman_call16_SetDPCR2(
			(dmacman_call17_GetDPCR2() & 0xF7FFFFFF));	break;
	}

	CpuResumeIntr(x);					//intrman
}

//////////////////////////////entrypoint///////////////////////////////
struct export dmacman_stub={
	0x41C00000,
	0,
	VER(1, 2),	// 1.2 => 0x102
	0,
	"dmacman",
	(func)dmacman_start,	// entrypoint
	(func)retonly,
	(func)dmacman_deinit,
	(func)retonly,
	(func)dmacman_call4_SetD_MADR,
	(func)dmacman_call5_GetD_MADR,
	(func)dmacman_call6_SetD_BCR,
	(func)dmacman_call7_GetD_BCR,
	(func)dmacman_call8_SetD_CHCR,
	(func)dmacman_call9_GetD_CHCR,
	(func)dmacman_call10_SetD_TADR,
	(func)dmacman_call11_GetD_TADR,
	(func)dmacman_call12_Set_4_9_A,
	(func)dmacman_call13_Get_4_9_A,
	(func)dmacman_call14_SetDPCR,
	(func)dmacman_call15_GetDPCR,
	(func)dmacman_call16_SetDPCR2,
	(func)dmacman_call17_GetDPCR2,
	(func)dmacman_call18_SetDPCR3,
	(func)dmacman_call19_GetDPCR3,
	(func)dmacman_call20_SetDICR,
	(func)dmacman_call21_GetDICR,
	(func)dmacman_call22_SetDICR2,
	(func)dmacman_call23_GetDICR2,
	(func)dmacman_call24_SetBF80157C,
	(func)dmacman_call25_GetBF80157C,
	(func)dmacman_call26_SetBF801578,
	(func)dmacman_call27_GetBF801578,
	(func)dmacman_call28_SetDMA,
	(func)dmacman_call29_SetDMA_chainedSPU_SIF0,
	(func)dmacman_call30_SetDMA_SIF0,
	(func)dmacman_call31_SetDMA_SIF1,
	(func)dmacman_call32_StartTransfer,
	(func)dmacman_call33_SetVal,
	(func)dmacman_call34_EnableDMAch,
	(func)dmacman_call35_DisableDMAch,
	0
};

void retonly(){}