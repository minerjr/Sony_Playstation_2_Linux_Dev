//[module]	VBLANK
//[processor]	IOP
//[type]	ELF-IRX
//[size]	3465(0xD89)
//[bios]	10000(0x37C70-0x38A00)
//[iopboot]	13
//[loaded @]	00011F00-00012900
//[name]	Vblank_service
//[version]	0x101
//[memory map]	-
//[handlers]	-
//[entry point]	start, export_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\loadcore.h"	(0x101,RegisterLibraryEntries)
#include "..\include\intrman.h"		(0x102,RegisterIntrHandler,EnableIntr,CpuSuspendIntr,CpuResumeIntr,QueryIntrContext
#include "..\include\sysclib.h"		(0x101,memset)
#include "..\include\thbase.h"		(0x101,GetSystemStatusFlag)
#include "..\include\thevent.h"		(0x101,CreateEventFlag,iSetEventFlag,iClearEventFlag,WaitEventFlag)
#include "..\include\err.h"

struct LINK{				//used for sentinels
	void *next;			//dummy item that contains
	void *prev;			//only the links
};

struct DCLL{
	void	*next;
	void	*prev;
	int	priority;
	int	(*function)();
	void	*this;			//'this' style pointer
};					//intrh_vblank, intrh_evblank, vblank_0, vblank_1
					//cannot access global v
struct VBHS{
	int		statusFlag;	//set to 0 in 'start' function
	int		count;
	struct LINK	list0;		//sentinel, dummy list head (interrupt 0 vblank)
	struct LINK	list11;		//sentinel, dummy list head (interrupt 11 evblank)
	struct LINK	free;		//available blocks
	struct DDCL	items[16];
} v;

int  start();
struct VBHS *return_v();
int WaitVblankStart();
int WaitVblankEnd();
int WaitVblank();
int WaitNonVblank();
int RegisterVblankHandler(int number, int priority, int (*)(struct VBHS *), struct VBHS*);
int ReleaseVblankHandler(int number, int (*)(struct VBHS *));
void retonly();

//////////////////////////////entrypoint///////////////////////////////
struct export export_stub={
	0x41C00000,
	0,
	VER(1, 1),			// 1.1 => 0x101
	0,
	"vblank",
	(func)start,			// entrypoint
	(func)retonly,
	(func)retonly,
	(func)return_smth,
	(func)WaitVblankStart,		// 4
	(func)WaitVblankEnd,		// 5
	(func)WaitVblank,		// 6
	(func)WaitNonVblank,		// 7
	(func)RegisterVblankHandler,	// 8
	(func)ReleaseVblankHandler,	// 9
	0				// end of list
};

//////////////////////////////entrypoint///////////////////////////////
int start(){
    struct EventFlagParam e;
    void *x;
	CpuSuspendIntr(&x);					//intrman

        if (RegisterLibraryEntries(&export_stub)){		//loadcore
		CpuResumeIntr(x, 0);				//intrman
		return 1;
	}

	memset(&v, 0, sizeof(VBHS));			// 352	//sysclib
	DCLL_make_sentinel(&v->list0);
	DCLL_make_sentinel(&v->list11);
	DCLL_make_sentinel(&v->free);
	for (i=0; i<16; i++)				//link 16 elements
		DCLL_add_after(&v->free, &v->items[i]);//to 'available' list

	e.initPattern=0;
	e.attr=2;
	e.option=0;
	CreateEventFlag(&e);					//thevent

	v.statusFlag=0;
	RegisterVblankHandler(0, 128, vblankh_0, &v);
	RegisterVblankHandler(1, 128, vblankh_1, &v);
	RegisterIntrHandler( 0, 1, intrh_vblank, &v);		//intrman
	RegisterIntrHandler(11, 1, intrh_evblank,&v);		//intrman
	EnableIntr(0);						//intrman
	EnableIntr(11);						//intrman

	CpuResumeIntr(x);					//intrman
	return 0;
}

///////////////////////////////////////////////////////////////////////
struct VBHS *return_v(){
	return &v;
}

///////////////////////////////////////////////////////////////////////
int RegisterVblankHandler(int number, int priority, int (*func)(struct VBHS *), struct VBHS* this){
    struct DCLL *p, *list;
	if (QueryIntrContext())					//intrman
		return ERROR_INTR_CONTEXT;
	CpuSuspendIntr(&x);					//intrman

	if (DCLL_is_only_sentinel(&v->free)){
		CpuResumeIntr(x);				//intrman
		return ERROR_NO_MEM;		//no more empty places
	}

	list=(number? &v->list11 : &v->list0);	//which list: 0 or 1?
	p=list->next;
	if (p != list){				//search for an existing instance in the list
		do{
			if (p->function == func){
				CpuResumeIntr(x);		//intrman
				return ERROR_DOES_EXIST;//already added
			}
			p=p->next;
		}while(p != list);
		p = list->next;
	}
	while (p != list){			// while we have elements in list ...
		if (priority < p->priority)
			break;			//greater priority 
		p=p->next;
	}

	DCLL_del(v->free->next);		//unlink next available
	v->free->next->function=func;		//fill it
	v->free->next->this    =this;
	v->free->next->priority=priority;
	DCLL_add_after(p, v->free->next);	//add it

	CpuResumeIntr(x);					//intrman
	return ERROR_OK;	
}

///////////////////////////////////////////////////////////////////////
int  ReleaseVblankHandler(int number, int (*func)(struct VBHS *)){
    struct DCLL *p, *list;
	if (QueryIntrContext())					//intrman
		return ERROR_INTR_CONTEXT;
	CpuSuspendIntr(&x);					//intrman

	for (list=(number?&v->list11:&v->list0), p=list->next; p!=list; p=p->next)
		if (p->function == func){	//bingo
			DCLL_del(p);
			DCLL_add_before(&v->free, p);

			CpuResumeIntr(x);			//intrman
			return ERROR_OK;
		}

	CpuResumeIntr(x);					//intrman
	return ERROR_DOESNOT_EXIST;				//not found
}

///////////////////////////////////////////////////////////////////////
int intrh_vblank(struct VBHS *m){
    struct DCLL *p, *cp;
	if (m->count++ == 0)
		iSetEventFlag(GetSystemStatusFlag(), 0x200);	//thevent,thbase

	for (p=m->list0; p != &m->list0; p=cp){
		cp=p->next;
		if ((p->function)(p->this)==0){
			DCLL_del(p);
			DCLL_add_before(&m->free, p);
		}
	}
	return 1;
}

///////////////////////////////////////////////////////////////////////
int intrh_evblank(struct VBHS *v){
    struct DCLL *p, *cp;
	for (p=v->list11; p != &v->list11; p=cp ){
		cp=p->next;
		if ((p->function)(p->this)==0){
			DCLL_del(p);
			DCLL_add_before(&v->free, p);
		}
	}
	return 1;
}

///////////////////////////////////////////////////////////////////////
int vblankh_0(struct VBHS *v){
	iSetEventFlag(v->statusFlag, 1);	//  0001b	//thevent
	iSetEventFlag(v->statusFlag, 2);	//  0010b	//thevent
	iClearEventFlag(v->statusFlag, ~(1|8));//~(1001b)=0xFFFFFFF6//thevent
	return 1;
}

///////////////////////////////////////////////////////////////////////
int vblankh_1(struct VBHS *v){
	iSetEventFlag(v->statusFlag, 4);	//  0100b	//thevent
	iSetEventFlag(v->statusFlag, 8);	//  1000b	//thevent
	iClearEventFlag(v->statusFlag, ~(2|4));//~(0110b)=0xFFFFFFF9//thevent
	return 1;
}

///////////////////////////////////////////////////////////////////////
int WaitVblankStart(){
	return WaitEventFlag(v->statusFlag, 1, 1, 0);		//thevent
}

///////////////////////////////////////////////////////////////////////
int WaitVblankEnd(){
	return WaitEventFlag(v->statusFlag, 4, 1, 0);		//thevent
}

///////////////////////////////////////////////////////////////////////
int WaitVblank(){
	return WaitEventFlag(v->statusFlag, 2, 1, 0);		//thevent
}

///////////////////////////////////////////////////////////////////////
int WaitNonVblank(){
	return WaitEventFlag(v->statusFlag, 8, 1, 0);		//thevent
}

///////////////////////////////////////////////////////////////////////
//static allocated Double Cyclic sentinel priority Linked List (whew)//
///////////////////////////////////////////////////////////////////////
void DCLL_make_sentinel(struct DCLL *list){
	list->next=list;
	list->prev=list;
}

///////////////////////////////////////////////////////////////////////
int  DCLL_is_only_sentinel(struct DCLL *list){
	v0=list->next;
	return (((unsigned int)list->next ^ (unsigned int)list) < 1);
}

///////////////////////////////////////////////////////////////////////
void DCLL_del(struct DCLL *list){	//in fact, unlink only
	list->next->prev=list->prev;
	list->prev->next=list->next;
}

///////////////////////////////////////////////////////////////////////
int  DCLL_less_than_two(struct DCLL *list){	//not used!
	return (((unsigned int)list->prev ^ (unsigned int)list->next) < 1);
        //returns true for 0 or 1 items in list
}

///////////////////////////////////////////////////////////////////////
void DCLL_add_before(struct DCLL *list, struct DCLL *new){
/*	sw      list, 0(new)	  new->next=list;
	lw      $v0, 4(list)	\
	sw      $v0, 4(new)	/ new->prev=list->prev;
	sw      new, 4(list)	  list->prev=new;
	lw      $v0, 4(new)	\ 
        sw      new, 0($v0)     / new->prev->next=new;
      ��������������Ŀ  ��������������Ŀ  ��������������Ŀ  
 ...�Ĵ              � ڴ    list      ��Ĵ              ���
 ...�ĳ              ÿ��              ��ĳ              ���
      ���������������ٳ�����������������  ����������������  
            �         ���(3)�Ŀ�
          (2)���(4)����       �(1)
            ����������������Ŀ��
            �Ĵ     new      �ٳ
             ��              ���
              ����������������                                  */
	new->next=list;
	new ->prev=list->prev;
	list->prev=new;
	new->prev->next=new;
}

void retonly(){}
