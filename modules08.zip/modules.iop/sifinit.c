//[module]	SIFINIT
//[processor]	IOP
//[type]	ELF-IRX
//[size]	1041(0x411)
//[bios]	10000(0x3FAD0-0x3FEF0)
//[iopboot]	25
//[name]	-
//[version]	-
//[memory map]	-
//[handlers]	-
//[entry point]	start
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\loadcore.h"	//(0x101,QueryBootMode)
#include "..\include\stdio.h"		//(0x102,printf)
#include "..\include\sifman.h"		//(0x101,sceSifInit)

//////////////////////////////entrypoint///////////////////////////////
int start(){
	int *v;

	if ((v=QueryBootMode(3)) && (v[1] & 1)){		//loadcore
		printf(" Skip SIF init\n");			//stdio
		return 1;
	}
	if ((v=QueryBootMode(1)) && ((short)v[0]==1)){		//loadcore
		printf(" Skip SIF init (it is DECI1)\n");	//stdio
		return 1;
	}
        sceSifInit();						//sifman
	return 1;
}