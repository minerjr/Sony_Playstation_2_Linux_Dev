//[module]	IOMAN
//[processor]	IOP
//[size]	8041(0x1F69)
//[bios]	T10000(0x38A00-0x3A970)
//[iopboot]	14
//[loaded @]	00012900-00013E00
//[name]	"IO/File_Manager"
//[version]	0x102
//[memory map]	-
//[handlers]	-
//[entry point]	start, export_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com) 1-3 February 2003

#include "..\include\sysmem.h"		//(0x101,Kprintf)
#include "..\include\loadcore.h"	//(0x101,FlushIcache,RegisterLibraryEntries)
#include "..\include\intrman.h"		//(0x102,CpuSuspendIntr,CpuResumeIntr)
#include "..\include\sysclib.h"		//(0x101,look_ctype_table,bzero,strcmp,index,strlen,strncpy,strtol)

struct ioman_FD{
	int			flag;	//+00
	int			devno;	//+04
	struct ioman_DRV	*drv;	//+08
	int			_pad;	//+0C
};					//=10

int max=16, dirty=1;
struct ioman_FUNCS tty_funclist={	//17 functions
	dummy, dummy, dummy, dummy, dummy, dummy, dummy, dummy, dummy,
	dummy, dummy, dummy, dummy, dummy, dummy, dummy, dummy
};

struct ioman_DRV ttyDev={
	"tty",		//device
	1,		//???
	1,		//version
	"CONSOLE",	//description
	&tty_funclist	//functions list
};

int error=0;

struct ioman_DRV *drvs[16];
struct ioman_FD  *fds[16];

//////////////////////////////entrypoint///////////////////////////////
int ioman_start(){
	RegisterLibraryEntries(&export_stub);			//loadcore
	bzero(drvs, sizeof(drvs));	//sizeof=64		//sysclib
	bzero(fds,  sizeof(fds));	//sizeof=256		//sysclib
	ioman_init(0);
	return 0;
}

///////////////////////////////////////////////////////////////////////
void ioman_init(int b){
	DelDrv("tty");
	if (b==0){
		_addDrv_tty();
		_clean();
	}

///////////////////////////////////////////////////////////////////////
int _clean(){
	close(STDIN);
	close(STDOUT);
	if (       open("tty00:", 3)==0)
	    return open("tty00:", 2);
}

///////////////////////////////////////////////////////////////////////[04]
int open(char *filename, int flag){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->flag =flag;
	FD->devno=devno;
	FD->drv  =drv;
	if (r=drv->f_list->open(FD, name, flag)>=0)
		return (FD-&fds) / sizeof(struct ioman_FD);
	error=-r;
	FD->drv=0;
	return r;
}

///////////////////////////////////////////////////////////////////////[08]
int lseek(int fd, int offset, int whence){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	if ((whence>=0) && (whence<3))
		if ((r=FD->drv->f_list->lseek(FD, offset, whence))>=0)
			return r;
		else{
			error=-r;
			return r;
		}
	write(STDOUT, "invalid lseek arg\r\n", strlen("invalid lseek arg\r\n"));//sysclib
	error=EINVAL;
	return -EINVAL;
}

///////////////////////////////////////////////////////////////////////[06]
int read(int fd, void *buf, long count){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	if ((r=FD->drv->f_list->read(FD, buf, count))>=0)
		return r;
	else{
		error=-r;
		return r;
	}
}

///////////////////////////////////////////////////////////////////////[07]
int write(int fd, void *buf, long count){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	if ((r=FD->drv->f_list->write(FD, buf, count))>=0)
		return r;
	else{
		error=-r;
		return r;
	}
}

///////////////////////////////////////////////////////////////////////[05]
int close(int fd){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	r=FD->drv->f_list->close(FD);
	FD->drv=FD->flag=0;
	if (r>=0)
		return fd;
	else{
		error=-r;
		return r;
	}
}

///////////////////////////////////////////////////////////////////////[09]
int ioctl(int fd, int request, int arg){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	if ((r=FD->drv->f_list->ioctl(FD, request, arg))>=0)
		return r;
	else{
		error=-r;
		return r;
	}
}

///////////////////////////////////////////////////////////////////////[13]
int dopen(char *filename){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->flag =0;
	FD->devno=devno;
	FD->drv  =drv;
	if (r=drv->f_list->dopen(FD, name)>=0)
		return (FD-&fds) / sizeof(struct ioman_FD);
	error=-r;
	FD->drv=0;
	return r;
}

///////////////////////////////////////////////////////////////////////[15]
int dread(int fd, void *buf){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	if ((r=FD->drv->f_list->dread(FD, buf))>=0)
		return r;
	else{
		error=-r;
		return r;
	}
}

///////////////////////////////////////////////////////////////////////[14]
int dclose(int fd){
	register struct ioman_FD *FD;
	register int r;

	FD=ithFD(fd);
	if (FD==0){
		error=EBADF;
		return -EBADF;
	}
	r=FD->drv->f_list->dclose(FD);
	FD->drv=FD->flag=0;
	if (r>=0)
		return fd;
	else{
		error=-r;
		return r;
	}
}

///////////////////////////////////////////////////////////////////////[10]
int remove(char *filename){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->devno=devno;
	FD->drv  =drv;
	r=drv->f_list->remove(FD, name);
	FD->drv=FD->flag=0;
	if (r)
		error=-r;
	return r;
}

///////////////////////////////////////////////////////////////////////[11]
int mkdir(char *filename){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->devno=devno;
	FD->drv  =drv;
	r=drv->f_list->mkdir(FD, name);
	FD->drv=FD->flag=0;
	if (r>=0)
		return 0;
	error=-r;
	return r;
}

///////////////////////////////////////////////////////////////////////[12]
int rmdir(char *filename){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->devno=devno;
	FD->drv  =drv;
	r=drv->f_list->rmdir(FD, name);
	FD->drv=FD->flag=0;
	if (r>=0)
		return 0;
	error=-r;
	return r;
}

///////////////////////////////////////////////////////////////////////[16]
int getstat(char *filename, void *buf){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->devno=devno;
	FD->drv  =drv;
	r=drv->f_list->getstat(FD, name, buf);
	FD->drv=FD->flag=0;
	if (r>=0)
		return 0;
	error=-r;
	return r;
}

///////////////////////////////////////////////////////////////////////[17]
int chstat(char *filename, void *buf, unsigned int mask){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->devno=devno;
	FD->drv  =drv;
	r=drv->f_list->chstat(FD, name, buf, mask);
	FD->drv=FD->flag=0;
	if (r>=0)
		return 0;
	error=-r;
	return r;
}

///////////////////////////////////////////////////////////////////////[18]
int format(char *filename){
	register int devno, r;
	register struct ioman_DRV *drv;
	register struct ioman_FD  *FD;
	register char *name;

	FD=getFD();
	if (FD==0){
		error=EMFILE;
		return -EMFILE;
	}
	name=getDev_Name(filename, &drv, &devno);
	if (name==ERROR_UNK){
		error=EACCES;
		FD->drv=0;
		return -EACCES;
	}
	FD->devno=devno;
	FD->drv  =drv;
	r=drv->f_list->format(FD, name);
	FD->drv=FD->flag=0;
	if (r>=0)
		return 0;
	error=-r;
	return r;
}

///////////////////////////////////////////////////////////////////////
void _ioabort_exit_message(char *m1, char *m2){
	Kprintf("ioabort exit:%s %s\n", m1, m2);		//sysmem
}

///////////////////////////////////////////////////////////////////////
struct ioman_FD *getFD(){
	int x;
	register int i;

	CpuSuspendIntr(&x);					//intrman
	for (i=0; i<16; i++)
		if (fds[i]->drv==0){
			fds[i]->drv="";
			CpuResumeIntr(x);			//intrman
			return &fds[i];
		}
	CpuResumeIntr(x);					//intrman
	_ioabort_exit_message("out of file descriptors", "");
	return 0;
}

///////////////////////////////////////////////////////////////////////
struct ioman_FD *ithFD(int i){
	if (i<16) && (fds[i])
		return &fds[i];
	return 0;
}

///////////////////////////////////////////////////////////////////////
struct ioman_DEV *getDev(char *device){
	register int i;

	for (i=0; i<max; i++){
		if (drvs[i]->device) && (strcmp(drvs[i]->device, device)==0)//sysclib
			return drvs[i];
	Kprintf("Unknown device '%s'\n", device);		//sysmem
	knownDevs();
	return NULL;
}

///////////////////////////////////////////////////////////////////////
char *getDev_Name(char *filename, struct ioman_DEV *drv, int *devno){
	char buf[32];
	register int i, len;

	while (*filename++==" ");
	filename--;

	if ((i=index(filename, ':'))==0){			//sysclib
		Kprintf("Unknown device '%s'\n", filename);	//sysmem
		return ERROR_UNK;
	}
	*devno=0;
	strncpy(buf, filename, len=i-filename);			//sysclib
	filename=buf+len;
	*filename=0;
	if (look_ctype_table(*(filename-1)) & 4){		//sysclib
		while (look_ctype_table(*(filename-1)) & 4)	//sysclib
			filename--;
		*devno=strtol(filename, 0, 10);			//sysclib
	}
	*filename=0;
	if (*drv=getDev(&buf))
		return i+1;
	return ERROR_UNK;
}

///////////////////////////////////////////////////////////////////////
int unsupportedOp(){
	write(STDOUT, "io request for unsupported operation\r\n", strlen("io request for unsupported operation\r\n");//sysclib
	return ERROR_UNK;
}

///////////////////////////////////////////////////////////////////////
int dummy(){
	return ERROR_OK;
}

///////////////////////////////////////////////////////////////////////[20]
int AddDrv(struct ioman_DRV *drv){
	register int i;

	for (i=0; i<max; i++)
		if (drvs[i]==0){
			drvs[i]=drv;
			FlushIcache();				//loadcore
			if (drv->f_list->init(drv)<0){
				drvs[i]=0;
				break;
			}else{
				dirty=1;
				return ERROR_OK;
			}
		}
	return ERROR_UNK;
}

///////////////////////////////////////////////////////////////////////[21]
int DelDrv(char *device){
	register int i;

	for (i=0; i<max; i++)
		if (drvs[i]->device) && (strcmp(device, drvs[i]->device)==0){//sysclib
			drvs[i]->f_list->term(drvs[i]);
			drvs[i]=0;
			return 0;
	}
	return -1;
}

///////////////////////////////////////////////////////////////////////
void knownDevs(){
	register int i;
	if (dirty){
		Kprintf("Known devices are ");			//sysmem
		for (i=0; i<max; i++)
			if (drvs[i]->device)
				Kprintf(" %s:(%s) ", drvs[i]->device, drvs[i]->description);//sysmem
		Kprintf("\n");					//sysmem
	}
	dirty=0;
}

///////////////////////////////////////////////////////////////////////
void _addDrv_tty(){
	AddDrv(&ttyDev);
}

//////////////////////////////entrypoint///////////////////////////////
struct export export_stub={
	0x41C00000,
	0,
	VER(1, 2),	// 1.2 => 0x102
	0,
	"ioman",
	(func)ioman_start,	// entrypoint
	(func)ioman_retonly,
	(func)ioman_retonly,
	(func)ioman_retonly,
	(func)open,		//04
	(func)close,		//05
	(func)read,		//06
	(func)write,		//07
	(func)lseek,		//08
	(func)ioctl,		//09
	(func)remove,		//10
	(func)mkdir,		//11
	(func)rmdir,		//12
	(func)dopen,		//13
	(func)dclose,		//14
	(func)dread,		//15
	(func)getstat,		//16
	(func)chstat,		//17
	(func)format,		//18
	(func)ioman_retonly,	//19
	(func)AddDrv,		//20
	(func)DelDrv,		//21
	(func)ioman_retonly,	//22
	(func)ioman_retonly,	//23
	(func)ioman_retonly,	//24
	0
};

///////////////////////////////////////////////////////////////////////
void ioman_retonly(){}
