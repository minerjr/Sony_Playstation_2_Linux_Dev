//[module]	SIFMAN
//[processor]	IOP
//[type]	ELF-IRX
//[size]	5529(0x1599)
//[bios]	10000(0x3E530-0x3FAD0)
//[iopboot]	18
//[loaded @]	00016900-00017D00
//[name]	IOP_SIF_manager
//[version]	0x101
//[memory map]	0xBD000000,0xBD000010,0xBD000020,0xBD000030,
//		0xBD000040,0xBD000060
//		0xBF8010A0,0xBF8010A4,0xBF8010A8,
//		0xBF8010F0,
//		0xBF801450,
//		0xBF801520,0xBF801524,0xBF801528,0xBF80152C,
//		0xBF801530,0xBF801534,0xBF801538,
//		0xBF801570
//[handlers]	-
//[entry point]	sifman_start, sifman_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com) october 2002

#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries)
#include "..\include\intrman.h"		//(0x102,RegisterIntrHandler,ReleaseIntrHandler,EnableIntr,DisableIntr,CpuEnableIntr,CpuSuspendIntr,CpuResumeIntr)

#define CONFIG_1450		(*(volatile int*)0xBF801450)

#define BD0	(*(volatile int*)0xBD000000)	//mscom
#define BD1	(*(volatile int*)0xBD000010)	//smcom
#define BD2	(*(volatile int*)0xBD000020)	//msflag
#define BD3	(*(volatile int*)0xBD000030)	//smflag
#define BD4	(*(volatile int*)0xBD000040)
#define BD5	(*(volatile int*)0xBD000050)
#define BD6	(*(volatile int*)0xBD000060)
#define BD7	(*(volatile int*)0xBD000070)

struct sifData{
	int	data,
		words,
		count,
		addr;
};

int	sifGPUInit	=FALSE,
	sifInit		=FALSE:

struct sm_internal{
	short		id,		//+000	some id...?!?
			res1;		//+002	not used
	int		index;		//+004	current position in dma buffer
	struct sifData	*crtbuf;	//+008	address of current used buffer
	struct sifData	buf1[32];	//+00C	first buffer
	struct sifData	buf2[32];	//+20C	second buffer
	int		(*function)(int);//+40C	a function ?!?
	int		param;		//+410	a parameter for function
	int		res2;		//+414	not used
} vars;

struct sifData	one;
int		res3, res4;

//////////////////////////////entrypoint///////////////////////////////[00]
int sifman_start(int argc, char* argv){
	if ((PRId>=0x10) &&
	   !(CONFIG_1450 &   8)&&
	   ((BD6 == 0x1D000060)||
	   !(BD6  & 0xFFFFF000)))
		return (RegisterLibraryEntries(&sifman_stub)>0);//loadcore
	}
	return 1;
}

///////////////////////////////////////////////////////////////////////
int getBD2_loopchanging(){
    register int a, b;
	b=BD2;
	do{
		a=b;
		b=BD2;
	while (a!=b);
	return a;
}

///////////////////////////////////////////////////////////////////////
int getBD3_loopchanging(){
    register int a, b;
	b=BD3;
	do{
		a=b;
		b=BD3;
	while (a!=b);
	return a;
}

///////////////////////////////////////////////////////////////////////[04]
void sifman_sceSifGPUInit(){
    int var8;
	if (sifGPUInit==FALSE){
		DMAch_SIF2_CHCR	= 0;		//reset ch. 2
		DMAch_DPCR	|=0x800;	//enable dma ch. 2
		var8		=DMAch_DPCR;	//?!?
		sifGPUInit	=TRUE;
	}
}

///////////////////////////////////////////////////////////////////////[05]
void sceSifInit(){
    int var20, x, y;
	if (sifInit==FALSE){
		DMAch_DPCR2	|=0x8800;	//enable dma ch. 9 and 10
		DMAch_SIF9_CHCR	= 0;
		DMAch_SIFA_CHCR	= 0;
		sifman_sceSifGPUInit();

		if (CONFIG_1450 & 0x10)
			CONFIG_1450 |= 0x10;
		CONFIG_1450 |= 0x1;

		RegisterSif0Handler();

		CpuSuspendIntr(&x);				//intrman
		CpuEnableIntr();				//intrman

		do{
			CpuSuspendIntr(&y);			//intrman
			s0=getBD2_loopchanging();
			CpuResumeIntr(y);			//intrman
		}while (!(s0 & 0x10000));	//EE kernel sif ready

		CpuResumeIntr(x);				//intrman
		sceSifSetDChain();
		sifman_call27_setIOPrcvaddr(0);	//sif1 receive buffer
		BD3 = 0x10000;			//IOPEE_sifman_init
		var20		=BD3;		//?!?
		sifInit		=TRUE;
	}
}

///////////////////////////////////////////////////////////////////////[02]
void sifman_deinit(){
	DisableIntr(INT_DMA9, &x);				//intrman
	ReleaseIntrHandler(INT_DMA9);				//intrman
	DMAch_SIF9_CHCR=0;
	DMAch_SIFA_CHCR=0;
	if (CONFIG_1450 & 0x10)
		CONFIG_1450 |= 0x10;
}

///////////////////////////////////////////////////////////////////////[29]
int sceSifCheckInit(){
	return sifInit;
}

///////////////////////////////////////////////////////////////////////[06]
void sceSifSetDChain(){
	if (BD4 & 0x40 == 0) BD4=0x40;
	DMAch_SIFA_CHCR		=0;
	DMAch_SIFA_BCR_size	=32;
	DMAch_SIFA_CHCR		=DMAf_08|DMAf_CO|DMAf_TR|DMAf_30;//EE->IOP (to memory)
}

///////////////////////////////////////////////////////////////////////[30]
void sifman_call30_setSif0CB(int (*_function)(int), int _param){
	vars.function=_function;
	vars.param=_param;
}

///////////////////////////////////////////////////////////////////////[31]
void sifman_call31_resetSif0CB(){
	vars.function=NULL;
	vars.param=0;
}

///////////////////////////////////////////////////////////////////////
int Sif0Handler(struct sm_internal *vars){
    int var_10;
	if (vars->function)
		vars->function(vars->param);

	if ((DMAch_SIF9_CHCR & DMAf_TR == 0) && (vars->index>0))
		DMAch_SIF9_CHCR	=0;
		DMAch_SIF9_TADDR=vars->crtbuf;
		DMAch_SIF9_BCR	=32;
		if (BD4 & 0x20 == 0)	BD4 = 0x20;
		vars->id++;
		if (vars->crtbuf == vars->buf1){
			vars->index=0;
			vars->crtbuf=vars->buf2;
		}else
			vars->crtbuf=vars->buf1;
		DMAch_SIF9_CHCR = DMAf_DR|DMAf_08|DMAf_CO|DMAf_LI|DMAf_TR;//IOP->EE (from memory)
		var_10=DMAch_SIF9_CHCR;
	}
	return 1;
}

///////////////////////////////////////////////////////////////////////
void RegisterSif0Handler(){
    int x;
	vars.index=0;
	vars.crtbuf=vars.buf1;
	vars.function=NULL;
	vars.param=0;
	CpuSuspendIntr(&x);					//intrman
	RegisterIntrHandler(INT_DMA9, 1, Sif0Handler, &vars);	//intrman
	EnableIntr(INT_DMA9);					//intrman
	CpuResumeIntr(x);					//intrman
}

///////////////////////////////////////////////////////////////////////
void enqueue(struct sifman_DMA *psd){
	vars.crtbuf[vars.index].data=psd->data & 0xFFFFFF;	//16MB addressability
	if (psd->attr & SIF_DMA_INT_I)
		vars.crtbuf[vars.index].data |= 0x40000000;
	vars.crtbuf[index].words=(psd->size + 3)/4 & 0xFFFFFF;
	vars.crtbuf[index].count = ((psd->size + 3)/16 + (((psd->size + 3)/4) & 3))
			| 0x10000000;
	if (psd->attr & SIF_DMA_INT_O)
		vars.crtbuf[vars.index].count |=0x80000000;
	vars.crtbuf[index].addr = psd->addr & 0x1FFFFFFF;	//512MB addresability
	vars.index++;
}

///////////////////////////////////////////////////////////////////////[07]
unsigned int sceSifSetDma(struct sifman_DMA *psd, int len){
    int var_20;
    register unsigned int ret;
	if (32-vars.index < len)	return 0;	//no place

	ret = vars.id;
	ret = (ret << 16) | ((vars.index & 0xFF) << 8) | (len & 0xFF);

	if (vars.index)
	vars.crtbuf[vars.index-1].data &= 0x7FFFFFFF;
	for (i=0; i<len; i++)
		enqueue(&psd[i]);
	vars.crtbuf[vars.index-1].data |= 0x80000000;

	if (DMAch_SIF9_CHCR & DMAf_TR == 0)
		DMAch_SIF9_CHCR=0;
		DMAch_SIF9_TADDR=vars.crtbuf;

		if (BD4 & 0x20 == 0)	BD4=0x20;

		DMAch_SIF9_BCR_size=32;

		vars.index=0;
		vars.id++;
		if (vars.crtbuf==vars.buf1)vars.crtbuf=vars.buf2;
			//stupid :D (why the if?)

		DMAch_SIF9_CHCR=DMAf_DR|DMAf_08|DMAf_CO|DMAf_LI|DMAf_TR;//IOP->EE
		var_20=DMAch_SIF9_CHCR;	//?!?
	}
	return ret;
}

///////////////////////////////////////////////////////////////////////[08]
int sceSifDmaStat(unsigned int id){
	if (DMAch_SIF9_CHCR & DMAf_TR){
		if (id>>16   == vars.id)	return 1;  //waiting in queue
		if (id>>16+1 == vars.id)	return 0;  //running
	}
	return -1;	//terminated
}

///////////////////////////////////////////////////////////////////////[09]
void sifman_call9_sceSifSend(struct sifman_DMA sd){
	sd.size = sd.size /4 + ((sd.size & 3) > 0);
	one.data = sd.data & 0xFFFFFF | 0x80000000;
	one.words= sd.size & 0xFFFFFF;
	if (sd.attr & SIF_DMA_INT_I)	     one.data |= 0x40000000;
	one.count = (sd.size/4 + ((sd.size & 3)>0)) |  0x10000000;
	if (sd.attr & SIF_DMA_INT_O)	     one.count|= 0x80000000;
	one.addr = sd.addr & 0xFFFFFFF;

	if (BD4 & 0x20 == 0)	BD4=0x20;

	DMAch_SIF9_CHCR=0;
	DMAch_SIF9_TADDR=&one;
	DMAch_SIF9_BCR_size=32;
	DMAch_SIF9_CHCR=DMAf_DR|DMAf_08|DMAf_CO|DMAf_LI|DMAf_TR; //IOP->EE
	var_8=DMAch_SIF9_CHCR;	//?!?
}

///////////////////////////////////////////////////////////////////////[10]
void sifman_call10_sceSifSendSync(){
	while (DMAch_SIF9_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[11]
int  sifman_call11_sceSifIsSending(){
	return (DMAch_SIF9_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[12]
void sifman_call12_sceSifSetSIF0DMA(void *data, int size, int attr){
    int var_8;

	size=size/4 + ((size & 3)>0);

	if (BD4 & 0x20 == 0)	BD4=0x20;

	DMAch_SIF9_CHCR=0;
	DMAch_SIF9_MADDR=data & 0xFFFFFF;
	DMAch_SIF9_BCR_size=32;
	DMAch_SIF9_BCR_count=size/32 + ((size & 0x1F)>0)
	DMAch_SIF9_CHCR=DMAf_DR|DMAf_CO|DMAf_TR;
	var_8=DMAch_SIF9_CHCR;
}

///////////////////////////////////////////////////////////////////////[13]
void sifman_call13_sceSifSendSync0(){
	while (DMAch_SIF9_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[14]
int  sifman_call14_sceSifIsSending0(){
	return (DMAch_SIF9_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[15]
void sifman_call15_sceSifSetSIF1DMA(void *data, int size, int attr){
    int var_8;

	size=size/4 + ((size & 3)>0);

	if (BD4 & 0x40 == 0)	BD4=0x40;

	DMAch_SIFA_CHCR=0;
	DMAch_SIFA_MADDR=data & 0xFFFFFF;
	DMAch_SIFA_BCR_size=32;
	DMAch_SIFA_BCR_count=size/32 + ((size & 0x1F)>0)
	DMAch_SIFA_CHCR=DMAf_CO|DMAf_TR|
	    (attr & SIF_DMA_BSN?DMAf_30:0);
	var_8=DMAch_SIFA_CHCR;
}

///////////////////////////////////////////////////////////////////////[16]
void sifman_call16_sceSifSendSync1(){
	while (DMAch_SIFA_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[17]
int  sifman_call17_sceSifIsSending1(){
	return (DMAch_SIFA_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[18]
void sifman_call18_sceSifSetSIF2DMA(void *data, int size, int attr){
    int var_8;

	size=size/4 + ((size & 3)>0);

	if (BD4 & 0x80 == 0)	BD4=0x80;

	DMAch_GPU_CHCR=0;
	DMAch_GPU_MADDR=data & 0xFFFFFF;
	DMAch_GPU_BCR_size=min(size, 32);
	DMAch_GPU_BCR_count=size/32 + ((size & 0x1F)>0)
	DMAch_GPU_CHCR=DMAf_CO |DMAf_TR|
	    ((attr & SIF_TO_EE  ?DMAf_DR:
	     (attr & SIF_DMA_BSN?DMAf_30:0));
	var_8=DMAch_GPU_CHCR;
}

///////////////////////////////////////////////////////////////////////[19]
void sifman_call19_sceSifSendSync2(){
	while (DMAch_GPU_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[20]
int  sifman_call20_sceSifIsSending2(){
	return (DMAch_GPU_CHCR & DMAf_TR);
}

///////////////////////////////////////////////////////////////////////[21]
int  sifman_call21_getEEIOPflags(){
	return getBD2_loopchanging();
}

///////////////////////////////////////////////////////////////////////[22]
int  sifman_call22_setEEIOPflags(int val){
	BD2=val;
	return getBD2_loopchanging();
}

///////////////////////////////////////////////////////////////////////[23]
int  sifman_call23_getIOPEEflags(){
	return getBD3_loopchanging();
}

///////////////////////////////////////////////////////////////////////[24]
int  sifman_call24_setIOPEEflags(int val){
	BD3=val;
	return getBD3_loopchanging();
}

///////////////////////////////////////////////////////////////////////[25]
int  sifman_call25_getEErcvaddr(){
	return BD0;
}

///////////////////////////////////////////////////////////////////////[26]
int  sifman_call26_getIOPrcvaddr(){
	return BD1;
}

///////////////////////////////////////////////////////////////////////[27]
int  sifman_call27_setIOPrcvaddr(int val){
	BD1=val;
	return BD1;
}

///////////////////////////////////////////////////////////////////////[28]
void sifman_call28(){
    int var_8;
	CONFIG_1450 |= 2;
	CONFIG_1450 &= 0xFFFFFFFD;
	var_8=CONFIG_1450;
}

///////////////////////////////////////////////////////////////////////[01,03,32,33,34,35]
void sifman_retonly(){}

//////////////////////////////entrypoint///////////////////////////////
struct export sifman_stub={
	0x41C00000,
	0,
	VER(1, 1),			// 1.1 => 0x101
	0,
	"sifman",
	(func)sifman_start,			// entrypoint
	(func)sifman_retonly,
	(func)sifman_deinit,
	(func)return_retonly,
	(func)sifman_call4_sceSifGPUInit,
	(func)sceSifInit,
	(func)sceSifSetDChain,
	(func)sceSifSetDma,
	(func)sceSifDmaStat,
	(func)sifman_call9_sceSifSend,
	(func)sifman_call10_sceSifSendSync,
	(func)sifman_call11_sceSifIsSending,
	(func)sifman_call12_sceSifSetSIF0DMA,
	(func)sifman_call13_sceSifSendSync0,
	(func)sifman_call14_sceSifIsSending0,
	(func)sifman_call15_sceSifSetSIF1DMA,
	(func)sifman_call16_sceSifSendSync1,
	(func)sifman_call17_sceSifIsSending1,
	(func)sifman_call18_sceSifSetSIF2DMA,
	(func)sifman_call19_sceSifSendSync2,
	(func)sifman_call20_sceSifIsSending2,
	(func)sifman_call21_getEEIOPflags,
	(func)sifman_call22_setEEIOPflags,
	(func)sifman_call23_getIOPEEflags,
	(func)sifman_call24_setIOPEEflags,
	(func)sifman_call25_getEErcvaddr,
	(func)sifman_call26_getIOPrcvaddr,
	(func)sifman_call27_setIOPrcvaddr,
	(func)sifman_call28,
	(func)sceSifCheckInit,
	(func)sifman_call30_setSif0CB,
	(func)sifman_call31_resetSif0CB,
	(func)sifman_retonly,
	(func)sifman_retonly,
	(func)sifman_retonly,
	(func)sifman_retonly,
	0
};