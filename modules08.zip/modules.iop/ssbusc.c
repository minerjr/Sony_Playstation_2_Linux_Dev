//[module]	SSBUSC
//[processor]	IOP
//[type]	ELF-IRX
//[size]	1897(0x769)
//[bios]	10000(0x26400-0x26B70)
//[iopboot]	05
//[loaded @]	00005C00-00006000
//[name]	ssbus_service
//[version]	0x101
//[memory map]	0xBF801000,0xBF801004,0xBF801008,0xBF80100C,		(r/w)
//		MDECin(T2),8(T2)     ,MDECin(T1),MDECout(T1),
//
//		0xBF801010,0xBF801014,0xBF801018,0xBF80101C,0xBF801020	(r/w)
//		GPU(SIF2)(T1),SPU(T1)spu_delay,PIO(T1),8(T1),SSBUSCconfig
//
//		0xBF801400,0xBF801404,0xBF801408,0xBF80140C,		(r/w)
//		MDECout(T2),SPU(T2)  ,PIO(T2)   ,SIF0(T2),
//
//		0xBF801410,0xBF801414,0xBF801418,0xBF80141C,0xBF801420	(r/w)
//		SIO2in(T2),SIF0(T1)  ,SIF1(T1)  ,SIO2in(T1),SIO2out(T1)
//
//[handlers]	-
//[entry point]	start, export_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries)
#include "..\include\intrman.h"		//(0x102,CpuSuspendIntr,CpuResumeIntr)

int memmap_table[]={
	0xBF801008, 0xBF80100C, 0xBF801010, 	     0, 0xBF801014,//spu_delay
	0xBF801018,	     0,		 0, 0xBF80101C, 0xBF801414,
	0xBF801418, 0xBF80141C, 0xBF801420
};

int memmap_table_2[]={
	0xBF801000, 0xBF801400,		 0,	     0, 0xBF801404,
	0xBF801408,	     0,		 0, 0xBF801004, 0xBF80140C,
		 0, 0xBF801410,		 0
};

int ssbusc_start();
int return_0();
int ssbusc_call4(int code, int value);
int ssbusc_call5(int code);
int ssbusc_call6(int code, int value);
int ssbusc_call7(int code);
int ssbusc_call8(int a);
int ssbusc_call9();
int ssbusc_call10(int a);
int ssbusc_call11();
int ssbusc_call12(int a);
int ssbusc_call13();
int ssbusc_call14(int a);
int ssbusc_call15();
int ssbusc_call16(int a);
int ssbusc_call17();
void retonly();

//////////////////////////////entrypoint///////////////////////////////
struct export export_stub={
	0x41C00000,
	0,
	VER(1, 1),	// 1.1 => 0x101
	0,
	"ssbusc",
	(func)ssbusc_start,	// entrypoint
	(func)retonly,
	(func)return_0,
	(func)retonly,
	(func)ssbusc_call4_setTable1,
	(func)ssbusc_call5_getTable1,
	(func)ssbusc_call6_setTable2,
	(func)ssbusc_call7_getTable2,
	(func)ssbusc_call8_setCOM_DELAY_1st,
	(func)ssbusc_call9_getCOM_DELAY_1st,
	(func)ssbusc_call10_setCOM_DELAY_2nd,
	(func)ssbusc_call11_getCOM_DELAY_2nd,
	(func)ssbusc_call12_setCOM_DELAY_3rd,
	(func)ssbusc_call13_getCOM_DELAY_3rd,
	(func)ssbusc_call14_setCOM_DELAY_4th,
	(func)ssbusc_call15_getCOM_DELAY_4th,
	(func)ssbusc_call16_setCOM_DELAY,
	(func)ssbusc_call17_getCOM_DELAY,
	0		// end of list
};

//////////////////////////////entrypoint///////////////////////////////
int ssbusc_start(int argc, char* argv[]){
    int x;

	CpuSuspendIntr(&x);					//intrman
	if (RegisterLibraryEntries(&export_stub)==0){		//loadcore
		CpuResumeIntr(x);				//intrman
		return 0;
	}else{
		CpuResumeIntr(x);				//intrman
		return 1;
	}
}

///////////////////////////////////////////////////////////////////////
int return_0(){
	return 0;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call4_setTable1(int code, int value){	//set
    int *v;
	if ((code < 13) && (v=memmap_table[code]))
		return *v=value;
	return -1;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call5_getTable1(int code){			//get
    int *v;
	if ((code < 13) && (v=memmap_table[code]))
		return *v;
	return -1;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call6_setTable2(int code, int value){	//set
    int *v;
	if ((code < 13) && (v=memmap_table_2[code]))
		return *v=value;
	return -1;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call7_setTable2(int code){			//get
    int *v;
	if ((code < 13) && (v=memmap_table_2[code]))
		return *v;
	return -1;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call8_setCOM_DELAY_1st(int a){			//set lowest nibble
	return	 *(int*)(0xBF801020) = 
		(*(int*)(0xBF801020) & 0xFFFFFFF0) |
		(             a      &        0xF);
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call9_getCOM_DELAY_1st(){				//get lowest nibble
	return   *(int*)(0xBF801020) &        0xF;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call10_setCOM_DELAY_2nd(int a){			//set
	return	 *(int*)(0xBF801020) = 
		(*(int*)(0xBF801020) & 0xFFFFFF0F) |
		(         (a << 4)   &       0xF0);
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call11_getCOM_DELAY_2nd(){				//get
	return *(unsigned char*)(0xBF801020) >> 4;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call12_setCOM_DELAY_3rd(int a){			//set
	return	 *(int*)(0xBF801020) = 
		(*(int*)(0xBF801020) & 0xFFFFF0FF) |
		(         (a << 8)   &      0xF00);
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call13_getCOM_DELAY_3rd(){				//get
	return  (*(int*)(0xBF801020) >> 8) & 0xF;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call14_setCOM_DELAY_4th(int a){			//set
	return	 *(int*)(0xBF801020) = 
		(*(int*)(0xBF801020) & 0xFFFF0FFF) |
		(        (a << 12)   &     0xF000);
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call15_getCOM_DELAY_4th(){				//get
	return  (*(int*)(0xBF801020) >> 12) & 0xF;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call16_setCOM_DELAY(int a){				//set
	return   *(int*)(0xBF801020) = a;
}

///////////////////////////////////////////////////////////////////////
int ssbusc_call17_getCOM_DELAY(){				//get
	return   *(int*)(0xBF801020);
}

///////////////////////////////////////////////////////////////////////
void retonly(){}

