//[module]	EECONF
//[processor]	IOP
//[type]	ELF-IRX
//[size]	3729(0xE91)
//[bios]	10000(0xAD7D0-0xAE670)
//[iopboot]	11
//[loaded @]	0000AA00-?
//[name]	EEConfig
//[version]	0x101
//[memory map]	0xBF402005, 0xBF402016, 0xBF402017, 0xBF402018
//[handlers]	-
//[entry point]	eeconf_start, [eeconf_stub]
//[made by]	[RO]man (roman_ps2dev@hotmail.com) 26 January 2003

#include "..\include\sysmem.h"		//(0x101,AllocSysMemory)
#include "..\include\loadcore.h"	//(0x101,QueryBootMode)

#include "..\include\cdvdman.h"

int count, _[3];

///////////////////////////////////////////////////////////////////////
int sceCdSCmd(int command, int *idata, int isize, int *odata, int osize){
	char old, buf[20];
	register int i, j;

	if (CDVDreg_SDATAIN & 0x80)		//error if still reading
		return 0;
	while (CDVDreg_SDATAIN & 0x40==0)	//empty pipe
		old=CDVDreg_SDATAOUT;

	for (i=0; i<isize; i++)			//send data in
		CDVDreg_SDATAIN=idata[i];

	CDVDreg_SCOMMAND=command;		//send command

	old=CDVDreg_SCOMMAND;			//old command?

	while (CDVDreg_SDATAIN & 0x80);		//wait for ready

	for (i=0; CDVDreg_SDATAIN & 0x40==0; i++)//get command result
		buf[i]=CDVDreg_SDATAOUT;

	osize=min(i, osize);
	for (j=0; j<osize; j++)			//fill output buffer
		odata[j]=buf[j];

	return 1;
}

///////////////////////////////////////////////////////////////////////
int sceCdOpenConfig(int a, int b, int _count, int *result){
	int idata;

	idata=   (b     & 0xFF) |
		((a     & 0xFF) << 8) |
		((_count & 0xFF) << 16);
	count=_count;
	return sceCdSCmd(SCMD_OPENCONFIG, &idata, 3, result, 1);
}

///////////////////////////////////////////////////////////////////////
int sceCdCloseConfig(int *result){
	register int r;

	r=sceCdSCmd(SCMD_CLOSECONFIG, NULL, 0, result, 1);
	count=0;
	return r;
}

///////////////////////////////////////////////////////////////////////
int _sceCdReadConfig(char *data, int *key){
	char buffer[20];
	register int r;

	r=sceCdSCmd(SCMD_READCONFIG, NULL, 0, buffer, 16);
	*key=(((buffer[ 0]+buffer[ 1]+buffer[ 2]+buffer[ 3]+
		buffer[ 4]+buffer[ 5]+buffer[ 6]+buffer[ 7]+
	     	buffer[ 8]+buffer[ 9]+buffer[10]+buffer[11]+
	     	buffer[12]+buffer[13]+buffer[14]) & 0xFF) ^ buffer[15]) > 0;
	*(int*)(data+0)=*(int*)(buffer+0);
	*(int*)(data+4)=*(int*)(buffer+4);
	*(int*)(data+8)=*(int*)(buffer+8);
	data[12]=buffer[12];
	data[13]=buffer[13];
	data[14]=buffer[14];

	return r;
}

///////////////////////////////////////////////////////////////////////
int sceCdReadConfig(char *data, int *key){
	register int i;

	for (i=0; i<count; i++, data+=15)
		if ((_sceCdReadConfig(data, key)==0) || (*key))
			break;
	return i;
}

///////////////////////////////////////////////////////////////////////
int _sceCdWriteConfig(char *data, int *key){
	char buffer[16];

	*key=0;
	*(int*)(buffer+0)=*(int*)(data+0);
	*(int*)(buffer+4)=*(int*)(data+4);
	*(int*)(buffer+8)=*(int*)(data+8);
	buffer[12]=data[12];
	buffer[13]=data[13];
	buffer[14]=data[14];
	buffer[15]=data[ 0]+data[ 1]+data[ 2]+data[ 3]+
		   data[ 4]+data[ 5]+data[ 6]+data[ 7]+
	    	   data[ 8]+data[ 9]+data[10]+data[11]+
		   data[12]+data[13]+data[14];
	return sceCdSCmd(SCMD_WRITECONFIG, buffer, 16, key, 1);
}

///////////////////////////////////////////////////////////////////////
int sceCdWriteConfig(char *data, int *key){
	register int i;

	for (i=0; i<count; i++, data+=15)
		if ((_sceCdWriteConfig(data, key)==0) || (*key))
			break;
	return i;
}

//////////////////////////////entrypoint///////////////////////////////
int eeconf_start(int argc, char* argv[]){
	char data[16];
	int  result;
	register int *v, tmp, i, flag, r;
	register char *mem;

	if (v=QueryBootMode(3)){				//loadcore
		if (v[1] & 1)	return 1;
		if (v[1] & 2)	return 1;
	}

	*(int*)0x3C0=0;

	tmp=3;
	while ((CDVDreg_READY & 8==0) && (tmp>0))
		tmp=0x2FFFF;
	if (CDVDreg_READY & 8==0)	return 1;

	flag=0;
	if (mem=AllocSysMemory(ALLOC_LAST, 96, NULL)){		//sysmem
		flag=1;
		*(char**)0x3C0=mem;
    		for (i=89; i>=0; i--)
			mem[i]=0;

		i=0x10000;do{r=sceCdOpenConfig(0, 0, 4, &result);tmp=i;i=0xFFFF;
		}while ((tmp>0) && ((result & 9) || (r==0))); flag*=(i!=0);

		i=0x10000;do{r=sceCdReadConfig(mem, &result);tmp=i;i=0xFFFF;
		}while ((tmp>0) && ((result & 9) || (r==0))); flag*=(i!=0);

		i=0x10000;do{r=sceCdCloseConfig(&result);tmp=i;i=0xFFFF;
		}while ((tmp>0) && ((result & 9) || (r==0))); flag*=(i!=0);


		i=0x10000;do{r=sceCdOpenConfig(1, 0, 2, &result);tmp=i;i=0xFFFF;
		}while ((tmp>0) && ((result & 9) || (r==0))); flag*=(i!=0);

		i=0x10000;do{r=sceCdReadConfig(mem+60, &result);tmp=i;i=0xFFFF;
		}while ((tmp>0) && ((result & 9) || (r==0))); flag*=(i!=0);

		i=0x10000;do{r=sceCdCloseConfig(&result);tmp=i;i=0xFFFF;
		}while ((tmp>0) && ((result & 9) || (r==0))); flag*=(i!=0);

		mem[15] = (mem[15] & 0xF7) | ((mem[75] >> 3) & 1);
	}

	if (flag==0)
		*(int*)0x3C0=0;

	if (CDVDreg_READY & 2==0)	return 1;
	if (CDVDreg_READY & 4!=0)	return 1;

	i=0x10000;do{r=sceCdOpenConfig(1, 0, 1, &result);tmp=i;i=0xFFFF;
	}while ((tmp>0) && ((result & 9) || (r==0)));

	i=0x10000;do{r=sceCdReadConfig(&data, &result);tmp=i;i=0xFFFF;
	}while ((tmp>0) && ((result & 9) || (r==0)));

	i=0x10000;do{r=sceCdCloseConfig(&result);tmp=i;i=0xFFFF;
	}while ((tmp>0) && ((result & 9) || (r==0)));

	for (flag=0, i=0; i<15; i++)
		if (data[i]){
			flag=1;
			data[i]=0;
		}
	if (flag==0)	return 1;

	i=0x10000;do{r=sceCdOpenConfig(1, 1, 1, &result);tmp=i;i=0xFFFF;
	}while ((tmp>0) && ((result & 9) || (r==0)));

	i=0x10000;do{r=sceCdWriteConfig(&data, &result);tmp=i;i=0xFFFF;//data[i]==0! ;)
	}while ((tmp>0) && ((result & 9) || (r==0)));

	i=0x10000;do{r=sceCdCloseConfig(&result);tmp=i;i=0xFFFF;
	}while ((tmp>0) && ((result & 9) || (r==0)));

	return 1;	//does not get resident
}

//////////////////////////////entrypoint///////////////////////////////
struct export eeconf_stub={
	0x41C00000,
	0,
	VER(1, 1),	// 1.1 => 0x101
	0,
	"eeconfig",
	(func)eeconf_start,	// entrypoint
	(func)eeconf_retonly,
	(func)eeconf_retonly,
	(func)eeconf_retonly,
	(func)eeconf_retonly,
	(func)eeconf_retonly,
	(func)eeconf_retonly,
	(func)eeconf_retonly,
	0
};

///////////////////////////////////////////////////////////////////////
void eeconf_retonly(){}
