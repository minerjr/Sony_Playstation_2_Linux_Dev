//[module]	TIMEMANP
//[processor]	IOP
//[type]	ELF-IRX
//[size]	3033(0xBD9)
//[bios]	10000(0x26B70-0x27750)
//[iopboot]	07
//[loaded @]	00007D00-?
//[name]	Timer_Manager
//[version]	0x101
//[memory map]	0xBF801100, 0xBF801110, 0xBF801120,
//		0xBF801450
//		0xBF801480, 0xBF801490, 0xBF8014A0
//[handlers]	-
//[entry point]	timrman_start, timrman_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com) 12 October 2002

#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries)
#include "..\include\intrman.h"		//(0x102,CpuSuspendIntr,CpuResumeIntr,QueryIntrContext)

#include "..\include\err.h"
#include "..\include\timeman.h"

#define CONFIG_1450		(*(volatile int*)0xBF801450)

struct TIMRMAN{	//sizeof==12
	int	hwreg;		//+00
	char	source,		//+04
		size;		//+05
	short	prescale;	//+06
	int	allocated;	//+08
} t[6]={
{RTC2, TC_SYSCLOCK,		     TIMER_SIZE_16, TIMER_PRESCALE_8, 0},
{RTC0, TC_SYSCLOCK|TC_PIXEL|TC_HOLD, TIMER_SIZE_16, TIMER_PRESCALE_1, 0},
{RTC1, TC_SYSCLOCK|TC_HLINE|TC_HOLD, TIMER_SIZE_16, TIMER_PRESCALE_1, 0}
};

extern struct export timrman_stub;	//not extern; just forward

//////////////////////////////entrypoint///////////////////////////////[00]
int  timrman_start(int argc, char* argv[]){
    register int i;
	if ((PRId>=0x10) && !(CONFIG_1450 & 8))	return 1;

	for (i=5; i>=0; i--)	t[i].allocated=0;

	return (RegisterLibraryEntries(&timrman_stub)>0);	//loadcore
}

///////////////////////////////////////////////////////////////////////[03]
void *timrman_call3(){
	return t;	//address of the array
}

///////////////////////////////////////////////////////////////////////[04]
int  AllocHardTimer(int source, int size, int prescale){
    register int	i;
	int				x;

	if (QueryIntrContext())	return ERROR_INTR_CONTEXT;	//intrman

	CpuSuspendIntr(&x);					//intrman
	
	for (i=0; i<6; i++)
		if (!t[i].allocated   && (t[i].source & source) &&
		    (t[i].size==size) && (t[i].prescale>=prescale)){
			t[i].allocated++;	//u8
			CpuResumeIntr(x);			//intrman
			return t[i].hwreg>>2;
		}

	CpuResumeIntr(x);					//intrman
	return ERROR_NO_TIMER;
}

///////////////////////////////////////////////////////////////////////[05]
int  ReferHardTimer(int source, int size, int mode, int modemask){
    register int	i;
	int				x;

	if (QueryIntrContext())	return ERROR_INTR_CONTEXT;	//intrman

	CpuSuspendIntr(&x);					//intrman
	
	for (i=0; i<6; i++)
		if (t[i].allocated && (t[i].source & source) && (t[i].size==size) &&
		    (int)(GetTimerStatus(t[i].hwreg>>2) & modemask)==mode){
			t[i].allocated++;	//u8
			CpuResumeIntr(x);			//intrman
			return t[i].hwreg>>2;
		}

	CpuResumeIntr(x);					//intrman
	return ERROR_NO_TIMER;
}

///////////////////////////////////////////////////////////////////////[10]
int  GetHardTimerIntrCode(int timid){
	switch(timid<<2){
	case RTC2:	return INT_RTC2;
	case RTC0:	return INT_RTC0;
	case RTC1:	return INT_RTC1;

	case RTC4:	return INT_RTC4;
	case RTC3:	return INT_RTC3;
	case RTC5:	return INT_RTC5;
	}
	return ERROR_UNK;
}

///////////////////////////////////////////////////////////////////////[06]
int  FreeHardTimer(int timid){
    register int	i;
	int				x;

	if (QueryIntrContext())	return ERROR_INTR_CONTEXT;	//intrman

	for (i=0; i<6; i++)
		if (t[i].hwreg==(timid<<2))
			break;

	if ((i<6) && (t[i].allocated)){
		CpuSuspendIntr(&x);				//intrman
		t[i].allocated--;
		CpuResumeIntr(x);				//intrman
		return ERROR_OK;
	}
	return ERROR_NO_TIMER;

}

///////////////////////////////////////////////////////////////////////[07]
void SetTimerMode(int timid, int mode){
	*(volatile short*)((timid<<2)+4) = mode;
}

///////////////////////////////////////////////////////////////////////[08]
unsigned int GetTimerStatus(int timid){
	return *(volatile unsigned short*)((timid<<2)+4);
}

///////////////////////////////////////////////////////////////////////[09]
void SetTimerCounter(int timid, unsigned int count){
	if ((timid<<2) < RTC3)
		*(volatile short*)((timid<<2)+0)=count;
	else
		*(volatile   int*)((timid<<2)+0)=count;
}

///////////////////////////////////////////////////////////////////////[0A]
unsigned int GetTimerCounter(int timid){
	if ((timid<<2) < RTC3)
		return *(volatile short*)((timid<<2)+0);
	else
		return *(volatile   int*)((timid<<2)+0);
}

///////////////////////////////////////////////////////////////////////[0B]
void SetTimerCompare(int timid, unsigned int compare){
	if ((timid<<2)+8 < RTC3)
		*(volatile short*)((timid<<2)+8)=compare;
	else
		*(volatile   int*)((timid<<2)+8)=compare;
}

///////////////////////////////////////////////////////////////////////[0C]
unsigned int GetTimerCompare(int timid){
	if ((timid<<2)+8 < RTC3)
		return *(volatile short*)((timid<<2)+8);
	else
		return *(volatile   int*)((timid<<2)+8);
}

///////////////////////////////////////////////////////////////////////[0D]
void SetHoldMode(int holdnum, int mode){return;}

///////////////////////////////////////////////////////////////////////[0E]
unsigned long GetHoldMode(int holdnum){return 0;}

///////////////////////////////////////////////////////////////////////[0F]
unsigned long GetHoldReg(int holdnum){return 0;}

void timrman_retonly();
//////////////////////////////entrypoint///////////////////////////////
struct export timrman_stub={
	0x41C00000,
	0,
	VER(1, 1),	// 1.1 => 0x101
	0,
	"timrman",
	(func)timrman_start,	// entrypoint
	(func)timrman_retonly,
	(func)timrman_retonly,
	(func)timrman_call3,
	(func)AllocHardTimer,
	(func)ReferHardTimer,
	(func)FreeHardTimer,
	(func)SetTimerMode,
	(func)GetTimerStatus,
	(func)SetTimerCounter,
	(func)GetTimerCounter,
	(func)SetTimerCompare,
	(func)GetTimerCompare,
	(func)SetHoldMode,
	(func)GetHoldMode,
	(func)GetHoldReg,
	(func)GetHardTimerIntrCode,
	0
};

///////////////////////////////////////////////////////////////////////[01,02]
void timrman_retonly(){}
