//[module]	SIFCMD
//[processor]	IOP
//[type]	ELF-IRX
//[size]	8753(0x2231)
//[bios]	10000(0x59770-0x5B9B0)
//[iopboot]	20
//[loaded @]	00017D00-0001A800
//[name]	IOP_SIF_rpc_interface
//[version]	0x101
//[memory map]	
//[handlers]	
//[entry point]	sifcmd_start, sifcmd_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries,QueryBootMode)
#include "..\include\intrman.h		//(0x102,RegisterIntrHandler,ReleaseIntrHandler,EnableIntr,DisableIntr,CpuSuspendIntr,CpuResumeIntr)
#include "..\include\stdio.h		//(0x102,printf)
#include "..\include\sifman.h		//(0x101,sifman_deinit,sceSifInit,sceSifSetDChain,sceSifSetDma,sifman_call22_setBD000020,sifman_call24_setBD000030,sifman_call27_setBD000010,sceSifCheckInit)
#include "..\include\thbase.h		//(0x101,GetThreadId,SleepThread,iWakeupThread,GetSystemStatusFlag)
#include "..\include\thevent.h		//(0x101,iSetEventFlag,WaitEventFlag)

/////////////////////// data
int sifInitRpc=0;
/////////////////////// bss [cmd]
char sif1_rcvBuffer[8*16];			//8 qwords
char b[4*16];					//not used
struct tag_cmd_common{
	char		*sif1_rcvBuffer,	//+00
			*b,			//+04
			*saddr;			//+08
	sceSifCmdData	*sysCmdBuffer;		//+0C
	int		sysCmdBufferSize;	//+10
	sceSifCmdData	*cmdBuffer;		//+14
	int		cmdBufferSize,		//+18
			*Sreg,			//+1C
			systemStatusFlag;	//+20
	void		(*func)(int);		//+24
	int		param,			//+28
			_pad;			//+2C
} cmd_common;					//=30
sceSifCmdData	sysCmds[32];
int		Sreg[32];
/////////////////////// bss [rpc]
int x[512], y[512];
struct tag_rpc_common{
	int		pid;
	RPC_PACKET	*paddr;
	int		size;
	RPC_PACKET	*paddr2;
	int		size2;
	void		*next;
	int		count;
	int		base;
	void		*queue;
	int		_pad0,
			_pad1,
			_pad2;
} rpc_common;

///////////////////////////////////////////////////////////////////////
//////////////////////////// CMD //////////////////////////////////////
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////
void cmd80000001_SET_SREG(sceSifCmdSRData packet, common)
	common->Sreg[packet->rno]=packet->value;
}

///////////////////////////////////////////////////////////////////////
void cmd80000000_CHANGE_SADDR(sceSifCmdCSData *packet, common){
	common->saddr=packet->newaddr;
}

///////////////////////////////////////////////////////////////////////[06]
int sceSifGetSreg(int index){
	return Sreg[index];
}

///////////////////////////////////////////////////////////////////////[07]
int sceSifSetSreg(int index, unsigned int value){
	return Sreg[index]=value;
}

///////////////////////////////////////////////////////////////////////
void *getCmdCommon(){
	return &cmd_common;
}

///////////////////////////////////////////////////////////////////////
void cmd80000002_INIT_CMD(sceSifCmdCSData *packet, common){
	if (packet->hdr.opt==0){
		iSetEventFlag(common->systemStatusFlg, 0x100);
		sifman_call22_setBD000020(0x20000);
		common->saddr=packet->newaddr;
	}else
		iSetEventFlag(common->systemStatusFlg, 0x800);
}

//////////////////////////////entrypoint///////////////////////////////[00]
int sifcmd_start(int argc, char* argv[]){
	register int *v, i;

	if (v=QueryBootMode(3)){
		if (v[1] & 1){	printf(" No SIF service(sifcmd)\n");return 1;}
		if (v[1] & 2){	printf(" No SIFCMD/RPC service\n"); return 1;}
	}

	if (sceSifCheckInit()==0)
		sceSifInit();

	if (RegisterLibraryEntries(&sifcmd_stub))	return 1;

	cmd_common->rcvBuffer=sif1_rcvBuffer;
	cmd_common->b=&b;
	cmd_common->stdCmdBuffer=&stdCmd;
	cmd_common->stdCmdBufferSize=32;
	cmd_common->saddr=0;
	cmd_common->cmdBuffer=0;
	cmd_common->cmdBufferSize=0;
	cmd_common->Sreg=&Sreg;
	cmd_common->func=0;
	cmd_common->param=0;

	for (i=0; i<32; i++){
		stdCmd[i].func=0;
		stdCmd[i].data=0;
	}
	for (i=31; i>=0; i--)
		Sreg[i]=0;

	sysCmds[0].func=cmd80000000_CHANGE_SADDR;
	sysCmds[0].data=&cmd_common;

	sysCmds[1].func=cmd80000001_SET_SREG;
	sysCmds[1].data=&cmd_common;

	cmd_common=systemStatusFlg=GetSystemStatusFlag();
	
	sysCmds[1].func=cmd80000002_INIT_CMD;
	sysCmds[1].data=&cmd_common;

	RegisterIntrHandler(INT_DMA10, 1, SIF1_handler, &cmd_common);
	EnableIntr(INT_DMA10 | IMODE_DMA_IQE);

	sifman_call27_setBD000010(sif1_rcvBuffer);

	return 0;
}

///////////////////////////////////////////////////////////////////////[02]
int sifcmd_deinit(){
	int x;
	DisableIntr(INT_DMA10, &x);
	ReleaseIntrHandler(INT_DMA10);
	sifman_deinit();
	return 0;
}

///////////////////////////////////////////////////////////////////////[04]
void sceSifInitCmd(){
	sifman_call24_setBD000030(0x20000);
	WaitEventFlag(cmd_common.systemStatusFlg, 0x100, 0, 0);
}

///////////////////////////////////////////////////////////////////////[05]
void sceSifExitCmd(){
	int x;
	DisableIntr(INT_DMA10, &x);
	ReleaseIntrHandler(INT_DMA10);
}

///////////////////////////////////////////////////////////////////////[08]
sceSifCmdData *sceSifSetCmdBuffer(sceSifCmdData *cmdBuffer, int size){
	register sceSifCmdData *old;
	old=cmd_common.cmdBuffer;
	cmd_common.cmdBuffer=cmdBuffer;
	cmd_common.cmdBufferSize=size;
	return old;
}

///////////////////////////////////////////////////////////////////////[09]
sceSifCmdData *sceSifSetSysCmdBuffer(sceSifCmdData *sysCmdBuffer, int size){
	register sceSifCmdData *old;
	old=cmd_common.sysCmdBuffer;
	cmd_common.sysCmdBuffer=sysCmdBuffer;
	cmd_common.sysCmdBufferSize=size;
	return old;
}

///////////////////////////////////////////////////////////////////////[0A]
void sceSifAddCmdHandler(unsigned int pos, sceSifCmdHandler f, void *data){
	if (pos<0){
		cmd_common.stdCmdBuffer[pos & 0x1FFFFFFF].func=f;
		cmd_common.stdCmdBuffer[pos & 0x1FFFFFFF].data=data;
	}else{
		cmd_common.cmdBuffer   [pos & 0x1FFFFFFF].func=f;
		cmd_common.cmdBuffer   [pos & 0x1FFFFFFF].data=data;
	}
}

///////////////////////////////////////////////////////////////////////[0B]
void sceSifRemoveCmdHandler(unsigned int pos){
	if (pos<0)
		cmd_common.stdCmdBuffer[pos & 0x1FFFFFFF].func=0;
	else
		cmd_common.cmdBuffer   [pos & 0x1FFFFFFF].func=0;
}

///////////////////////////////////////////////////////////////////////
unsigned int sendCmd(unsigned int pos, int mode, void *cp, int ps, void *src, void *dst, int size){
	int x;
	sifman_DMA dma[2];
	register int count, y;

	if (ps<16 || ps>112)	return 0;

	count=0;
	if (size>0){
		count=1;
		dma[0].dst=dst;
		dma[0].size=size;
		dma[0].attr=0;
		dma[0].src=src;
		cp->daddr=dst;
		cp->dsize=size;
	}else{
		cp->daddr=0;
		cp->dsize=0;
	}
	count++;
	cp->psize=ps;
	cp->fcode=pos;
	dma[count-1].src=cp;
	dma[count-1].attr=SIF_DMA_INT_O;	//calls SIF0 handler
	dma[count-1].size=ps;			//on EE side after transfer;)
	dma[count-1].dst=cmd_common.saddr;
	if (mode & 1)	//interrupt mode
		return sceSifSetDma(dma, count);
	else{
		CpuSuspendIntr(&x);
		y=sceSifSetDma(dma, count);
		CpuResumeIntr(x);
		return y;
	}
}

///////////////////////////////////////////////////////////////////////[0C]
unsigned int sceSifSendCmd(unsigned int pos, void *cp, int ps, void *src, void *dst, int size){
	return sendCmd(pos, 0, cp, ps, src, dst, size);
}

///////////////////////////////////////////////////////////////////////[0D]
unsigned int isceSifSendCmd(unsigned int pos, void *cp, int ps, void *src, void *dst, int size){
	return sendCmd(pos, 1, cp, ps, src, dst, size);
}

///////////////////////////////////////////////////////////////////////[1A]
void sifcmd_call26_setSif1CB(void *func, int param){
	cmd_common.func =func;
	cmd_common.param=param;
}

///////////////////////////////////////////////////////////////////////[1B]
void sifcmd_call27_resetSif1CB(){
	cmd_common.func =0;
	cmd_common.param=0;
}

///////////////////////////////////////////////////////////////////////
void SIF1_handler(void *common){
	int buf[112/4];
	register int i, ps;
	register sceSifCmdData *scd;

	if (common->func)
		common->func(common->param);

	packet=common->sif1_rcvBuffer;

	if ((ps=packet->psize & 0xFF)==0){
		sceSifSetDChain();
		return 1;
	}
	packet->psize=0;

	ps=(ps+3<0 ? ps+6 : ps+3)/4;
	for (i=0; i<ps; i++)
		buf[i]=packet[i];

	sceSifSetDChain();
	if (buf->fcode<0){
		if (buf->fcode & 0x7FFFFFFF>=common->sysCmdBufferSize)
			return 1;
		scd=&common->sysCmdBuffer[buf->fcode & 0x7FFFFFFF];
	}else{
		if (buf->fcode>=common->cmdBufferSize)
			return 1;
		scd=&common->cmdBuffer[buf->fcode];
	}
	if (scd->func)
		scd->func(buf, scd->data);

	return 1;
}

///////////////////////////////////////////////////////////////////////
//////////////////////////// RPC //////////////////////////////////////
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////[0E]
void sceSifInitRpc(unsigned int mode){
	sceSifInitCmd();
	CpuSuspendIntr(&x);

	if (sifInitRpc){
		CpuResumeIntr(x);		
	}else{
		sifInitRpc=1;
		rpc_common.paddr=&x;
		rpc_common.size=32;
		rpc_common.paddr2=0;
		rpc_common.size2=0;
		rpc_common.next=&y;
		rpc_common.count=32;
		rpc_common.base=0;
		rpc_common.pid=1;

		sceSifAddCmdHandler(0x80000008, cmd80000008_END,   &rpc_common);
		sceSifAddCmdHandler(0x80000009, cmd80000009_BIND,  &rpc_common);
		sceSifAddCmdHandler(0x8000000A, cmd8000000A_CALL,  &rpc_common);
		sceSifAddCmdHandler(0x8000000C, cmd8000000C_RDATA, &rpc_common);

		CpuResumeIntr(x);

		x->rno  =0;
		x->value=1;
		sceSifSendCmd(0x80000001, &x, sizeof(sceSifCmdSRData), 0, 0, 0);
	}
	WaitEventFlag(GetSystemStatusFlag(), 0x800, 0, 0);
}

///////////////////////////////////////////////////////////////////////
RPC_PACKET rpc_get_packet(common){
	int x;
	register int pid, i;

	CpuSuspendIntr(&x);
	
	for (i=0, packet=common->paddr;  i<common->size;  i++)
		if (packet[i]->rec_id & 2==0)	goto found;
	for (i=0, packet=common->paddr2; i<common->size2; i++)
		if (packet[i]->rec_id & 2==0)	goto found;

	CpuResumeIntr(x);
	return 0;

found:	packet[i]->rec_id |= 2;
	pid=++common->pid;
	if (pid == 1)
		//pid=1;	//stupid
		common->pid++;
	packet[i]->pid=pid;
	packet[i]->paddr=&packet[i];
	CpuResumeIntr(x);
	return &packet[i];
}

///////////////////////////////////////////////////////////////////////
void rpc_free_packet(packet){
	packet->pid     = 0;
	packet->rec_id &= 0xFFFFFFFD;	//~2
}

///////////////////////////////////////////////////////////////////////
epacket rpc_get_fpacket(common){
	register int i;

	//assert(common->count != 0)
	i=common->base % common->count
	//assert(common->count != -1)
	//assert(common->base != 0x8000)
	common->base=i;
	common->base=i+1;
	return common->next[i];		//sizeof == 0x40
}

///////////////////////////////////////////////////////////////////////
void cmd80000008_END(packet, common){
	if (packet->command==0x8000000A){
		if (packet->client->func)
			packet->client->func(packet->client->para);
	}else
	if (packet->command==0x80000009){
		packet->client->serve=packet->server;
		packet->client->buff =packet->buff;
		packet->client->cbuff=packet->cbuff;
	}

	if (packet->client->rpcd.tid>=0)
		iWakeupThread(packet->client->rpcd.tid);

	rpc_free_packet(packet->client->rpcd.paddr);
	packet->client->rpcd.paddr=0;
}

///////////////////////////////////////////////////////////////////////
void cmd8000000C_RDATA(packet, common){
	epacket=rpc_get_fpacket(common);

	epacket->paddr  =packet->paddr;
	epacket->command=0x8000000C;
	epacket->client =packet->client;

	isceSifSendCmd(0x80000008, epacket, 0x40, packet->src, packet->dst, packet->size);
}

///////////////////////////////////////////////////////////////////////[17]
int sceSifGetOtherData(sceSifReceiveData *rd, void *src, void *dst, int size, unsigned int mode){

	if ((packet=rpc_get_packet(&rpc_common))==0)
		return -1;

	rd->rpcd.paddr=packet;
	rd->rpcd.pid  =packet->pid;
	packet->paddr=packet;
	packet->client=rd;
	packet->src=src;
	packet->dst=dst;
	packet->size=size;

	if (mode & 1==0){
		rd->rpc.tid=GetThreadId();
		if (sceSifSendCmd(0x8000000C, packet, 0x40, 0, 0, 0)==0)
			return -2;
		SleepThread();
	}else{			//async
		rd->rpc.tid=-1;
		if (sceSifSendCmd(0x8000000C, packet, 0x40, 0, 0, 0)==0)
			return -2;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////
server search_svdata(command, common){
	for (q=common->queue; q; q=q->next)
		for (s=q->link; s; s=s->link)
			if (s->command==command)
				return s;
	return 0;
}

///////////////////////////////////////////////////////////////////////
void cmd80000009_BIND(packet, common){
	epacket=rpc_get_fpacket(common)

	epacket->paddr=packet->paddr;
	epacket->command=0x80000009;
	epacket->client=packet->client;
	
	s=search_svdata(packet->fno, common)
	if (s==0){
		epacket->server=0;
		epacket->buff  =0;
		epacket->cbuff =0;
	}else{
		epacket->server=s;
		epacket->buff  =s->buff;
		epacket->cbuff =s->cbuff;
	}
	isceSifSendCmd(0x80000008, epacket, 0x40, 0, 0, 0);
}

///////////////////////////////////////////////////////////////////////[0F]
int sceSifBindRpc(sceSifClientData *client, unsigned int number, unsigned int mode){
	client->command=0;
	client->serve=0;

	packet=rpc_get_packet(rpc_common);
	if (packet==0)	return -1;

	client->rpcd.paddr=packet;
	client->rpcd.pid=packet->pid;
	packet->paddr=packet;
	packet->client=client;
	packet->fno=number;
	
	if (mode & 1==0){
		client->rpcd.tid=GetThreadId();
		if (sceSifSendCmd(0x80000009, packet, 0x40, 0, 0, 0)==0)
			return -2;
		SleepThread();
	}else{		//async
		client->rpcd.tid=-1;
		if (sceSifSendCmd(0x80000009, packet, 0x40, 0, 0, 0)==0)
			return -2;
	}
	return 0;
}

///////////////////////////////////////////////////////////////////////
void cmd8000000A_CALL(packet, common){
	qd=packet->server->base;
	if (qd->start==0)	qd->start=packet->server;
	else			qd->end->link=packet->server;
	qd->end=packet->server;
	packet->server->paddr=packet->paddr;
	packet->server->client=packet->client;
	packet->server->fno=packet->fno;
	packet->server->size=packet->size;
	packet->server->receive=packet->receive;
	packet->server->rsize=packet->rsize;
	packet->server->rmode=packet->rmode;
	if ((qd->key>=0) && (qd->active==0))
		iWakeupThread(qd->key);
}

///////////////////////////////////////////////////////////////////////[10]
int sceSifCallRpc(sceSifClientData *client, unsigned int fno, unsigned int mode, void *send, int ssize, void *receive, int rsize, sceSifEndFunc end_func, void *end_para){
	if ((packet=rpc_get_packet(&rpc_common))==0)
		return -1;
	client->rpcd.paddr=packet;
	client->func=end_func;
	client->para=end_para;
	client->rpcd.pid=packet->pid;

	packet->paddr  =packet;
	packet->client =client;
	packet->fno    =fno;
	packet->size   =ssize;
	packet->receive=receive;
	packet->rsize  =rsize;
	packet->server =client->serve;

	if (mode & 1){
		packet->rmode=(end_func!=0);
		client->rpcd.tid=-1;
		if (sceSifSendCmd(0x8000000A, packet, 0x40, send, client->buff, ssize))
			return 0;
		return -2;
	}else{
		packet->rmode=1;
		client->rpcd.tid=GetThreadId();
		if (sceSifSendCmd(0x8000000A, packet, 0x40, send, client->buff, ssize)==0)
			return -2;
		SleepThread();
		return 0;
	}
}

///////////////////////////////////////////////////////////////////////[12]
int sceSifCheckStatRpc(sceSifRpcData *rd){
	return (rd->paddr && (rd->pid==rd->paddr->pid) && (rd->addr->rec_id & 2));
}

///////////////////////////////////////////////////////////////////////[13]
void sceSifSetRpcQueue(sceSifQueueData *qd, int key){
	int x;
	register sceSifQueueData *q, *i;

	CpuSuspendIntr(&x);
	v1=&;
	qd->key=key;
	qd->active=0;
	qd->link=0;
	qd->start=0;
	qd->end=0;
	qd->next=0;
	q=&rpc_common.queue;
	if (*q)	for (i=(q=*q)->next; i; i=q->next) q=q->next;
	*q=qd;
	CpuResumeIntr(x);
}

///////////////////////////////////////////////////////////////////////[11]
void sceSifRegisterRpc(sceSifServeData *sd, unsigned int command, sceSifRpcFunc func, void *buff, sceSifRpcFunc cfunc, void *cbuff, sceSifQueueData *qd){
	int x;
	register sceSifQueueData *q, *i;

	CpuSuspendIntr(&x);
	sd->command=command;
	sd->func=func;
	sd->buff=buff;
	sd->next=0;
	sd->link=0;
	sd->cfunc=cfunc;
	sd->cbuff=cbuff;
	sd->base=qd;

	if (qd->link==0)
		qd->link=sd;
	else{
		for (q=qd->link, i=q->link; i; i=q->link)
			q=q=>link;
		q->link=sd;
	}
	CpuResumeIntr(x);
}

///////////////////////////////////////////////////////////////////////[18]
sceSifServeData *sceSifRemoveRpc(sceSifServeData *sd, sceSifQueueData *qd){
	int x;
	register sceSifServeData *s;

	CpuSuspendIntr(&x);

	if ((s=qd->link)==sd)
		qd->link=s->link;
	else
		for ( ; s; s=s->link)
			if (s->link==sd){
				s->link=s->link->link;
				break;
			}
	CpuResumeIntr(x);
	return s;
}

///////////////////////////////////////////////////////////////////////[19]
sceSifQueueData *sceSifRemoveRpcQueue(sceSifQueueData *qd){
	int x;
	register sceSifQueueData *q;

	CpuSuspendIntr(&x);

	q=rpc_common.queue;
	if (q==qd)
		rpc_common.queue=q->next;
	else
		for ( q; q=q->next)
			if (q->next==qd){
				q->next=q->next->next;
				break;
			}
	CpuResumeIntr(x);
	return q;
}

///////////////////////////////////////////////////////////////////////[14]
sceSifServeData *sceSifGetNextRequest(sceSifQueueData *qd){
	int x;
	register sceSifServeData *s;

	CpuSuspendIntr(&x);

	if ((s=qd->start)==0)
		qd->active=0;
	else{
		qd->active=1;
		qd->start=qd->start->next;
	}

	CpuResumeIntr(x);
	return s;
}

///////////////////////////////////////////////////////////////////////[15]
void sceSifExecRequest(sceSifServeData *sd){
	int x;
	register int size, id, count, i;
	register void *buff;

	size=0;
	if (buff=sd->func(sd->fno, sd->buff, sd->size))
		size=sd->rsize;

	CpuSuspendIntr(&x);
	epacket=rpc_get_fpacket(&rpc_common);
	CpuResumeIntr(x);

	epacket->command=0x8000000A;
	epacket->client=sd->client;
	count=0;
	if (sd->rmode){
		while (sceSifSendCmd(0x80000008, epacket, 0x40, buff, sd->receive, size)==0);
		return;
	}else{
		epacket->pid=0;
		epacket->rec_id=0;
		if (size>0){
			count=1;
			dma[count-1].src=buff;
			dma[count-1].size=size;
			dma[count-1].attr=0;
			dma[count-1].dst=sd->receive;
		}
		count++;
		dma[count-1].src=epacket;
		dma[count-1].size=0x40;
		dma[count-1].attr=0;
		dma[count-1].dst=sd->paddr;
		do{
			CpuSuspendIntr(&x);
			id=sceSifSetDma(&dma, count);
        		CpuResumeIntr(x);
			if (id)	break;
			i=0xFFFF; do --i; while (i!=-1);
		while (id==0);
	}
}

///////////////////////////////////////////////////////////////////////[16]
void sceSifRpcLoop(sceSifQueueData *qd){
	register sceSifServeData *s;

	do{
		if (s=sceSifGetNextRequest(qd))
			sceSifExecRequest(s);
		else
			SleepThread();
	while (1);
}

//////////////////////////////entrypoint///////////////////////////////
.text:00001560 sifcmd_stub:    .word 0x41C00000
.text:00001564                 .word 0
.text:00001568                 .word 0x101
.text:0000156C aSifcmd:        .ascii "sifcmd"<0><0>
.text:00001574                 .word sifcmd_start
.text:00001578                 .word sifcmd_retonly
.text:0000157C                 .word sifcmd_deinit
.text:00001580                 .word sifcmd_retonly
.text:00001584                 .word sceSifInitCmd      # 04
.text:00001588                 .word sceSifExitCmd      # 05
.text:0000158C                 .word sceSifGetSreg      # 06
.text:00001590                 .word sceSifSetSreg      # 07
.text:00001594                 .word sceSifSetCmdBuffer  # 08
.text:00001598                 .word sceSifSetSysCmdBuffer  # 09
.text:0000159C                 .word sceSifAddCmdHandler  # 0A
.text:000015A0                 .word sceSifRemoveCmdHandler  # 0B
.text:000015A4                 .word sceSifSendCmd      # 0C
.text:000015A8                 .word isceSifSendCmd     # 0D
.text:000015A8                                          # 
.text:000015AC                 .word sceSifInitRpc      # 0E
.text:000015B0                 .word sceSifBindRpc      # 0F
.text:000015B4                 .word sceSifCallRpc      # 10
.text:000015B8                 .word sceSifRegisterRpc  # 11
.text:000015BC                 .word sceSifCheckStatRpc  # 12
.text:000015C0                 .word sceSifSetRpcQueue  # 13
.text:000015C4                 .word sceSifGetNextRequest  # 14
.text:000015C8                 .word sceSifExecRequest  # 15
.text:000015CC                 .word sceSifRpcLoop      # 16
.text:000015D0                 .word sceSifGetOtherData  # 17
.text:000015D4                 .word sceSifRemoveRpc    # 18
.text:000015D8                 .word sceSifRemoveRpcQueue  # 19
.text:000015DC                 .word sifcmd_call26_setSif1CB  # 1A
.text:000015E0                 .word sifcmd_call27_resetSif1CB  # 1B
.text:000015E4                 .word sifcmd_retonly
.text:000015E8                 .word sifcmd_retonly
.text:000015EC                 .word sifcmd_retonly
.text:000015F0                 .word sifcmd_retonly
.text:000015F4                 .word 0

0000 RPC_PACKET      struc  # (sizeof=0x1c)
0000 hdr:            sceSifCmdHdr ?
0010 rec_id:         .word ?
0014 paddr:          .word ?
0018 pid:            .word ?
001C RPC_PACKET      ends

0000 RPC_PACKET_END  struc  # (sizeof=0x30)
0000 packet:         RPC_PACKET ?
001C client:         .word ?
0020 command:        .word ?
0024 server:         .word ?
0028 buff:           .word ?
002C cbuff:          .word ?
0030 RPC_PACKET_END  ends

0000 RPC_PACKET_BIND struc  # (sizeof=0x24)
0000 packet:         RPC_PACKET ?
001C client:         .word ?
0020 fno:            .word ?
0024 RPC_PACKET_BIND ends

0000 RPC_PACKET_CALL struc  # (sizeof=0x38)
0000 packet:         RPC_PACKET_BIND ?
0024 size:           .word ?
0028 receive:        .word ?
002C rsize:          .word ?
0030 rmode:          .word ?
0034 server:         .word ?
0038 RPC_PACKET_CALL ends

0000 RPC_PACKET_RDATA struc  # (sizeof=0x2c)
0000 packet:         RPC_PACKET ?
001C client:         .word ?
0020 src:            .word ?
0024 dst:            .word ?
0028 size:           .word ?
002C RPC_PACKET_RDATA ends
