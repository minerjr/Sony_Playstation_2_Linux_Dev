//[module]	REBOOT
//[processor]	IOP
//[type]	ELF-IRX
//[size]	1985(0x7C1)
//[bios]	10000(0x3FEF0-0x406C0)
//[iopboot]	21
//[loaded @]	0001A800-0001AD00
//[name]	RebootByEE
//[version]	0x101
//[memory map]	BF801538(w)
//[handlers]	80000003(CMD,Reboot service module.(99/11/10))
//[entry point]	start
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\loadcore.h"	//(0x101,FlushDcache,QueryBootMode)
#include "..\include\intrman.h"		//(0x102,CpuEnableIntr)
#include "..\include\stdio.h"		//(0x102,printf)
#include "..\include\sifman.h"		//(0x101,sceSifInit,sifman_call22_setBD000020,sceSifCheckInit)
#include "..\include\sifcmd.h"		//(0x101,sceSifInitCmd,sceSifAddCmdHandler)
#include "..\include\modload.h"		//(0x101,ReBootStart)
#include "..\include\thbase.h"		//(0x101,CreateThread,StartThread,GetSystemStatusFlag)
#include "..\include\thevent.h"		//(0x101,iSetEventFlag,WaitEventFlag)

struct reboot{
        int    statusFlag;	//+00
        int    flag   		//+04
        char   data[80];  	//+08
} common;			//=58

int thread_entry();

//////////////////////////////entrypoint///////////////////////////////
int start(){
    struct ThreadParam	threadParam;
    register int	*v;
    register int 	thid;

	FlushDcache();						//loadcore
	if (v=QueryBootMode(3)){				//loadcore
		if (v[1] & 1){
			printf(" No SIF service(reboot)\n");	//stdio
			return 1;
		}
		if (v[1] & 2){
			printf(" No Reboot by EE service\n");	//stdio
			return 1;
		}
	}

	CpuEnableIntr();					//intrman
	threadParam.attr	=0x200;
	threadParam.entry	=thread_entry;
	threadParam.initPriority=10;
	threadParam.stackSize	=0x800;
	threadParam.option	=0;
	if ((thid=CreateThread(&threadParam))<=0)		//thbase
		return 1;
	StartThread(thid, 0);					//thbase
	return 0;
}

///////////////////////////////////////////////////////////////////////
int cmd80000003_REBOOT_CMD(sceSifCmdResetData *packet, struct reboot *common){
	for (i=0; i<packet.size; i++)
		common.data[i]=packet.data[i];
	common.flag=packet.flag;
	return iSetEventFlag(common.statusFlag, 0x400);		//thevent
}

///////////////////////////////////////////////////////////////////////
int thread_entry(){
	if (sceSifCheckInit()==0)				//sifman
		sceSifInit();					//sifman
	printf("Reboot service module.(99/11/10)\n");		//printf
	common.statusFlag=GetSystemStatusFlag();		//thbase
	sceSifInitCmd();					//sifcmd
	sceSifAddCmdHandler(0x80000003, cmd80000003_REBOOT_CMD, &common);//sifcmd
	WaitEventFlag(common.SystemStatusFlag, 0x400, 0, 0);	//thevent//?unk20?
	printf("Get Reboot Request From EE\n");			//stdio
	sifman_call22_setBD000020(0x20000);			//sifman
	DMAch_SIFA_CHCR=0;					//clear SIF1
	ReBootStart(common.data, common.flag);			//modload
	return 0;
}
