//[module]	SIO2MAN
//[processor]	IOP
//[type]	ELF-IRX
//[size]	?(0x?)
//[bios]	?(0x?-0x?)
//[iopboot2]	21
//[loaded @]	?
//[name]	sio2man
//[version]	0x101
//[memory map]	0xBF808200,0xBF808204,0xBF808208,0xBF80820C,\
//		0xBF808210,0xBF808214,0xBF808218,0xBF80821C, \ 16 entries
//		0xBF808220,0xBF808224,0xBF808228,0xBF80822C, /    array
//		0xBF808230,0xBF808234,0xBF808238,0xBF80823C,/
//		0xBF808240,0xBF808244,0xBF808248,0xBF80824C,
//		0xBF808250,0xBF808254,0xBF808258,0xBF80825C,
//		0xBF808260,0xBF808264,0xBF808268,0xBF80826C,
//		0xBF808270,0xBF808274,0xBF808278,0xBF80827C,
//		0xBF808280
//[handlers]	-
//[entry point]	_start, (export_stub)
//[made by]	Herben

#include "..\include\dmacman.h"		//(0x102, )

//#define DEBUG

struct SIO2_packet {
    unsigned int recvVal1; // 0x00
    unsigned int sendArray1[4]; // 0x04-0x10
    unsigned int sendArray2[4]; // 0x14-0x20

    unsigned int recvVal2; // 0x24

    unsigned int sendArray3[16]; // 0x28-0x64

    unsigned int recvVal3; // 0x68

    int sendSize; // 0x6C
    int recvSize; // 0x70

    unsigned char *sendBuf; // 0x74
    unsigned char *recvBuf; // 0x78

    unsigned int dmacAddress1;
    unsigned int dmacSize1;
    unsigned int dmacCount1;
    unsigned int dmacAddress2;
    unsigned int dmacSize2;
    unsigned int dmacCount2;
};

static int SIO2_initialized = 0;
static int sioIntCommon;
static int sioEventID;
static int sioThreadID;
SIO2_packet *packetAddr;

#define NULL (void *) (0)

ModuleInfo Module = {"sio2man", 0x0101 };

void _start(void) {
    SIO2_init();
}

// Export 1 & 3
void nullSub(void) { return; }

// Export 4
// Set
void SIO2_set8268_ctrl(unsigned int arg0) {
	*(unsigned int *) (0xBF808268) = arg0;
}

// Export 5
// Get
unsigned int SIO2_get8268_ctrl(void) {
	return(*(unsigned int *) (0xBF808268));
}

// Export 6
// Get
unsigned int SIO2_get826C_recv1(void) {
	return(*(unsigned int *) (0xBF80826C));
}

// Export 7
// Set
void SIO2_call7_send1(int entryNum, unsigned int val) {
	switch(entryNum) {
		case 0:
			*(unsigned int *) (0xBF808240) = val;
			return;
			break;
		case 1:
			*(unsigned int *) (0xBF808248) = val;
			return;
			break;
		case 2:
			*(unsigned int *) (0xBF808250) = val;
			return;
			break;
		case 3:
			*(unsigned int *) (0xBF808258) = val;
			return;
			break;
		default:
			break;
		}

	return;
}

// Export 8
// Get
unsigned int SIO2_call8_send1(int entryNum) {
	switch(entryNum) {
		case 0:
			return(*(unsigned int *) (0xBF808240));
			break;
		case 1:
			return(*(unsigned int *) (0xBF808248));
			break;
		case 2:
			return(*(unsigned int *) (0xBF808250));
			break;
		case 3:
			return(*(unsigned int *) (0xBF808258));
			break;
		default:
			break;
		}

	return(0);
}

// Export 9
// Set
void SIO2_call9_send2(int entryNum, unsigned int val) {
	switch(entryNum) {
		case 0:
			*(unsigned int *) (0xBF808244) = val;
			return;
			break;
		case 1:
			*(unsigned int *) (0xBF80824C) = val;
			return;
			break;
		case 2:
			*(unsigned int *) (0xBF808254) = val;
			return;
			break;
		case 3:
			*(unsigned int *) (0xBF80825C) = val;
			return;
			break;
		default:
			break;
		}

	return;
}

// Export 10
// Get
unsigned int SIO2_call10_send2(int entryNum) {
	switch(entryNum) {
		case 0:
			return(*(unsigned int *) (0xBF808244));
			break;
		case 1:
			return(*(unsigned int *) (0xBF80824C));
			break;
		case 2:
			return(*(unsigned int *) (0xBF808254));
			break;
		case 3:
			return(*(unsigned int *) (0xBF80825C));
			break;
		default:
			break;
		}

	return(0);
}

// Export 11
// Get
unsigned int SIO2_get8270_recv2(void) {
	return(*(unsigned int *) (0xBF808270));
}

// Export 12
// Set
void SIO2_call12_params(int entryNum, unsigned int val) {
	if(entryNum < 16)
		*(unsigned int *) (0xBF808200 + (entryNum * 4)) = val;
}

// Export 13
// Get
unsigned int SIO2_call13_params(int entryNum) {
	if(entryNum < 16)
		return(*(unsigned int *) (0xBF808200 + (entryNum * 4)));

	return(-1);
}

// Export 14
// Get
unsigned int SIO2_get8274_recv3(void) {
	return(*(unsigned int *) (0xBF808274));
}

// Export 15
// Set
void SIO2_set8278(unsigned int arg0) {
	*(unsigned int *) (0xBF808278) = arg0;
}

// Export 16
// Get
unsigned int SIO2_get8278(void) {
	return(*(unsigned int *) (0xBF808278));
}

// Export 17
// Set
void SIO2_set827C(unsigned int arg0) {
	*(unsigned int *) (0xBF80827C) = arg0;
}

// Export 18
// Get
unsigned int SIO2_get827C(void) {
	return(*(unsigned int *) (0xBF80827C));
}

// Export 19
// Set
void SIO2_set8260_datain(unsigned char arg0) {
	*(unsigned char *) (0xBF808260) = arg0;
}

// Export 20
// Get
unsigned char SIO2_get8264_dataout(void) {
	return(*(unsigned char *) (0xBF808264));
}

// Export 21
// Set
void SIO2_set8280_intr(unsigned int arg0) {
	*(unsigned int *) (0xBF808280) = arg0;
}

// Export 22
// Get
unsigned int SIO2_get8280_intr(void) {
	return(*(unsigned int *) (0xBF808280));
}

int SIO2_createEventFlag(void) {
	struct EventFlagParam param;

	param.attr = 2;
	param.option = 0;
	param.initPattern = 0;
	return(CreateEventFlag(&param));
}


void SIO2_sendPacket(struct SIO2_packet *p) {
	int i;


	for(i = 0; i < 4; i++) {
		SIO2_call7_send1(i, (*p).sendArray1[i]);
		SIO2_call9_send2(i, (*p).sendArray2[i]);
		}

	for(i = 0; i < 16; i++)
		SIO2_call12_params(i, (*p).sendArray3[i]);

	for(i = 0; i < (*p).sendSize; i++)
		*(unsigned char *) (0xBF808260) = (*p).sendBuf[i];

	if((*p).dmacAddress1 != 0) {
		dmacman_call28_SetDMA(DMAch_SIO2in, (*p).dmacAddress1, (*p).dmacSize1, (*p).dmacCount1, 1);  // from memory
		dmacman_call32_StartTransfer(DMAch_SIO2in);
		}

	if((*p).dmacAddress2 != 0) {
		dmacman_call28_SetDMA(DMAch_SIO2out, (*p).dmacAddress2, (*p).dmacSize2, (*p).dmacCount2, 0); // to memory
		dmacman_call32_StartTransfer(DMAch_SIO2out);
		}
}

void SIO2_recvPacket(struct SIO2_packet *p) {
	int i;

    (*p).recvVal1 = *(unsigned int *) (0xBF80826C);
    (*p).recvVal2 = *(unsigned int *) (0xBF808270);
    (*p).recvVal3 = *(unsigned int *) (0xBF808274);


    for(i = 0; i < (*p).recvSize; i++)
        (*p).recvBuf[i] = *(unsigned char *) (0xBF808264);
}

void SIO2_basicThread(void) {
	unsigned long result[4];

#ifdef DEBUG
	printf("SIO2MAN: SIO2_basicThread Start!\n");
#endif

	while(1) {
		WaitEventFlag(sioEventID, 0x05, 0x01, result);

		if((result[0] & 0x01) != 0) {
			ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x01);
			SetEventFlag(sioEventID, 0x02);
			}
		else if((result[0] & 0x04) != 0) {
			ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x04);
			SetEventFlag(sioEventID, 0x08);
			}
		else {
			printf("SIO2MAN: Woke up for unknown event(%08X)!\n", result[0]);
			return;
			}

// Wait for application to call our export 25
		WaitEventFlag(sioEventID, 0x10, 0, NULL);
		ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x10);

		*(unsigned int *) (0xBF808268) = (*(unsigned int *) (0xBF808268)) | 0x0C;
		SIO2_sendPacket(packetAddr);
		*(unsigned int *) (0xBF808268) = (*(unsigned int *) (0xBF808268)) | 0x01;

// Wait for the SIO2 interrupt to occur
		WaitEventFlag(sioEventID, 0x80, 0, NULL);
		ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x80);

// Recieve the reply packet
		SIO2_recvPacket(packetAddr);

// Signal SIO2_transferData to let it know the transfer is complete.
		SetEventFlag(sioEventID, 0x20);
		WaitEventFlag(sioEventID, 0x40, 0, NULL);
		ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x40);
		}
}

int SIO2_createBasicThread(void) {
	struct ThreadParam param;

	param.attr = TH_C;
	param.option = 0;
	param.entry = &SIO2_basicThread;
	param.stackSize = 0x2000;
	param.initPriority = 0x18;

	return(CreateThread(&param));
}

int SIO2_interruptHandler(unsigned int *common) {

	SIO2_set_intr8280(SIO2_get8280_intr());

	iSetEventFlag(common[1], 0x80);

	return(1);
}

// Export 0
int SIO2_init(void) {
	int oldStat;
	extern libhead sio2man_entry;

	SIO2_deInit();

	if(RegisterLibraryEntries(&sio2man_entry) != 0) {
		printf("SIO2MAN: Unable to register library entries!\n");
		return(NO_RESIDENT_END);
		}

	if(SIO2_initialized != 0) {
		printf("SIO2MAN: Already initialized!\n");
		return(NO_RESIDENT_END);
		}

	SIO2_initialized = 1;

	*(unsigned int *) (0xBF808268) = 0x3BC;

	sioEventID = SIO2_createEventFlag();
	sioThreadID = SIO2_createBasicThread();

	CpuSuspendIntr(&oldStat);

	RegisterIntrHandler(INUM_SIO2, HTYPE_C, &SIO2_interruptHandler, &sioIntCommon);
	EnableIntr(INUM_SIO2);

	CpuResumeIntr(oldStat);

	dmacman_call33_SetVal(DMAch_SIO2in,  0x03);
	dmacman_call33_SetVal(DMAch_SIO2out, 0x03);
	dmacman_call34_EnableDMAch(DMAch_SIO2in);
	dmacman_call34_EnableDMAch(DMAch_SIO2out);

	StartThread(sioThreadID, 0); // Start the "basicThread"

	return RESIDENT_END;
}

// Export 2
void SIO2_deInit(void) {
	int oldStat;

	CpuSuspendIntr(&oldStat);

	DisableIntr(INUM_SIO2, 0);
	ReleaseIntrHandler(INUM_SIO2);

	CpuResumeIntr(oldStat);

	dmacman_call35_DisableDMAch(DMAch_SIO2in);
	dmacman_call35_DisableDMAch(DMAch_SIO2out);
}

// Export 23
void SIO2_signalExchange1(void) {

// Signal the basic thread to let it know we want to do an exchange.
	SetEventFlag(sioEventID, 0x01);
// Wait for basic thread to acknowledge then clear the flag.
	WaitEventFlag(sioEventID, 0x02, 0, NULL);
	ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x02);
}

// Export 24
void SIO2_signalExchange2(void) {

// Signal the basic thread to let it know we want to do an exchange.
	SetEventFlag(sioEventID, 0x04);
// Wait for basic thread to acknowledge then clear the flag.
	WaitEventFlag(sioEventID, 0x08, 0, NULL);
	ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x08);
}

// Export 25
void SIO2_packetExchange(unsigned int arg0) {

// Set the address of the packet.
	packetAddr = (struct SIO2_packet *) arg0;

// Let the basic thread know we have the address set for the exchange.
	SetEventFlag(sioEventID, 0x10);

// Wait for the basic thread to finish it's stuff.
	WaitEventFlag(sioEventID, 0x20, 0, NULL);
	ClearEventFlag(sioEventID, 0xFFFFFFFF ^ 0x20);

// Let the basic thread know we're done.
	SetEventFlag(sioEventID, 0x40);
}
