//[module]	EESYNC
//[processor]	IOP
//[type]	ELF-IRX
//[size]	1177(0x499)
//[bios]	10000(0x406C0-0x40B60)
//[iopboot]	28
//[name]	SyncEE
//[version]	0x101
//[memory map]	-
//[handlers]	-
//[entry point]	start, export_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com)

#include "..\include\sifman.h"		//(0x101,sifman_call24_setBD000030)
#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries,QueryBootMode,loadcore_call20)

int start()
int retonly();

//////////////////////////////entrypoint///////////////////////////////
struct export export_stub={
	0x41C00000,
	0,
	VER(1, 1),	// 1.1 => 0x101
	0,
	"eesync",
	(func)start,	// entrypoint
	(func)retonly,
	(func)retonly,
	(func)retonly,
	(func)retonly,	// 4
	(func)retonly,	// 5
	0		// end of list
};

int SyncEE(int*, int);

//////////////////////////////entrypoint///////////////////////////////
int start(){
    int *v;
	if (v=QueryBootMode(3)){			//loadcore
		if (v[1] & 1) return 1;
		if (v[1] & 2) return 1;
	}
	if (RegisterLibraryEntries(&export_stub)<0)	//loadcore
		return 1;
	loadcore_call20_registerFunc(SyncEE, 2, NULL);	//loadcore
	return 0;
}

///////////////////////////////////////////////////////////////////////
int SyncEE(int*, int){
	sifman_call24_setBD000030(0x40000);		//sifman
	return 0;
}

///////////////////////////////////////////////////////////////////////
void retonly(){}
