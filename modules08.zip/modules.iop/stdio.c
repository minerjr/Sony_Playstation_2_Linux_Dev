//[module]	STDIO
//[processor]	IOP
//[type]	ELF-IRX
//[size]	3049(0xBE9)
//[bios]	10000(0x3D940-0x3E530)
//[iopboot]	17
//[loaded @]	00016200-?
//[name]	Stdio
//[version]	0x101
//[memory map]	-
//[handlers]	-
//[entry point]	stdio_start, stdio_stub
//[made by]	[RO]man (roman_ps2dev@hotmail.com) 30 January 2003

#include "..\include\loadcore.h"	//(0x101,RegisterLibraryEntries)
#include "..\include\sysclib.h"		//(0x101,look_ctype_table,prnt)
#include "..\include\ioman.h"		//(0x102,read,write)

//////////////////////////////entrypoint///////////////////////////////
int stdio_start(int argc, char* argv[]){
	return stdio_init();
}

///////////////////////////////////////////////////////////////////////
int stdio_init(){
	return RegisterLibraryEntries(&stdio_stub);		//loadcore
}

//////////////////////////////entrypoint///////////////////////////////
struct export stdio_stub={
	0x41C00000,
	0,
	VER(1, 2),	// 1.2 => 0x102
	0,
	"stdio",
	(func)stdio_start,	// entrypoint
	(func)stdio_init,
	(func)stdio_retonly,
	(func)stdio_retonly,
	(func)printf,
	(func)getchar,
	(func)putchar,
	(func)puts,
	(func)gets,
	(func)fdprintf,
	(func)fdgetc,
	(func)fdputc,
	(func)fdputs,
	(func)fdgets,
	0
};

///////////////////////////////////////////////////////////////////////
void stdio_retonly(){}

struct unk{
	short	fd;
	short	size;
	char	data[64];
};

///////////////////////////////////////////////////////////////////////
void sub_B0(struct unk *p, int c){
	register int s;

	switch(c){
	case 0x200:	p->size=0;					break;
	case 0x201:	if (p->size>0)	write(p->fd, p->data, p->size);	break;//ioman
	default:
		if (c==LF)	sub_B0(p, '\n');
		s=((int)(++p->size))<<16>>16;
		*((char*)p+s+3)=c;
		if (0x40==s){
			p->size=0;
			write(p->fd, p->data, 0x40);			//ioman
		}
	}
}

///////////////////////////////////////////////////////////////////////
int fdprintf(int fd, const char *format,...){
	struct unk v;
	
	v.fd=fd;
	v.size=0;
	return prnt(sub_B0, &v, format, &arg_8);		//sysclib
}

///////////////////////////////////////////////////////////////////////
int printf(const char *fmt,...){
	struct unk v;

	v.fd=STDOUT;
	v.size=0;
	return prnt(sub_B0, &v, format, &arg_4);		//sysclib
}

///////////////////////////////////////////////////////////////////////
int fdputc(int c, int fd){
	static int col;
	char x=c;

	switch(c<<24>>24){
	case TAB:
		write(fd, "        ", 8-(col & 7));		//ioman
		col &= 0xFFFFFFF8;
		col += 8;
		break;
	case LF:
		write(fd, "\r\n", 2);				//ioman
		col=0;
		break;
	default:
		if (look_ctype_table(c) & 0x97)	col++;		//sysclib
		write(fd, &x, 1);				//ioman
		break;
	}
	return c;
}

///////////////////////////////////////////////////////////////////////
int putchar(int c){
	return fdputc(c, STDOUT);
}

///////////////////////////////////////////////////////////////////////
int fdputs(char *s, int fd){
	register int c;
	if (s==NULL)
		s="<NULL>";
	while(c=*s++)			//c=(int)(*s++)<<24
		fdputc(c<<24>>24, fd);	//c>>24
	return 0;
}

///////////////////////////////////////////////////////////////////////
int puts(char *s){
	return fdputs(s, STDOUT);
}

///////////////////////////////////////////////////////////////////////
int fdgetc(int fd){
	char c;

	read(fd, &c, 1);					//ioman
	return c;
}

///////////////////////////////////////////////////////////////////////
int getchar(){
	return fdgetc(STDIN);
}

///////////////////////////////////////////////////////////////////////
char *fdgets(char *buf, int fd){
	register char *p=buf, *end=p+125;	//s0, s4

	while(1){
		c=fdgetc(fd);

		switch(c<<24>>24){
		case LF:
		case CR:
			fdputc(LF, fd ? fd : STDOUT);
			*p=0;
			return buf;
		case 0x8:	//BS
		case 127:	//BACKSPACE
			if (buf<p){
				p--;
				fdputc(0x8, , fd ? fd : STDOUT);
				fdputc(' ', , fd ? fd : STDOUT);
				fdputc(0x8, , fd ? fd : STDOUT);
			}
			break;
		case 0x16://SYN
			c=fdgetc(fd);
			if (p<end)	fdputc((*p++=c)<<24>>24, fd ? fd : STDOUT);
			else            fdputc(0x7 , fd ? fd : STDOUT);
			break;
		case TAB:
			c=' ';
		default:
			if ((look_ctype_table(c<<24>>24) & 0x97) && (p<end))	//sysclib
				fdputc((*p++=c)<<24>>24, fd ? fd : STDOUT);
			else	fdputc(0x7 , fd ? fd : STDOUT);
		}
	}
}

///////////////////////////////////////////////////////////////////////
char *gets(char *s){
	return fdgets(s, STDIN);
}
