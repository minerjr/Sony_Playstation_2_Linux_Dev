#ifndef __MODLOAD_H__
#define __MODLOAD_H__

#define MODLOAD_VER	0x101

void ReBootStart(int *, int);		//4 (21)

#endif//__MODLOAD_H__