#ifndef __FILEIO_H__
#define __FILEIO_H__

#define FILEIO_VER	0x101

//////////////////////////////////////////////// 80000001 fileio rpc service
#define FILEIO_OPEN	0
#define FILEIO_CLOSE	1
#define FILEIO_READ	2
#define FILEIO_WRITE	3
#define FILEIO_LSEEK	4
#define FILEIO_IOCTL	5
#define FILEIO_REMOVE	6
#define FILEIO_MKDIR	7
#define FILEIO_RMDIR	8
#define FILEIO_DOPEN	9
#define FILEIO_DCLOSE	10
#define FILEIO_DREAD	11
#define FILEIO_GETSTAT	12
#define FILEIO_CHSTAT	13
#define FILEIO_FORMAT	14
#define FILEIO_ADDDRV	15
#define FILEIO_DELDRV	16
/*************************** not in version 0x101
#define FILEIO_RENAME	17
#define FILEIO_CHDIR	18
#define FILEIO_SYNC	19
#define FILEIO_MOUNT	20
#define FILEIO_UMOUNT	21
#define FILEIO_LSEEK64	22
#define FILEIO_DEVCTL	23
#define FILEIO_SYMLINK	24
#define FILEIO_READLINK	25
#define FILEIO_IOCTL2	26
#define FILEIO_FSINIT	255
****************************/

struct fileio_OPEN{
	int	mode;
	char	name[0];
};

struct fileio_LSEEK{
	int	fd;
	int	offset;	//pos
	int	ref;	//mode
};

struct fileio_IOCTL{
	int	fd;
	int	io_code;
};

struct fileio_READ{
	int	fd;
	void	*buffer;
	int	size;
	void	*_intr_data;
};

struct fileio_WRITE{
	int	fd;
	void	*buffer;
	int	size;
	int	mis;
};

//////////////////////////////////////////////// 80000003 iopheap rpc service
#define IOPHEAP_ALLOC		1
#define IOPHEAP_FREE		2
#define IOPHEAP_LOAD		3
/*************************** not in version 0x101
#define IOPHEAP_ALLOCSYSMEMORY	4
****************************/

struct fileio_LOADIOPHEAP{
	char *buffer;
	char name[0];
};

#endif//__FILEIO_H__