#ifndef __SIFMAN_H__
#define __SIFMAN_H__

#define SIFMAN_VER	0x101

struct sifman_DMA{	//t_sif_dma_transfer
	void	*data;
	void	*addr;
	int	size;
	int	attr;
};

int	sifman_start(int argc, char* argv);		//0
void	sifman_deinit();				//2

void	sifman_sceSifGPUInit();				//4
void	sceSifInit();					//5 (21,25,26)
void	sceSifSetDChain();				//6
int	sceSifSetDma(struct sifman_DMA* psd, int len);	//7 (26)
int     sceSifDmaStat(int);				//8 (26)
void	sifman_call9_sceSifSend(struct sifman_DMA sd);	//9
void	sifman_call10_sceSifSendSync();			//10
int	sifman_call11_sceSifIsSending();		//11
void	sifman_call12_sceSifSetSIF0DMA(void *data, int size, int attr);	//12
void	sifman_call13_sceSifSendSync0();		//13
int	sifman_call14_sceSifIsSending0();		//14
void	sifman_call15_sceSifSetSIF1DMA(void *data, int size, int attr);	//15
void	sifman_call16_sceSifSendSync1();		//16
int	sifman_call17_sceSifIsSending1();		//17
void	sifman_call18_sceSifSetSIF2DMA(void *data, int size, int attr);	//18
void	sifman_call19_sceSifSendSync2();		/19
int	sifman_call20_sceSifIsSending2();		//20
int	sifman_call21_getBD000020();			//21
int	sifman_call22_setBD000020(int val);		//22(21)
int	sifman_call23_getBD000030();			//23
int	sifman_call24_setBD000030(int val);		//24(28)
int	sifman_call25_getBD000000();			//25
int	sifman_call26_getBD000010();			//26
int	sifman_call27_setBD000010(int val);		//27
void	sifman_call28();				//28
int	sceSifCheckInit();				//29(21,26)
void	sifman_call30(int (*_function)(int), int _param);//30
void	sifman_call31();				//31

#endif//__SIFMAN_H__