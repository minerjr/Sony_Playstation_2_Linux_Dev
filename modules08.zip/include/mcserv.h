#ifndef _MCSERV_H_
#define _MCSERV_H_

#define MCSERV_VER	0x101

#define MC2_GETINFO				1
#define MC2_OPEN					2
#define MC2_CLOSE				3
#define MC2_SEEK					4
#define MC2_READ					5
#define MC2_WRITE				6

#define MC2_FLUSH				10
#define MC2_MKDIR				11
#define MC2_CHDIR				12
#define MC2_GETDIR				13
#define MC2_SETFILEINFO			14
#define MC2_DELETE				15
#define MC2_FORMAT				16
#define MC2_UNFORMAT				17
#define MC2_GETENTSPACE			18
#define MC2_RENAME				19
#define MC2_CHANGETHREADPRIORITY	20
#define MC2_UDCHECKNEWCARD		53
#define MC2_INIT			254

#define MC_INIT				0x70
#define MC_OPEN				0x71
#define MC_CLOSE			0x72
#define MC_READ				0x73
#define MC_WRITE			0x74
#define MC_SEEK				0x75
#define MC_GETDIR			0x76
#define MC_FORMAT			0x77
#define MC_GETINFO			0x78
#define MC_DELETE			0x79
#define MC_FLUSH			0x7A
#define MC_CHDIR			0x7B
#define MC_SETFILEINFO			0x7C
#define MC_7D				0x7D
#define MC_7E				0x7E
#define MC_7F				0x7F
#define MC_UNFORMAT			0x80

#endif//_MCSERV_H_


