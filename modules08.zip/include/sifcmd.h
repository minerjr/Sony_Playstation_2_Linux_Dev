#ifndef __SIFCMD_H__
#define __SIFCMD_H__

#define SIFCMD_VER	0x101

#define SIF_CMDI_SYSTEM		0x80000000	// system function call
#define SIF_CMDC_CHANGE_SADDR	( SIF_CMDI_SYSTEM | 0x00000000)
#define SIF_CMDC_SET_SREG	( SIF_CMDI_SYSTEM | 0x00000001)
#define SIF_CMDC_INIT_CMD	( SIF_CMDI_SYSTEM | 0x00000002)
#define SIF_CMDC_RESET_CMD	( SIF_CMDI_SYSTEM | 0x00000003)

#define SIF_CMDC_RPC_END	( SIF_CMDI_SYSTEM | 0x00000008)
#define SIF_CMDC_RPC_BIND	( SIF_CMDI_SYSTEM | 0x00000009)
#define SIF_CMDC_RPC_CALL	( SIF_CMDI_SYSTEM | 0x0000000A)
#define SIF_CMDC_RPC_RDATA	( SIF_CMDI_SYSTEM | 0x0000000C)

typedef  struct {
	unsigned int	psize:8; // packet size [16->112]
	unsigned int	dsize:24;// extra data size
	unsigned int	daddr;   // extra data address
  	unsigned int	fcode;	 // function code
	unsigned int	opt;	 // optional user parameter
} sceSifCmdHdr;

typedef struct {
	sceSifCmdHdr	chdr;
	void		*newaddr;
} sceSifCmdCSData;

typedef struct {
	sceSifCmdHdr	chdr;
	int		rno;
	unsigned int	value;
} sceSifCmdSRData;

typedef struct {
	sceSifCmdHdr	chdr;
	int		size;
	int		flag;
	char		arg[80];
} sceSifCmdResetData;

struct sifcmd_RPC_SERVER_DATA{	//t_rpc_server_data
   int				command;	/* 04	00 */

   void  *			(*func)(u32, void *, int);	/* 05	01 */
   void				*buff;		/* 06	02 */
   int				size;		/* 07	03 */

   void  * 			(*func2)(u32, void *, int); /* 08	04 */
   void				*buff2;		/* 09	05 */
   int				size2;		/* 10	06 */

   struct sifcmd_RPC_CLIENT_DATA*client;	/* 11	07 */
   void				*pkt_addr;	/* 12	08 */
   int				rpc_number;	/* 13	09 */

   void				*receive;	/* 14	10 */
   int				rec_size;	/* 15	11 */
   int				has_async_ef;	/* 16	12 */
   int				rec_id;		/* 17	13 */

   struct sifcmd_RPC_SERVER_DATA*link;		/* 18	14 */
   struct sifcmd_RPC_SERVER_DATA*next;		/* 19	15 */
   struct sifcmd_RPC_DATA_QUEUE	*queued_object;	/* 20	16 */
};


struct sifcmd_RPC_HEADER{	//t_rpc_header
   void				*pkt_addr;	/* 04	00 */
   u32				rpc_id;		/* 05	01 */
   int				sema_id;	/* 06	02 */
   u32			 	mode;		/* 07	03 */
};


struct sifcmd_RPC_CLIENT_DATA{	//t_rpc_client_data
   struct sifcmd_RPC_HEADER	hdr;
   u32				command;	/* 04 	08 */
   void				*buff, 		/* 05 	09 */
      				*buff2;		/* 06 	10 */
   void     			(*end_function)	( void *);	/* 07 	11 */
   void				*end_param;	/* 08 	12*/
   struct sifcmd_RPC_SERVER_DATA*server;	/* 09 	13 */
};

struct sifcmd_RPC_RECEIVE_DATA{	//t_rpc_receive_data
   struct sifcmd_RPC_HEADER	hdr;
   void				*src,		/* 04 */
      				*dest;		/* 05 */
   int	                        size;		/* 06 */
};

struct sifcmd_RPC_DATA_QUEUE{	//t_rpc_data_queue
   int				thread_id,	/* 00 */
      				active;		/* 01 */
   struct sifcmd_RPC_SERVER_DATA*svdata_ref,	/* 02 */
      				*start,		/* 03 */
                                *end;		/* 04 */
   struct sifcmd_RPC_DATA_QUEUE	*next;  	/* 05 */
};

typedef int (*cmdh_func) (sceSifCmdHdr*, void*);
typedef int *(*rpch_func)(int code, int param1, int param2);

typedef struct {
	cmdh_func	func;
	void		*data;
} sceSifCmdData;

void	sceSifInitCmd();						//4 (21)
void	sceSifAddCmdHandler(int code, cmdh_func func, void *common);	//10(21)
void	sceSifInitRpc(int);						//14(26)
void	sceSifRegisterRpc(struct sifcmd_RPC_SERVER_DATA* sd,
			  int	cmd, rpch_func handler1, void *svrbuf1,
				     rpch_func handler2, void *svrbuf2,
			  struct sifcmd_RPC_DATA_QUEUE* dq);		//17(26)
void	sceSifSetRpcQueue(struct sifcmd_RPC_DATA_QUEUE* dq, int thid);	//19(26)
void	sceSifRpcLoop(struct sifcmd_RPC_DATA_QUEUE* dq);		//22(26)
void	sceSifGetOtherData(struct sifcmd_RPC_RECEIVE_DATA *receive,
		void *src, void *dest, int size, int mode);		//23(26)

#endif//__SIFCMD_H__