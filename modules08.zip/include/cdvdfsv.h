#ifndef __CDVDFSV_H__
#define __CDVDFSV_H__

#define CDVDFSV_VER	0x101

#define SCECdComplete	2
#define SCECdNotReady	6

/////////////////////////////////////////////////// 80000597
//old-style struct
struct cdvdfsv_SEARCHFILE{	//(sizeof=0x124)
	void	*src;		//+000
	int	field_4,	//+004
		field_8,	//+008
		field_C,	//+00C
		field_10,	//+010
		field_14,	//+014
		field_18,	//+018
		field_1C;	//+01C
	char	name[256];	//+020
	void	*dest;		//+120
};

//new-style struct
struct cdvdfsv_SEARCHFILE2{	//(sizeof=0x128)
	void	*src;		//+000
	int		field_4,	//+004
			field_8,	//+008
			field_C,	//+00C
			field_10,	//+010
			field_14,	//+014
			field_18,	//+018
			field_1C,	//+01C
			field_20;	//+020
	char	name[256];	//+024
	void	*dest;		//+124
};

#endif//__CDVDFSV_H__