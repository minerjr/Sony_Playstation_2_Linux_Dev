#ifndef __INTRMAN_H__
#define __INTRMAN_H__

#define INTRMAN_VER	0x102

#define INT_VBLANK	0x00

#define INT_CDROM	0x02

#define INT_RTC0        0x04
#define INT_RTC1        0x05
#define INT_RTC2        0x06

#define INT_EVBLANK	0x0B

#define INT_RTC3        0x0E
#define INT_RTC4        0x0F
#define INT_RTC5        0x10

#define INT_DMA9	0x2A	//sif0
#define INT_DMA10	0x2B	//sif1

void	RegisterIntrHandler(int interrupt, int, int (*intrh)(void*), void*);
						//4 (13,18)
void	ReleaseIntrHandler(int interrupt);	//5 (18)
void	EnableIntr(int interrupt);		//6 (13,18)
void	DisableIntr(int interrupt);		//7 (18)
void	CpuEnableIntr();			//9 (18,21,26)
void	CpuSuspendIntr(int*);			//17(05,06,07,13,14,18,26)
void	CpuResumeIntr(int);			//18(05,06,07,13,14,18,26)
int	QueryIntrContext();			//23(07,13)

#endif//__INTRMAN_H__