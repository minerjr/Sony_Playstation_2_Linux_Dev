#ifndef __SYSCLIB_H__
#define __SYSCLIB_H__

#define SYSCLIB_VER	0x101

int   look_ctype_table(unsigned int c);					// 8(14,17)
void* memset(void*, int, int);						//14(13)
void  bzero(void *s, size_t n);						//17(14)
int   strcmp (char *, char *);						//22(14)
char* index  (char *, char);						//25(14)
int   strlen (char *);							//27(14)
char* strncpy(char *, char *, int);					//30(14)
long  strtol(char *, char**, int);					//36(14)
int   prnt(void (*func)(void*, int c), int *v, const char *format,...);	//18(17)

#endif//__SYSCLIB_H__