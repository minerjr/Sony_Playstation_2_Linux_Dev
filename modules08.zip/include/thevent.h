#ifndef __THEVENT_H__
#define __THEVENT_H__

#define THEVENT_VER	0x101

struct thevent_eventFlag {
    unsigned int	attr;
    unsigned int	option;
    unsigned int	init;
};

int	CreateEventFlag(struct thevent_eventFlag*);		//4 (13)
int	iSetEventFlag(int, int);				//7 (13,21)
void	iClearEventFlag(int, int);				//9 (13)
void	WaitEventFlag(int statusFlag, int, int, int*);		//10(13,21)

//not sure about the 2nd param of iSetEventFlag and the 2nd of WaitEventFlag!

#endif//__THEVENT_H__