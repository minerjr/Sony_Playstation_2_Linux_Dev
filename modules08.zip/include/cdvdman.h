#ifndef __CDVDMAN_H__
#define __CDVDMAN_H__

#define CDVDMAN_VER	0x101

#define SCMD_OPENCONFIG		0x40	//in:3	out:1
#define SCMD_READCONFIG		0x41	//in:0	out:16
#define SCMD_WRITECONFIG	0x42	//in:16	out:1
#define SCMD_CLOSECONFIG	0x42	//in:0	out:1

#define SCECdINIT        0x00
#define SCECdINoD        0x01
#define SCECdEXIT        0x05

enum callback_opcode{
	SCECdFuncNop	= 0,
	SCECdFuncRead	= 1,
	SCECdFuncReadFull=2,
	SCECdFuncGetToc	= 3,
	SCECdFuncSeek	= 4,
	SCECdFuncStandby= 5,
	SCECdFuncStop	= 6,
	SCECdFuncPause	= 7,
	SCECdFuncBreak	= 8,
	SCECdFuncDvdRead= 9,
	SCECdFuncDefault= 10
};

#define NCMD_NOP	0x00
#define NCMD_NOP_	0x01
#define NCMD_STANDBY	0x02
#define NCMD_STOP	0x03
#define NCMD_PAUSE	0x04
#define NCMD_SEEK	0x05
#define NCMD_READ	0x06
#define NCMD_READFULL	0x07
#define NCMD_DVDREAD	0x08
#define NCMD_GETTOC	0x09
#define NCMD_call35	0x0C

#define READY_MASK		0xC0
#define READY			0x40

#define CDVDreg_NCOMMAND	(*(volatile unsigned char*)0xBF402004)	//r/w

#define CDVDreg_NDATAIN		(*(volatile unsigned char*)0xBF402005)	// /w
#define CDVDreg_READY		(*(volatile unsigned char*)0xBF402005)	//r/

#define CDVDreg_HOWTO		(*(volatile unsigned char*)0xBF402006)	// /w
#define CDVDreg_ERROR		(*(volatile unsigned char*)0xBF402006)	//r/ 

#define CDVDreg_7		(*(volatile unsigned char*)0xBF402007)	//-/w
#define CDVDreg_PWOFF		(*(volatile unsigned char*)0xBF402008)	//r/w 
#define CDVDreg_STATUS		(*(volatile unsigned char*)0xBF40200A)	//r/-
#define CDVDreg_TYPE		(*(volatile unsigned char*)0xBF40200F)	//r/-
#define CDVDreg_13		(*(volatile unsigned char*)0xBF402013)	//r/-
#define CDVDreg_SCOMMAND	(*(volatile unsigned char*)0xBF402016)	//r/w
#define CDVDreg_SDATAIN		(*(volatile unsigned char*)0xBF402017)	//r/w
#define CDVDreg_SDATAOUT	(*(volatile unsigned char*)0xBF402018)	//r/-

#endif//__CDVDMAN_H__

/*
if ((CDVDreg_PWOFF & 1==0) && (CDVDreg_PWOFF & 4)) powerOffCallBack();

0x00-0xFF	sceCdApplaySCmd
0x02	0,11	sceCdReadSubQ
0x03	1,9;9,1;
	1,4	sceCdReadConsoleID, sceCdWriteConsoleID,
		_sceCdGetMecaconVersion, _sceCdMV
0x05	0,1	sub_309C[_sceCdSearchFile & sceCdTrayReq]
0x06	1,1	sceCdTrayReq
0x08	0,8	sceCdReadClock, _sceCdRC
0x09	7,1	_sceCdWriteRTC
0x0A	2,3	_sceCdReadNVM
0x0B	4,1	_sceCdWriteNVM
0x0C	1,1	_sceCdSetHDMode
0x0F	0,1	sceCdPowerOff
0x10	0,2	__sub_40B0
0x11	1,1	__sub_40E4
0x12	0,9	_sceCdRI
0x13	8,1	_sceCdWriteILinkID
0x14	1,1	cdvdman_call45_AudioDigitalOut
0x15	0,1	cdvdman_call52_ForbidDVDP
0x16	1,1	cdvdman_call55_AutoAdjustCtrl
0x17	1,9	_sceCdRM
0x40	3,1	_sceCdOpenConfig
0x41	0,16	sub_474C[_sceCdReadConfig]
0x42	16,1	sub_4944[_sceCdWriteConfig]
0x43	0,1	_sceCdCloseConfig
0x80		mechacom_auth(secrman)
....		mechacom_auth(secrman)
0x88		mechacom_auth(secrman)
0x8D		sub_1528(secrman)
0x8E		sub_15A0(secrman)
0x8F		mechacom_auth(secrman)
0x90		_write_HD_start(secrman)
0x91		sub_1684(secrman)
0x92		sub_16E8(secrman)
0x93		sub_1738(secrman)

0x00-0xFF	sceCdApplyNCmd	cdvd_op
0x00	0,0	sceCdNop	0	SCECdFuncNop
0x01	0,0	_sceCdNop	0	SCECdFuncNop
0x02	0,0	sceCdStandby	5	SCECdFuncStandby
0x03	0,0	sceCdStop	6	SCECdFuncStop
0x04	0,0	sceCdPause	7	SCECdFuncPause
0x05	char*,4	sceCdSeek	4	SCECdFuncSeek
0x06	char*,B	sceCdRead	1	SCECdFuncRead
0x07	char*,B	cdvdman_call40	2	SCECdFuncReadSubQ	//read + subq
0x08	char*,B	sceDvdRead	9	SCECdFuncDvdRead
0x09	char*,1	__sceCdGetToc	3	SCECdFuncGetToc
0x09	char*,1	cdvdman_call19	0	-
0x0C	char*,7	sceCdReadKey	0	-
		sceCdBreak	8	SCECdFuncBreak
				A	SCECdFuncDefault?

HOWTO modes
size	hexa	binary          gettoc	cdread	call40	dvdread
2048	80	1000 0000	cd	0	-	-
2064	84	1000 0100	dvd	-	-	0(8C)
2328	86	1000 0110	-	1	-	-
2340	8F	1000 1111	-	2	-	-
2352	8C	1000 1100	-	-	0,2	^
2368	88	1000 1000	-	-	1	-
*/
