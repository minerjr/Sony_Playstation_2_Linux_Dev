#ifndef __LOADCORE_H__
#define __LOADCORE_H__

#define LOADCORE_VER	0x101

typedef	int (*func)();

#define	VER(major, minor)	(((major) & 0xFF)<<8 + ((minor) & 0xFF))

struct func_stub{
	int	jr_ra;	//jump instruction
	int	addiu0;	//addiu	zero, number
};

#define IMPORT_MAGIC	0x41E00000
#define EXPORT_MAGIC	0x41C00000

#define FLAG_EXPORT_QUEUED	1
#define FLAG_IMPORT_QUEUED	2

struct import{
	int		magic;		//0x41E00000
	struct import	*next;
	short		version;	//mjmi (mj=major, mi=minor version numbers)
	short		flags;		//=0
	char		name[8];
	struct func_stub func[0];	//the last one is 0, 0 (i.e. nop, nop)
};

struct export{
	int	magic_link;	//0x41C00000
	int	next;
	short	version;	//mjmi (mj=major, mi=minor version numbers)
	short	flags;		//=0
	char	name[8];
	func	func[0];	//usually module entry point (allways?)
//		func1
//		func2
//		func3
//		funcs	  	// more functions: the services provided my module
};

void	FlushIcache();				//4 (14)
void	FlushDcache();				//5 (14,21,26)
int	RegisterLibraryEntries(struct export*);	//6 (05,06,07,13,14,17,18,28)
int*	QueryBootMode(int code);		//12(11,21,25,26,28)
int	loadcore_call20_registerFunc(int (*function)(int *, int), int a1, int *result);
						//20(28)

#endif//__LOADCORE_H__