/*
  _____     ___ ____ 
   ____|   |    ____|      PSX2 OpenSource Project
  |     ___|   |____       (C)2002, David Ryan (Oobles@hotmail.com)
  ------------------------------------------------------------------------
			   Imports of 'export.irx' functions for use here  
*/

	.text
	.set	noreorder


	.local	exp_stub
exp_stub:
	.word	0x41e00000
	.word	0
	.word	0x00000101
	.ascii	"export\0\0"
	.align	2

	.globl	blah				# 004
blah:
	j	$31
	li	$0, 4

	.word	0
	.word	0


