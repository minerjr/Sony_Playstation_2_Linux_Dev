/*
  _____     ___ ____
   ____|   |    ____|      PSX2 OpenSource Project
  |     ___|   |____       (C)2002, David Ryan ( oobles@hotmail.com )
  ------------------------------------------------------------------------
  driver.c                 Remote Procedure Call server example driver.
*/

#include <tamtypes.h>
#include <fileio.h>
#include <stdlib.h>
#include <stdio.h>
#include <kernel.h>


// This is where the real work would happen
// if the driver was going to do something
// useful.

void * rpcHandlerFunction( unsigned int command  , void * rpcBuffer, int size )
{
  printf( "RPC: rpcHandlerFunction has been called!\n" );
  printf( "RPC: received '%s'\n" , (char * )rpcBuffer );
  return rpcBuffer;
}



// These are the various structures required
// to register a RPC handler.  Thankfully we
// don't need to do much with them. 

static struct t_rpc_data_queue queue __attribute__((aligned(64)));
static struct t_rpc_server_data server __attribute((aligned(64)));
static char rpcBuffer[ 128 ] __attribute((aligned(16)));



void threadRpcFunction()
{
   int rpcinit, threadId;
   int ret;
  
   printf("RPC: Thread Started\n");

   // Check and make sure the low level
   // Sif system is loaded.  We had to use
   // the Sif to load this module so its
   // very unlikely.  
   
   if ( sceSifCheckInit() == 0 )
   {
       printf( "RPC: Sif Not initialised\n" );
       sceSifInit();
   }
   else
   {
       printf( "RPC: Sif Initialised\n" );
   }

   rpcinit = sceSifInitRpc( 0 );
   printf( "RPC: sceSifInitRpc = %i\n", rpcinit );

   // Get the threadid of this thread.  Not much
   // else to say about that!

   threadId = GetThreadId();
   printf( "RPC: got ThreadId = %i\n", threadId );

   // Looks like the Rpc system uses the threadId
   // to wakeup this thread when a message arrives
   // for it.

   ret = sceSifSetRpcQueue( &queue , threadId );
   printf( "RPC: Did setup Queue. ret = %i\n", ret);

   // Register a handler.  The second parameter is
   // the Identifier the EE client must use to connect
   // to thise handler. I'm sure Sony keeps a list of
   // reserved numbers for this and has suggested ones
   // for everyone else.  I don't know them.. so we just
   // use one similar to others I've seen. 

   ret = sceSifRegisterRpc( &server  , 0x80000120  , rpcHandlerFunction, &rpcBuffer,0,0, &queue );
   printf( "RPC: Did Register RPC. ret = %i\n", ret);



   // Everything has been setup now.  The sceSifRpcLoop
   // shouldn't ever return.  You only get control through
   // the rpcHandlerFunction now.

   sceSifRpcLoop( &queue );
   printf( "RPC: shouldn't get here..  looping..\n");

}


int start( int argc, char **argv)
{
   int	threadId;
   struct t_thread t;

   t.type = 0x02000000;    // No idea what this flag is.  Same everywhere else.
   t.unknown = 0;	   // This is always 0.  No idea.
   t.function = threadRpcFunction;
   t.stackSize = 0x800;    // Keep stack size small.  This value seems standard.
   t.priority = 0x1e;
 
   threadId = CreateThread( &t );
   if ( threadId < 0 ) 
   {
       printf( "CreateThread failed.  %i\n", threadId );
   }
   else
   {

       // After the thread is created you need to start it!

       StartThread( threadId );
   }
  
   return 0;
} 
