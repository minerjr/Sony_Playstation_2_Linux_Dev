/*
  _____     ___ ____
   ____|   |    ____|      PSX2 OpenSource Project
  |     ___|   |____       (C)2002, David Ryan ( oobles@hotmail.com )
  ------------------------------------------------------------------------
  loader.c                 Module Loading program.
*/

#include <stdio.h>
#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>

#include "hw.h"
#include "loadmodule.h"


void loadModules(void)
{
    int ret;

    if((ret =_lf_bind(0)) != 0)
        return; // bind failed.

    
    ret = _sifLoadModule("host:filedriver.irx", 0, NULL, 0);
    if (ret < 0) {
	return;  // Failed to load driver.
    }

    ret = _sifLoadModule("host:export.irx", 0, NULL, 0);
    if (ret < 0) {
	return;  // Failed to load driver.
    }


    ret = _sifLoadModule("host:rpc.irx", 0, NULL, 0);
    if (ret < 0) {
	return; // Failed to load driver.
    }
}

// filedriver buffer 
static char readBuffer[ 128 ] __attribute((aligned(16)));

// rpc variables and buffers.
static struct t_rpc_client_data rpcsif  __attribute__((aligned(64)));
static char rpcBuffer[128] __attribute__((aligned(16)));

int main()
{
    int whichdrawbuf = 0;
    int fd,read;
    int bindsuccess = 0;

    // Initialise RPC system.

    sif_rpc_init(0);


    // Setup the Video.

    DmaReset();
    initGraph(3);
    SetVideoMode();
    install_VRstart_handler();

    // Setup the double buffers.

    SetDrawFrameBuffer(1);
    SetDrawFrameBuffer(0);
    SetCrtFrameBuffer(1);

    // Load the modules!

    loadModules();

    // Do a test of the 'fd' file driver.

    fd = fio_open( "fd:test" , 0 );
    read = fio_read( fd, readBuffer, sizeof( readBuffer ) );
    fio_write( fd, "Hi There!\n", 10 );

    // Connect to our RPC server.
    // Because the RPC server is running on a separate thread on
    // the server it may not be ready and registered by the time
    // we want to call it.. so we loop until we get an error or
    // get the server address.

    rpcsif.server = NULL;

    if ( sif_bind_rpc( &rpcsif, 0x80000120, 1 ) < 0 ) 
    {
       fio_write( fd, "LOADER: Failed to bind\n", 23 );
       bindsuccess = 0;
    }
    else
    {
       fio_write( fd, "LOADER: Got RPC connection!\n", 28 );
       bindsuccess = 1;
    }

    // If we connect to the server let try sending it a message.

    if ( bindsuccess )
    {
       int ret;

       ret = sif_call_rpc( &rpcsif, 1,0, readBuffer, 128, readBuffer, 128, 0,0 );
       if ( ret < 0 )
       {
           // Something went wrong..  should do something about it.
           fio_write( fd, "LOADER: Rpc call failed!\n", 25 );
       }
       else
       {
           // Success.. should look in read buffer for answer.
           // try writing it back to our 'fd' file driver.

           fio_write( fd, readBuffer, strlen( readBuffer ) );
       }
     
    }

    // Close up the file handle for our 'fd' driver.

    fio_close( fd ); 


    // Normally you'd do something during double 
    // buffering.  Its not needed here.. but I
    // thought I'd leave it here incase I got
    // inspired to add something later.

    while ( 1 )
	{
        WaitForNextVRstart(1);

        ClearVRcount();
        SetCrtFrameBuffer(whichdrawbuf);
        whichdrawbuf ^= 1;
        SetDrawFrameBuffer(whichdrawbuf);

    } 

    // We shouldn't get here.. but just in case.

    k_SleepThread();

}
