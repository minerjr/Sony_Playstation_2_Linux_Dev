/*
  _____     ___ ____
   ____|   |    ____|      PSX2 OpenSource Project
  |     ___|   |____       (C)2002, David Ryan ( oobles@hotmail.com )
  ------------------------------------------------------------------------
  filedriver.c             Example File Driver.
*/

#include <tamtypes.h>
#include <fileio.h>
#include <stdlib.h>
#include <stdio.h>

static struct fileio_driver file_driver;


int dummy()
{
   printf("FILEDRIVER: dummy function called\n");
   return -5;
}

void fd_initialize( struct fileio_driver *driver)
{
   printf("FILEDRIVER: initializing '%s' file driver.\n", driver->device);
}

int fd_open( int fd, char *name, int mode)
{
   printf("FILEDRIVER: fd_open called.\n" );
   printf("FILEDRIVER: fd......... %x\n", fd);
   printf("FILEDRIVER: name....... %s %x\n", name, name);
   printf("FILEDRIVER: mode....... %d\n", mode);
   return 0;
}

char helloIOP[] = "Hello IOP!";

int fd_read( int fd, char * buffer, int size )
{
   strcpy( buffer, helloIOP );
   return sizeof( helloIOP );
}

int fd_write( int fd, char * buffer, int size )
{
   printf( buffer );
   return size;
}

int fd_close( int fd)
{
   printf("FILEDRIVER: fd_close called.\n" );
   printf("FILEDRIVER: fd..... %d\n", fd);
   return 0;
}

static void *filedriver_functarray[16];

void
start( int argc, char **argv)
{
   int	i, fd;
   
   printf("FILEDRIVER: Module Loaded\n");
   printf("FILEDRIVER: Setting up 'fd' driver\n");
   file_driver.device = "fd";
   file_driver.xx1 = 16;
   file_driver.version = 1;
   file_driver.description = "File Driver Example";
   file_driver.function_list = filedriver_functarray;
   for (i=0;i < 16; i++)
      filedriver_functarray[i] = dummy;
   filedriver_functarray[ FIO_INITIALIZE ] = fd_initialize;
   filedriver_functarray[ FIO_OPEN ] = fd_open;
   filedriver_functarray[ FIO_CLOSE ] = fd_close;
   filedriver_functarray[ FIO_READ ] = fd_read;
   filedriver_functarray[ FIO_WRITE ] = fd_write;
 
   printf("FILEDRIVER: Removing any drivers of same name\n"); 
   FILEIO_del( "fd");

   printf("FILEDRIVER: Adding 'fd' driver into io system\n");
   FILEIO_add( &file_driver);
}

