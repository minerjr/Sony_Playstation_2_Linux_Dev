/*
  _____     ___ ____
   ____|   |    ____|      PSX2 OpenSource Project
  |     ___|   |____       (C)2002, David Ryan ( oobles@hotmail.com )
  ------------------------------------------------------------------------
  export.c		   EXAMPLE LIBRARY OF FUNCTIONS MODULE
*/

#include <tamtypes.h>
#include <stdio.h>
#include <kernel.h>


/* The function that makes up this library */
/* Yes.. It doesn't do much!               */

int blah()
{
   printf( "EXPORT: blah function called\n" );
   return 22;
}

/* This is defined in exp.s */

extern int * iop_module;


/* When we load the module we need to call */
/* a loadcore library function to export   */
/* our function list.                      */

int start( int argc, char **argv)
{
   int ret;

   printf( "EXPORT: Module Loaded.\n" );

   ret = ExportFunctions( &iop_module );   
   printf( "EXPORT: ExportFunctions returned = %i\n" , ret );
   return ret; 
}

 
