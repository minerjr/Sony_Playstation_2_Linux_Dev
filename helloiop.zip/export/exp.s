/*
  _____     ___ ____ 
   ____|   |    ____|      PSX2 OpenSource Project
  |     ___|   |____       (C)2002, David Ryan ( oobles@hotmail.com ) 
  ------------------------------------------------------------------------
  exp.s			   Example Export Function List.
*/



	.text
	.set	noreorder
	.global func_dec
   	.global iop_module
        .extern blah
        .extern start

iop_module:
	.word	0x41c00000
	.word	0
	.word	0x00000101
	.ascii	"export\0\0"

	.align	2

func_dec:
	.word   start
        .word   do_nothing
	.word   do_nothing
	.word   do_nothing
        .word   blah

	.word   0

do_nothing:
	.word   0x03e00008
	.word   0


