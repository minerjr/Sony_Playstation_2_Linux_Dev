Angle			.equ  	0
StartVert		.equ	4
NumVerts		.equ	4

.include "vcl_sml.inc"

.init_vf_all
.init_vi_all

.syntax new

.vu

--enter
--endenter

	iaddiu		iVert, vi00, 0				; Start vertex counter
	iaddiu		iVertPtr, vi00, StartVert	; Point to the first vert
	iaddiu		iNumVerts, vi00, NumVerts	; Load the loop end condition
	
	lq.x		fAngle, Angle(vi00)			; Load the angle
	add.z		fAngle, vf00, vf00			; AngleSinCos takes another angle in .z
	
	AngleSinCos	fAngle, fSinCos				; Calculate Sin and Cos of angle
	
	add.x		fCosNSin, vf00, fSinCos[y]	; fCosNSin makes it easier to
	sub.y		fCosNSin, vf00, fSinCos[x]	; Rotate the X coordinate
	loi			2048.0						; Put 2048 into the I register
	
loop:										; For each vertex
--LoopCS 4,0								; Minimum of 4 iterations
	lq.xy		fVert, 0(iVertPtr)			; Load the XY components of the vert
	mul.xy		fTransX, fVert, fCosNSin	; float tlX = _tlX * cosi - _tlY * sini
	mul.xy		fTransY, fVert, fSinCos		; float tlY = _tlX * sini + _tlY * cosi
	add.x		fVert, fTransX, fTransX[y]
	add.y		fVert, fTransY, fTransY[x] 
	add.xy		fVert, fVert, i				; Add 2048 to the XY components
	ftoi4.xy	fVert, fVert				; Convert to 12:4 fixed point
	sq.xy		fVert, 0(iVertPtr)			; Store the newly converted data
	iaddiu		iVert, iVert, 1				; Increment the vertex counter
	iaddiu		iVertPtr, iVertPtr, 3		; Increment the vertex pointer
	ibne		iVert, iNumVerts, loop		; Branch back to "loop" label if
											; iVert and iNumVerts are not equal
	iaddiu		iGIFTag, vi00, 1			; Kick the data at VUMEM location 1
	xgkick		iGIFTag						; to the GS
--exit
--endexit
