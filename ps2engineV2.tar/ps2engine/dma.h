#ifndef DMA_H
#define DMA_H

#include <stdio.h>
#include "dmamemory.h"
#include "structs.h"

/*
/Class Dma_Packet
/This class is used all dma packets. Used for schedaling of packets and also
/for storing of the packets.
*/

class Dma_Packet
{
private:
	int IDNumber;//Packet ID number given when a new packet is created
	int IsInUse;

	sps2DMATag_t *pDMATag;//Link to the dma tag
	Dn_CHCR_t	chcr;   // Channel control register used to control the DMA transfer
	Dn_MADR_t	madr;//Address of the first packet's psycial address
	int iQWC;	//Number of qwords

	Dma_4KPage *packetMemory;
	Dma_4KPage *currentPage;

	Dma_Memory_Engine *DmaMemoryEngine;

	uint128 *pCurrent;//Used for stepping through the 
	
	int stitch();

public:
	Dma_Packet();
	Dma_Packet(Dma_Memory_Engine *tmpDmaMemoryEngine);
	Dma_Packet(Dma_Memory_Engine *tmpDmaMemoryEngine, int numberOfPages);
	~Dma_Packet();
	
	int Init();
	int Init(int numberOfPages);
	int finish();

	int transfer();

	//int addQword(u_long64 tmpQword);
	int add2Qword(uint128 tmp2Qword);

	//int addQword(u_long64 *tmpQword, int count);
	int add2Qword(uint128 *tmp2Qword, int count);

	uint128 *getCurrent();
	void dump();
};

#endif
