#include <stdio.h>
#include "dma.h"
#include "addregisters.h"

int main()
{

	int posx, posy;

	Dma_Memory_Engine *DmaMemoryEngine;
	Dma_Packet *testPacket;

	sps2GIFTag_t GifTag;

	sps2GIFPackedRegister_t Register;



	printf("\nPS2 engine - test program\n");
	
	printf("Create Memory Engine: ");
	DmaMemoryEngine = new Dma_Memory_Engine(3072);
	printf("done\n");

	printf("Create Dma Packet: ");
	testPacket = new Dma_Packet(DmaMemoryEngine);


	printf("done\n");

	printf("Inilising the screen: ");


	printf("done\n");

	GifTag = AddGifTag(3, 1, 1, 11, GIF_FLG_PACKED, 0);
	
	SPS2_SET_GIF_REG(GifTag, GifTag.s.NREG++, GIF_REG_RGBAQ);
	// Add the XYZ2 register to the giftag. 
	SPS2_SET_GIF_REG(GifTag, GifTag.s.NREG++, GIF_REG_XYZ2);

	testPacket->add2Qword((uint128)GifTag.i128);

	Register = AddColour(0,0,255,0x80);
	
	testPacket->add2Qword((uint128)Register.i128);


	posx = -100;
	posy = 64;
	printf("Enter the first Vertex: X ");
	scanf("%d",&posx);
	printf("Enter the first Vertex: Y ");
	scanf("%d",&posy);
	
	//printf("Posx: %d, Posy %d\n", posx, posy);
	
	Register = AddVertex( posx, posy, 1024,0);
	
	testPacket->add2Qword((uint128)Register.i128);

	Register = AddColour(255,0,0,0xff);
	
	testPacket->add2Qword((uint128)Register.i128);


	posx = 100;
	posy = 64;

	printf("Enter the second Vertex: X: ");
	scanf("%d",&posx);
	printf("Enter the second Vertex: Y: ");
	scanf("%d",&posy);

	Register = AddVertex( posx, posy, 1024,0);
	
	testPacket->add2Qword((uint128)Register.i128);


	Register = AddColour(0,255,0,0x80);
	
	testPacket->add2Qword((uint128)Register.i128);


	posx = 0;
	posy = 0;

	printf("Enter the third Vertex: X: ");
	scanf("%d",&posx);
	printf("Enter the third Vertex: Y: ");
	scanf("%d",&posy);

	Register = AddVertex( posx, posy, 1024,0);
	
	testPacket->add2Qword((uint128)Register.i128);

	testPacket->finish();
	printf("Drawing Started\n");


	sps2UScreenInit(0);
	
	do
	{
		sps2UScreenClear(0x10, 0, 0x20);

		testPacket->transfer();

		sps2UScreenSwap();

	}while(1);
	
	testPacket->dump();	
	printf("Drawing Finished");

	sps2UScreenShutdown();

	printf("Deleting Dma Packet: ");
	delete testPacket;
	printf("done\n");


	printf("Deleting Memory Engine: ");
	delete DmaMemoryEngine;
	printf("done\n");

	return 0;

}
