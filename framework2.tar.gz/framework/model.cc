/****************************************************************************\
|* PS2 framework definitions
|* =========================
|*
|* Simple PS2 C++ framework on which to build a 3D/2.5D engine. 
|*
|* Author					: SjG, various others
|* First created			: Thu Jul 18 13:25:57 GMT 2002
|* Modification history		: See below
|*
\****************************************************************************/
#include "model.h"


/****************************************************************************\
|* Constructor
\****************************************************************************/
Model::Model()
	{
	initialise();
	}

/****************************************************************************\
|* Constructor
\****************************************************************************/
Model::Model(char *filename)
	{
	initialise();
	loadFile(filename);
	}
	
/****************************************************************************\
|* Destructor
\****************************************************************************/
Model::~Model()
	{
	erase();
	}


/****************************************************************************\
|* Method - initialise the model
\****************************************************************************/
void Model::initialise(void)
	{
	mesh				= NULL;
	nmeshes				= 0;
	nfaces				= 0;
	vpkt.buffer			= NULL;
	vpkt.buffer_size	= 0;
	type				= MODEL_BAD_FORMAT;

	objTrans			= (ps2_vu0_fvector){0,0,0,0};
	objRot				= (ps2_vu0_fvector){0,0,0,0};
	objRot0				= (ps2_vu0_fvector){0,0,0,0};
	
	localScreen			= NULL;
	localLight			= NULL;
	lightColour			= NULL;
	localClip			= NULL;
	outlineFactor		= NULL;
	}

/****************************************************************************\
|* Method - delete the model data
\****************************************************************************/
void Model::erase(void)
	{
	int i;
	if (vpkt.buffer != NULL)
		free(vpkt.buffer);
		
	for (i=nmeshes-1; i>=0; i--)
		{
		free(mesh[i].st);
		free(mesh[i].normal);
		free(mesh[i].vertex);
		}
		
	free(mesh);
	initialise();
	}
	
/****************************************************************************\
|* Method - load a file
\****************************************************************************/
void Model::loadFile(char *name)
	{
	if (strstr(name, ".ms") != NULL)
		loadStripped(name);
	else
		type = MODEL_BAD_FORMAT;
	}
	

	
/****************************************************************************\
|* Method - load a stripped-triangle file
\****************************************************************************/
void Model::loadStripped(char *name)
	{
	char tmpPath[1024];
	unsigned int *indexes = NULL;

	erase();

	FILE *sf = fopen(name, "r");
	if (sf==NULL)
		{
		_log << "Could not load file '" << name << "'\n";
		type=MODEL_BAD_FORMAT;
		return;
		}

	fseek(sf, 0, SEEK_END);
	int filesize=ftell(sf);
	fseek(sf, 0, SEEK_SET);
	_log << name << " size: " << filesize << " bytes\n";

	if (filesize<13)
		{
		_log <<"Unexpected end of stripped file\n";
		fclose(sf);
		type=MODEL_BAD_FORMAT;
		}
	else
		{
		unsigned int i;
		struct
			{
			char magic[8];
			unsigned char version;
			unsigned int nmeshes;
			unsigned int ntextures;
			} header;

		fread(&header, 1, 9, sf);

		if (strncmp(header.magic, STRIPPED_MAGIC, strlen(STRIPPED_MAGIC))!=0)
			{
			_log << "Invalid file format\n";
			fclose(sf);
			type=MODEL_BAD_FORMAT;
			return;
			}

		if (header.version!=STRIPPED_VERSION)
			{
			_log << "Incorrect file version\n";
			fclose(sf);
			type=MODEL_BAD_FORMAT;
			return;
			}

		fread(&header.nmeshes, 4, 1, sf);
		fread(&header.ntextures, 4, 1, sf);
		indexes=(unsigned int *)malloc(header.ntextures*sizeof(unsigned int));

		for (i=0; i<header.ntextures; i++)
			{
			unsigned char len;
			fread(&len, 1, 1, sf);
			*(tmpPath+len)=0;
			fread(tmpPath, 1, len, sf);
			// indexes[i]=AddTexture(tmp_path);
			}

		nfaces=0;
		nmeshes=header.nmeshes;

		mesh=(mesh_t*) memalign(64, nmeshes * sizeof(mesh_t));
		memset(mesh, 0, nmeshes * sizeof(mesh_t));

		/********************************************************************\
		|* Read in each mesh
		\********************************************************************/
		for (i=0; i<nmeshes; i++)
			{
			fread(&mesh[i].texture, sizeof(unsigned int), 1, sf);

			if (mesh[i].texture>=0)
				mesh[i].texture=indexes[mesh[i].texture];
			
			fread(&mesh[i].rgb, sizeof(float), 4, sf);
			fread(&mesh[i].nfaces, sizeof(unsigned int), 1, sf);
			
			/****************************************************************\
			|* Decompress the vertex strip
			\****************************************************************/
			lzo_uint out_len1 = mesh[i].nfaces * VERT_DATA_LEN_STRIP;
			lzo_uint overhead = out_len1/64+16+3;
			mesh[i].vertex    = (char *) memalign(64, out_len1);
			lzo_byte *out     = (lzo_byte *) mesh[i].vertex;
			
			lzo_uint in_len;
			fread(&in_len, sizeof(lzo_uint), 1, sf);
			lzo_byte *in      = (lzo_byte *) memalign(64, in_len);
			lzo_byte *wrkmem  = (lzo_byte *) memalign(64, overhead);
			
			lzo_uint out_len2;
			fread(in, 1, in_len, sf);
			lzo1x_decompress(in, in_len, out, &out_len2, NULL);
			
			free(wrkmem);
			free(in);
			
			if(out_len1!=out_len2)
				{
				_log << "Error decompressing stripped file (vertices)\n";
				erase();
				fclose(sf);
				return;
				}
			
			/****************************************************************\
			|* Decompress the normals
			\****************************************************************/
			out_len1       = mesh[i].nfaces * NORM_DATA_LEN_STRIP;
			overhead       = out_len1/64+16+3;
			mesh[i].normal = (char *) memalign(64, out_len1);
			out            = (lzo_byte *) mesh[i].normal;

			fread(&in_len, sizeof(lzo_uint), 1, sf);
			in             = (lzo_byte *) memalign(64, in_len);
			wrkmem         = (lzo_byte *) memalign(64, overhead);
			
			fread(in, 1, in_len, sf);
			lzo1x_decompress(in, in_len, out, &out_len2, NULL);
			free(wrkmem);
			free(in);
			
			if(out_len1!=out_len2)
			    {
				_log << "Error decompressing stripped file (normals)\n";
				erase();
				fclose(sf);
				return;
			    }
			
			/****************************************************************\
			|* Decompress the texture co-ords if they're present
			\****************************************************************/
			if (mesh[i].texture >= 0)
				{
				out_len1    = mesh[i].nfaces * ST_DATA_LEN_STRIP;
				overhead    = out_len1/64+16+3;
				mesh[i].st  = (char *) memalign(64, out_len1);
				out         = (lzo_byte *) mesh[i].st;

				fread(&in_len, sizeof(lzo_uint), 1, sf);
				in          = (lzo_byte *) memalign(64, in_len);
				wrkmem      = (lzo_byte *) memalign(64, overhead);
				
				fread(in, 1, in_len, sf);
				lzo1x_decompress(in, in_len, out, &out_len2, NULL);
				free(wrkmem);
				free(in);
				
				if(out_len1!=out_len2)
					{
					_log << "Error decompressing stripped file (textures)\n";
					erase();
					fclose(sf);
					return;
					}
				}

			// we actually read the number of verts, correct that
			mesh[i].nfaces -= 2;
			nfaces         += mesh[i].nfaces;
			}
			
		fread(&header.magic, 1, 8, sf);
		if (strncmp(header.magic, "STRIPPED", 8) != 0)
			{
			_log << "Unexpected string at the end of stripped file.\n";
			erase();
			fclose(sf);
			type=MODEL_BAD_FORMAT;
			return;
			}

		fclose(sf);
		free(indexes);
		}
	
	_log << "Loading done, " << nmeshes << " meshes, " << nfaces << " polys\n";
	type=MODEL_STRIPPED;
	}
		
/****************************************************************************\
|* Method - build a VIF packet for the model. Needs to be called whenever
|* the structure of the model changes (not it's orientation)
\****************************************************************************/
void Model::buildPacket(void)
	{
	unsigned int mesh_verts;
	unsigned int m, v, cnt1;

	int tags=0;
	int packet_size=10;
	for (m=0; m<nmeshes; m++)
		{
		packet_size+=10;

		mesh_verts=mesh[m].nfaces+2;
		for (v=0; v<mesh_verts; v+=VU_VERTS_STRIP)
			packet_size+=VU_VERTS_STRIP+VU_VERTS_STRIP*2*3/4+4;
		}

	_log << " .. allocating " << packet_size << " qwords (" 
	     << packet_size*16 << " bytes)\n";

	if (vpkt.buffer != NULL)
		free(vpkt.buffer);
	vpkt.buffer = NULL;
	vpkt.buffer = (u_long128 *) memalign(64, 16 * packet_size);

	// init memory for data VIF PKT
	vpkt.vp.init(vpkt.buffer);
	vpkt.vp.end(0);
	tags++;

	if (type == MODEL_BAD_FORMAT)
		{
		_log << "bad model format\n";
		vpkt.vp.terminate();
		return;
		}
		
	_log << "good model format\n";

	vpkt.vp.addCode(0x3000000); // set vu1 base
	vpkt.vp.addCode(0x2000200); // set vu1 offset

	vpkt.vp.openDirectCode(0);
	vpkt.vp.addq(GIF_SET_TAG(1,1,0,0,GIF_PACKED,4));
	vpkt.vp.addq(0xEEEEL);
	vpkt.vp.addq(PS2_GS_SETREG_ALPHA( 0,2,2,2,0xA0));
	vpkt.vp.addq(PS2_GS_ALPHA_1);
	vpkt.vp.addq(PS2_GS_SETREG_PABE( 1 ));
	vpkt.vp.addq(PS2_GS_PABE);
	vpkt.vp.addq(PS2_GS_SETREG_FBA( 0 ));
	vpkt.vp.addq(PS2_GS_FBA_1);
	vpkt.vp.addq(PS2_GS_SETREG_CLAMP(0, 0, 0, 0, 0, 0));
	vpkt.vp.addq(PS2_GS_CLAMP_1);
	vpkt.vp.closeDirectCode();

	int prim_type=PS2_GS_SETREG_PRIM(PS2_GS_PRIM_PRIM_TRISTRIP, GOURAUD(1),
	                             TEXTURED(0), 0, 0, 0, 0, 0, 0 );

	vpkt.vp.openUpkCode((0 | 0x8000), V4_32, 4, 4 );

	localScreen = vpkt.vp.current;
	for (cnt1=0; cnt1<4; cnt1++)
		vpkt.vp.add2q(0);	// 128-bit add (2 qwords)

	localLight = vpkt.vp.current;
	for (cnt1=0; cnt1<4; cnt1++)
		vpkt.vp.add2q(0);	// 128-bit add (2 qwords)

	lightColour = vpkt.vp.current;
	for (cnt1=0; cnt1<4; cnt1++)
		vpkt.vp.add2q(0);	// 128-bit add (2 qwords)

	vpkt.vp.closeUpkCode();
	
	vpkt.vp.add(VIF1_SET_MSCALF(0,0));

	for (m=0; m<nmeshes; m++)
		{
		mesh_verts=mesh[m].nfaces+2;

		int pre=1;
		for (v=0; v<mesh_verts; v+=VU_VERTS_STRIP)
			{
			unsigned int vu_verts=VU_VERTS_STRIP;

			if (v + VU_VERTS_STRIP > mesh_verts)
				vu_verts = mesh_verts % VU_VERTS_STRIP; // -v;

			vpkt.vp.openUpkCode((0|0x8000), V4_32, 4, 4);
			vpkt.vp.addq(PS2_GIFTAG_SET_TOPHALF( NLOOP(vu_verts), EOP(1),
			                                    PRE(pre), prim_type,
												PS2_GIFTAG_FLG_PACKED, 2));
			vpkt.vp.addq(0x41L);
			vpkt.vp.closeUpkCode();

			vpkt.vp.openUpkCode((1|0x8000), V3_32, 4, 4);
			vpkt.vp.add2q((u_long128*)(mesh[m].vertex +v * VERT_DATA_LEN_STRIP),
			                           VU_VERTS_STRIP*3/4);
			vpkt.vp.closeUpkCode();

			vpkt.vp.openUpkCode((101|0x8000), V3_32, 4, 4);
			vpkt.vp.add2q((u_long128*)(mesh[m].normal +v * VERT_DATA_LEN_STRIP),
			 							VU_VERTS_STRIP*3/4);
			vpkt.vp.closeUpkCode();

			vpkt.vp.openUpkCode((201|0x8000), V4_32, 4, 4);
			for (cnt1=0; cnt1<VU_VERTS_STRIP; cnt1++)
				vpkt.vp.add2q(*((u_long128*)(&(mesh[m].rgb))));
			vpkt.vp.closeUpkCode();

			vpkt.vp.addCode(VIF1_SET_MSCNT(0));
			pre=0;
			}
		}
	vpkt.vp.terminate();
	
	_log << "finished packet: " << vpkt.vp.size() << " qwords, "
	     << tags << " tags\n";
	//vpkt.vp.dump();
	}
			
/****************************************************************************\
|* Method - draw the model onto the screen
\****************************************************************************/
void Model::draw(Framework *f)
	{
	f->dmaStartOnVu1(NULL, (ps2_dmatag*)vpkt.vp.base);
	}
	
