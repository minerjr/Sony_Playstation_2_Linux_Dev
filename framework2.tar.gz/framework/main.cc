/****************************************************************************\
|* Test program for the framework
|* ==============================
|*
|* Simple PS2 C++ framework on which to build a 3D/2.5D engine. 
|*
|* Author					: SjG, various others
|* First created			: Thu Jul 18 13:25:57 GMT 2002
|* Modification history		: See class header files
|*
\****************************************************************************/

#include "framework.h"
#include "image.h"
#include "sprite.h"
#include "model.h"

	static ps2_vu0_fvector camera_p = { 0.0f, 0.0f, -1000.0f, 0.0f };
	static ps2_vu0_fvector camera_zd = { 0.0f, 0.0f, 1.0f, 1.0f };
	static ps2_vu0_fvector camera_yd = { 0.0f, 1.0f, 0.0f, 1.0f };
	static ps2_vu0_fvector camera_rot = { 0, 0, 0, 0 };
	static ps2_vu0_fvector light0 = { 1.0f, 0.0f, 0.3f, 0.0f };
	static ps2_vu0_fvector light1 = { 0.0f, 1.0f, 0.3f, 0.0f };
	static ps2_vu0_fvector light2 = { 0.0f, 0.0f, 1.0f, 0.0f };
	static ps2_vu0_fvector color0 = { 0.4f, 0.4f, 0.4f, 1.0f };
	static ps2_vu0_fvector color1 = { 0.4f, 0.4f, 0.4f, 1.0f };
	static ps2_vu0_fvector color2 = { 0.4f, 0.4f, 0.4f, 1.0f };
	static ps2_vu0_fvector ambient = { 0.2f, 0.2f, 0.2f, 0.0f };
	static ps2_vu0_fmatrix local_world;
	static ps2_vu0_fmatrix world_view;
	static ps2_vu0_fmatrix view_screen;
	static ps2_vu0_fmatrix local_screen;
	static ps2_vu0_fmatrix normal_light;
	static ps2_vu0_fmatrix light_color;
	static ps2_vu0_fmatrix local_light;
	static ps2_vu0_fmatrix work;
	
int main(int argc, char **argv)
	{
	Framework *ps2 = new Framework(argc, argv);
	ps2->start();
	ps2_gs_gparam *params = ps2->getParams();
	
	/************************************************************************\
	|* Initialise the background image
	\************************************************************************/
	Image im("lib/img/ps2tux.pcx");
	im.setAddress(ps2);
	Sprite tux(ps2, &im, 0, 0, (params->width)<<4, (params->height)<<4);
	
	/************************************************************************\
	|* Load in a model
	\************************************************************************/
	Model model("lib/models/ape.ms");
	model.buildPacket();
	
	/************************************************************************\
	|* Run the main loop
	\************************************************************************/
	while (1)
		{
		tux.draw();
		
		// view -> screen matrix
		ps2_vu0_view_screen_matrix(view_screen, 512.0f, 1.0f,
			params->pixel_ratio, params->center_x, params->center_y, 
			1.0f, ((1 << 24) - 1), 1.0f, 65536.0f);

		// color&normal matrix setting
		ps2_vu0_normal_light_matrix(normal_light, light0, light1, light2);

		// world -> view matrix
		vu0_rot_camera_matrix(world_view, camera_p, camera_zd, camera_yd,
								camera_rot);

		// light color
		ps2_vu0_light_color_matrix(light_color,color0, color1, color2, ambient);
		
		
		// Rotate the model
		model.objRot[1] += M_PI/150.0f;
		
		// Rotation must be between -PI and PI, otherwise it does weird things
		if (model.objRot[1] > M_PI)
		 	model.objRot[1] -= 2.0f*M_PI;

		// local -> world (rotate)matrix
		ps2_vu0_unit_matrix(work);
		ps2_vu0_rot_matrix(work, work, model.objRot0);
		ps2_vu0_rot_matrix(local_world, work, model.objRot);

		// light(normal) -> local_light matrix
		ps2_vu0_mul_matrix(local_light, normal_light, local_world);

		// local -> world (rotate&translate)matrix
		ps2_vu0_trans_matrix(local_world, local_world, model.objTrans);

		// local -> screen matrix
		ps2_vu0_mul_matrix(work, world_view, local_world);
		ps2_vu0_mul_matrix(local_screen, view_screen, work);

		// if we got the pointers for the matrices in the dma list
		if (model.localScreen != NULL)
			{
			// copy the tranform matrices into the dma list
			memcpy(model.localScreen, local_screen, sizeof(ps2_vu0_fmatrix));
			memcpy(model.localLight,  local_light,  sizeof(ps2_vu0_fmatrix));
			memcpy(model.lightColour, light_color,  sizeof(ps2_vu0_fmatrix));
			}

		// send it off
		model.draw(ps2);
				
		im.upload(ps2);
		ps2->flip();
		}
	}
	
