#ifndef __PIXELFORMATS_H__
#define __PIXELFORMATS_H__

// Modes
#define INDEXCOLOR16		1
#define INDEXCOLOR256		2
#define COLORRGBA32			4


#endif