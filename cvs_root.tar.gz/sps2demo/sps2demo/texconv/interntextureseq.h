#ifndef __INTERNTEXTURESEQ_H__
#define __INTERNTEXTURESEQ_H__

#include "exttypes.h"
#include <stdio.h>

class CInternBinaryBitmap
{
	friend class CTextureCrunch;

public:
	const int32 GetWidth() const { return m_iWidth; }
	const int32 GetHeight() const { return m_iHeight; }
	const void * GetPixData() const { return m_pPixelData; }

	CInternBinaryBitmap() : m_iWidth(-1), m_iHeight(-1), m_pPixelData(NULL) {}
	void CleanUp();

private:
	int32 m_iWidth;
	int32 m_iHeight;
	uint8 * m_pPixelData;	// check pixelformat in CInternTexture
};

class CInternTexture
{
	friend class CTextureCrunch;

public:
	const char * GetUserDefProps() const { return m_pUserDefProps; }
	const int32 GetPixelFormat() const { return m_iPixelFormat; }
	const void * GetPalette() const { return m_pInternPalette; }
	const int32 GetNumLevels() const { return m_iNumLevels; }
	const CInternBinaryBitmap * GetLevel(const int32 iLevelNum) const { return &m_pMipMaps[iLevelNum]; }

	CInternTexture() : m_pUserDefProps(NULL), m_iPixelFormat(-1), m_pInternPalette(NULL), m_iNumLevels(-1), m_pMipMaps(NULL) {}
	void CleanUp();
	
private:
	char * m_pUserDefProps;

	int32 m_iPixelFormat;
	uint8 * m_pInternPalette;	// max 256*4 ubytes
	int32 m_iNumLevels;		// Number of mipmap levels	(BinaryBitmaps)
	CInternBinaryBitmap * m_pMipMaps;	// always at least one level
};


class CInternTextureSeq
{
	friend class CTextureCrunch;

public:
	const float GetDuration() const { return m_fDuration; }
	const int32 GetNumTexFrames() const { return m_iNumTexFrames; }
	const CInternTexture& GetTexFrame(const int32 iNumTex) const { return m_pTexFrames[iNumTex]; }

	CInternTextureSeq() : m_fDuration(-1.0f), m_iNumTexFrames(-1), m_pTexFrames(NULL) {}

private:
	float m_fDuration;
	int32 m_iNumTexFrames;
	CInternTexture * m_pTexFrames;
};


bool	BBbufComp(const CInternBinaryBitmap &bb1, const CInternBinaryBitmap &bb2, const int32 pix_size);
bool	operator ==( const CInternTexture &tex1, const CInternTexture &tex2 );

#endif
