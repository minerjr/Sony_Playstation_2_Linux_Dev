#ifndef __TEXTUREPROPS_H__
#define __TEXTUREPROPS_H__

#include "exttypes.h"
#include <stdio.h>

// Maintains properties of a texture
class CInputContainer;
class CScriptParser;
class CTexturePropContainer;



class CTextureProps
{
	friend class CScriptParser;
	friend class CTexturePropContainer;

public:
	bool GenMipMaps() const;
	bool GenDither() const;
	int32 GetDestMode() const;
	const char * GetUserProps() const;
	const char * GetTexPath() const;

	CTextureProps();
	~CTextureProps();

public:	// secret API
	bool SetTexPath(const char * cptr, const int32 length);
	bool SetUserdefinedProps(const char * cptr, const int32 length);
	bool SetMode(const int32 texprop);
	bool SetMipMap(const bool bSetMipMap);
	bool SetDither(const bool bSetDither);

private:
	int32 m_iMode;
	bool m_bGenMipMapLevels;
	bool m_bGenDither;
	char * m_pTexPath;
	char * m_pUserProps;
};


class CTexturePropContainer
{
	friend class CConv3DS;

public:
	const CTextureProps * TexPropLocate(const char cTexPath[]) const;
	CTextureProps &GetDefaultTexProps();
	const int32 GetNumSpecificTextureProps() const;
	const CTextureProps GetSpecificTextureProp(const int32 iSpecTexProp) const;

	const int32 GetNumTexFolders() const;
	const char * GetTexFolder(const int32 iTexFolderNumber) const;


	CTexturePropContainer()
	{
		m_iNumPropSpecTexts = 0;
		m_pPropsOfSpecTexts = NULL;
		m_iTexFolderListLen = 0;
		m_pTexFolderList = NULL;
	}
	~CTexturePropContainer() {}

protected:
	bool AddTextureFolder(const char * cptr, const int32 length);
	bool AddStringToSpecList(const char * cptr, const int32 length, char *** pppList, int32 * pLenList);

	// list of texture folders
	int32 m_iTexFolderListLen;
	char ** m_pTexFolderList;

private:
	void RemoveLastTexFolder();

protected:
	CTextureProps * PriTexPropLocate(const char cTexPath[]) const;

	// Default texture props
	CTextureProps m_cDefaultProps;

	// Props for specific textures
	int32 m_iNumPropSpecTexts;
	CTextureProps * m_pPropsOfSpecTexts;
};


#endif
