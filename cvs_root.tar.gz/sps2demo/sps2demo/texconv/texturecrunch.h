#ifndef __TEXTURECRUNCH_H__
#define __TEXTURECRUNCH_H__

class CTexturePropContainer;
class CInternTextureSeq;
class CInternTexture;

#include "exttypes.h"
#include <stdio.h>


class CTextureCrunch
{
public:
	CInternTextureSeq * FetchTextureSeq(const char tex_file[], const float fFPS);

	CTextureCrunch(const CTexturePropContainer &texPropContainer, float max_dither);
	~CTextureCrunch();

private:
	CInternTexture * FetchTexture(const char tex_file[]);
	char * LocateNextPathFromIFL(char * max_path, char * pCurLocIFL, const char end_ptr[]);

	struct SRecordTexture
	{
		char * m_pTexPath;
		CInternTexture * m_pInternTex;
	};

	int32 m_iNumOfRecordedTextures;
	SRecordTexture * m_pRecordedTextures;
	float m_maxDither;

private:
	CInternTexture * OpenTexture(const char tex_file[]);
	FILE * OpenFile(const char file[]);
	bool DevilOpenFile(const char tex_file[]);
	void StitchPathAndName(char c_out[], const char path[], const char file[]);

	const CTexturePropContainer &m_cPropContainer;
};

#endif
