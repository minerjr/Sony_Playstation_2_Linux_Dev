#include "interntextureseq.h"
#include "pixel_formats.h"


void CInternBinaryBitmap::CleanUp()
{
	if(m_pPixelData!=NULL) { delete [] m_pPixelData; m_pPixelData=NULL; }
}

void CInternTexture::CleanUp()
{
	for(int l=0; l<GetNumLevels(); l++)
		m_pMipMaps[l].CleanUp();
	
	if(m_pInternPalette!=NULL) { delete [] m_pInternPalette; m_pInternPalette=NULL; }
	if(m_pUserDefProps!=NULL) { delete [] m_pUserDefProps; m_pUserDefProps=NULL; }
	if(m_pMipMaps!=NULL) { delete [] m_pMipMaps; m_pMipMaps=NULL; }
}


bool	BBbufComp(const CInternBinaryBitmap &bb1, const CInternBinaryBitmap &bb2, const int32 pix_size)
{
	bool bMatch = false;

	if(bb1.GetWidth()==bb2.GetWidth())
	{
		if(bb1.GetHeight()==bb2.GetHeight())
		{
			const char * ptr1 = (const char *) bb1.GetPixData();
			const char * ptr2 = (const char *) bb2.GetPixData();
			const int32 bytes_to_check = bb1.GetWidth()*bb1.GetHeight()*pix_size;
			int i=0;
			bool bPixMatch = true;
			while(i<bytes_to_check && bPixMatch)	// times 4 since it's always a 32bit palette
			{
				bPixMatch = ptr1[i]==ptr2[i];
				++i;
			}
			bMatch = bPixMatch;
		}
	}

	return bMatch;
}

bool	operator ==( const CInternTexture &tex1, const CInternTexture &tex2 )
{
	bool bMatch = false;

	// do a matchup
	const char * pUsrProp1 = tex1.GetUserDefProps();
	const char * pUsrProp2 = tex2.GetUserDefProps();
	if(	(pUsrProp1==NULL && pUsrProp2==NULL) || 
			( (pUsrProp1!=NULL && pUsrProp2!=NULL) && strcmp(pUsrProp1, pUsrProp2)==0 )
		)
	{
		if(tex1.GetPixelFormat()==tex2.GetPixelFormat())
		{
			if(tex1.GetNumLevels()==tex2.GetNumLevels())
			{	
				bool bPaletteMatch = true;
				
				// test colors and fetch pixel size
				int32 pix_size;
				if(tex1.GetPixelFormat()!=COLORRGBA32)
				{
					const int32 num_colors = (tex1.GetPixelFormat()==INDEXCOLOR16) ? 16 : 256;
					pix_size = 1;
					const char * ptr1 = (const char *) tex1.GetPalette();
					const char * ptr2 = (const char *) tex2.GetPalette();
					int i=0;
					while(i<num_colors*4 && bPaletteMatch)	// times 4 since it's always a 32bit palette
					{
						bPaletteMatch = ptr1[i]==ptr2[i];
						++i;
					}
				}
				else
					pix_size = 4;

				// match up mipmap levels
				if(bPaletteMatch)
				{
					bool bLevelsMatch = true;
					const int32 num_levels = tex1.GetNumLevels();
					int i=0;
					while(i<num_levels && bLevelsMatch)
					{
						bLevelsMatch = BBbufComp(*tex1.GetLevel(i), *tex2.GetLevel(i), pix_size);
						++i;
					}

					bMatch = bLevelsMatch;
				}
			}
		}
	}

	return bMatch;
}
