#include "textureprops.h"
#include "pixel_formats.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>

// Public API TexturePropContainer
const CTextureProps * CTexturePropContainer::TexPropLocate(const char cTexPath[]) const
{
	const CTextureProps * pTexProps = PriTexPropLocate(cTexPath);

	return (pTexProps!=NULL) ? pTexProps : &m_cDefaultProps;
}

CTextureProps &CTexturePropContainer::GetDefaultTexProps()
{
	return m_cDefaultProps;
}

const int32 CTexturePropContainer::GetNumSpecificTextureProps() const
{
	return m_iNumPropSpecTexts;
}

const CTextureProps CTexturePropContainer::GetSpecificTextureProp(const int32 iSpecTexProp) const
{
	assert(iSpecTexProp<GetNumSpecificTextureProps());
	return m_pPropsOfSpecTexts[iSpecTexProp];
}


const int32 CTexturePropContainer::GetNumTexFolders() const
{
	return m_iTexFolderListLen;
}

const char * CTexturePropContainer::GetTexFolder(const int32 iTexFolderNumber) const
{
	assert(iTexFolderNumber<GetNumTexFolders());
	return m_pTexFolderList[iTexFolderNumber];
}


// Public API TextureProps
bool CTextureProps::GenMipMaps() const
{
	return m_bGenMipMapLevels;
}

bool CTextureProps::GenDither() const
{
	return m_bGenDither;
}

int32 CTextureProps::GetDestMode() const
{
	return m_iMode;
}

const char * CTextureProps::GetUserProps() const
{
	return m_pUserProps;
}

const char * CTextureProps::GetTexPath() const
{
	return m_pTexPath;
}

// Secret API TexturePropContainer
bool CTexturePropContainer::AddTextureFolder(const char * cptr, const int32 length)
{
	return AddStringToSpecList(cptr, length, &m_pTexFolderList, &m_iTexFolderListLen);
}


bool CTexturePropContainer::AddStringToSpecList(const char * cptr, const int32 length, char *** pppList, int32 * pLenList)
{
	char * pString = NULL;
	bool bRes = false;

	if((pString = new char[length+1]) != NULL)
	{
		memcpy(pString, cptr, length);
		pString[length] = '\0';

		char ** pOldPointer = *pppList;
		*pppList = NULL;
		if((*pppList = new char*[*pLenList+1]) != NULL)
		{
			for(int i=0; i<*pLenList; i++)
				(*pppList)[i] = pOldPointer[i];
			if(pOldPointer != NULL) delete [] pOldPointer;
			(*pppList)[*pLenList] = pString;
			*pLenList = *pLenList + 1;
			bRes = true;
		}
		else
		{
			// cleanup, we failed
			delete [] pString;
			*pppList = pOldPointer;
		}
	}

	return bRes;
}

void CTexturePropContainer::RemoveLastTexFolder()
{
	assert(m_iTexFolderListLen>0 && m_pTexFolderList!=NULL);
	delete [] m_pTexFolderList[m_iTexFolderListLen-1];
	--m_iTexFolderListLen;
}


CTextureProps * CTexturePropContainer::PriTexPropLocate(const char cTexPath[]) const
{
	// locate entry
	bool bFound=false;
	int i=0;
	while(i<m_iNumPropSpecTexts && !bFound)
	{
		if(strcasecmp(cTexPath, m_pPropsOfSpecTexts[i].m_pTexPath) == 0)
			bFound = true;
		else
			++i;
	}

	return (bFound) ? &m_pPropsOfSpecTexts[i] : NULL;
}


// Secret API TextureProps
bool CTextureProps::SetTexPath(const char * cptr, const int32 length)
{
	// check if output has been set already
	if(m_pTexPath!=NULL)
	{
		delete [] m_pTexPath;
		m_pTexPath = NULL;
	}

	// fetch string
	bool bRes = false;

	if((m_pTexPath = new char[length+1]) != NULL)
	{
		memcpy(m_pTexPath, cptr, length);
		m_pTexPath[length] = '\0';
		bRes = true;
	}

	return bRes;
}

bool CTextureProps::SetUserdefinedProps(const char * cptr, const int32 length)
{
	// check if output has been set already
	if(m_pUserProps!=NULL)
	{
		delete [] m_pUserProps;
		m_pUserProps = NULL;
	}

	// fetch string
	bool bRes = false;

	if((m_pUserProps = new char[length+1]) != NULL)
	{
		memcpy(m_pUserProps, cptr, length);
		m_pUserProps[length] = '\0';
		bRes = true;
	}

	return bRes;
}

bool CTextureProps::SetMode(const int32 mode)
{
	m_iMode = mode;
	return true;
}

bool CTextureProps::SetMipMap(const bool bSetMipMap)
{
	m_bGenMipMapLevels = bSetMipMap;
	return true;
}

bool CTextureProps::SetDither(const bool bSetDither)
{
	m_bGenDither = bSetDither;
	return true;
}




// constructor and destructor
CTextureProps::CTextureProps()
{
	m_pTexPath = NULL;
	m_pUserProps = NULL;
	m_iMode = COLORRGBA32;
	SetMipMap(false);
	SetDither(false);
}

CTextureProps::~CTextureProps()
{

}
