#include "textureprops.h"
#include "texturecrunch.h"
#include "interntextureseq.h"
#include <stdio.h>
#include <string.h>

int main(int argc, const char **argv)
{
	int mode = 4;
	bool mipmap = false, dither = false;
	float max_dither = 16;

	for(int i = 3; i < argc; i++)
	{
		if(strcmp(argv[i], "INDEX4") == 0)
			mode = 1;
		else if(strcmp(argv[i], "INDEX8") == 0)
			mode = 2;
		else if(strcmp(argv[i], "RGBA32") == 0)
			mode = 4;
		else if(strcmp(argv[i], "MIPMAP") == 0)
			mipmap = true;
		else if(strcmp(argv[i], "DITHER") == 0)
			dither = true;
		else if(strncmp(argv[i], "DITHER", 6) == 0)
		{
			dither = true;
			sscanf(argv[i], "DITHER%f", &max_dither);
		}
		else
			printf("Unknown option '%s'\n", argv[i]);
	}
	
	CTexturePropContainer tcont;
	CTextureProps &props = tcont.GetDefaultTexProps();

	props.SetTexPath("", 0);
	props.SetUserdefinedProps("", 0);
	props.SetMode(mode);
	props.SetMipMap(mipmap);
	props.SetDither(dither);

	CTextureCrunch crunch(tcont, max_dither);
	CInternTextureSeq *tseq = crunch.FetchTextureSeq(argv[1], 30);
	const CInternTexture &tex = tseq->GetTexFrame(0);

	FILE *file = fopen(argv[2], "wb");

	mode = tex.GetPixelFormat();
	fwrite(&mode, 4, 1, file);

	if(mode == 1)
		fwrite(tex.GetPalette(), 4, 16, file);
	else if(mode == 2)
		fwrite(tex.GetPalette(), 4, 256, file);

	int numLevels = tex.GetNumLevels();
	fwrite(&numLevels, 4, 1, file);

	for(int i = 0; i < numLevels; i++)
	{
		const CInternBinaryBitmap *bm = tex.GetLevel(i);
		int w = bm->GetWidth();
		fwrite(&w, 4, 1, file);
		int h = bm->GetHeight();
		fwrite(&h, 4, 1, file);

		if(mode == 4)
			fwrite(bm->GetPixData(), w*h, 4, file);
		else
			fwrite(bm->GetPixData(), w*h, 1, file);
	}
	
	return 0;
}
