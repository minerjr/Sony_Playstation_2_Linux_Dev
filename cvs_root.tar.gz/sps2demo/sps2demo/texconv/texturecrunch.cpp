#include "texturecrunch.h"
#include "textureprops.h"
#include "interntextureseq.h"
#include "pixel_formats.h"
#include "quantizer.h"
#include <string.h>
#include <assert.h>
#include <IL/il.h>
#include <IL/ilu.h>

#ifndef WIN32
#include <dirent.h>
#endif


// public
CInternTextureSeq * CTextureCrunch::FetchTextureSeq(const char tex_file[], const float fFPS)
{
	// result
	CInternTextureSeq * resTexSeq = NULL;

	// check if we have a file?
	if(tex_file != NULL && strlen(tex_file)>0)
	{
		// determine if this is an ifl file
		const int32 len = strlen(tex_file);
		if((strcmp(&tex_file[len-4], ".ifl") == 0) || 
		   (strcmp(&tex_file[len-4], ".IFL") == 0) )	// ifl file
		{
			// open file
			FILE * fptr = NULL;
			if( (fptr=OpenFile(tex_file)) != NULL)
			{

				// prealloc sequence structure
				resTexSeq = new CInternTextureSeq;
				assert(resTexSeq != NULL);
				resTexSeq->m_fDuration = -1;
				resTexSeq->m_iNumTexFrames = 0;
				resTexSeq->m_pTexFrames = NULL;

				// Fetch file size
				fseek(fptr, 0, SEEK_END);
				const int32 end = ftell(fptr);
				fseek(fptr, 0, SEEK_SET);
				const int32 szeIFL = end - ftell(fptr);
				assert(szeIFL > 0);

				// Allocate parse mem
				char * parse_mem = NULL;
				parse_mem = new char[szeIFL*2 + 1];
				assert(parse_mem!=NULL);
				char * max_path = parse_mem + szeIFL;	// plus 1 char for null termination

				// Read file
				fread(parse_mem, szeIFL, 1, fptr);


				// while we find readable file names
				const char * pEndPtr = parse_mem + szeIFL;
				char * pCurLoc = parse_mem;
				bool bNotDone = true;
				while(bNotDone)
				{
					bNotDone = false;	// Default value

					// if located accurately
					if((pCurLoc=LocateNextPathFromIFL(max_path, pCurLoc, pEndPtr)) != NULL)
					{
						// fetch texture
						CInternTexture * pTex = FetchTexture(max_path);
						if(pTex!=NULL)
						{
							// Add Texture to Sequence
							const int32 iNewNumTexFrames = resTexSeq->m_iNumTexFrames + 1;
							CInternTexture * pOldFramesArray = resTexSeq->m_pTexFrames;
							resTexSeq->m_pTexFrames = NULL;
							resTexSeq->m_pTexFrames=new CInternTexture[iNewNumTexFrames];
							assert( resTexSeq->m_pTexFrames != NULL );

							// copy old ones
							for(int t=0; t<resTexSeq->m_iNumTexFrames; t++)
								resTexSeq->m_pTexFrames[t] = pOldFramesArray[t]; 

							// insert new one
							resTexSeq->m_pTexFrames[resTexSeq->m_iNumTexFrames] = *pTex;
							resTexSeq->m_iNumTexFrames = iNewNumTexFrames; 

							// delete old array if any
							if(pOldFramesArray != NULL)
								delete [] pOldFramesArray;

							// set extra run flag
							bNotDone = true;
						}
						else
							printf("failed to open %s, from IFL file %s\n", max_path, tex_file);
					}
				}

				// Cleanup
				fclose(fptr); fptr = NULL;
				delete [] parse_mem;
			}
			else
				printf("failed to open %s\n", tex_file);
		}
		else	// not an ifl file
		{
			// fetch texture
			CInternTexture * pTex = FetchTexture(tex_file);
			if(pTex!=NULL)
			{
				resTexSeq = new CInternTextureSeq;
				assert(resTexSeq != NULL);
				*((uint32 *) &resTexSeq->m_fDuration) = (0xff<<23);
				resTexSeq->m_iNumTexFrames = 1;
				resTexSeq->m_pTexFrames = pTex;
			}
			else
				printf("failed to open %s\n", tex_file);
		}	
	}

	// set duration
	if(resTexSeq != NULL)
		resTexSeq->m_fDuration = resTexSeq->m_iNumTexFrames / fFPS;

	return resTexSeq;
}


// private
CInternTexture * CTextureCrunch::FetchTexture(const char tex_file[])
{
	// Setup a result
	CInternTexture * res = NULL;

	/*// lookup texture in list of recorded entries
	bool bFound=false;
	int i=0;
	while(i<m_iNumOfRecordedTextures && !bFound)
	{
		if(strcmp(m_pRecordedTextures[i].m_pTexPath, tex_file)==0)
		{
			res = m_pRecordedTextures[i].m_pInternTex;	// get texture
			bFound = true;
		}
		else
			++i;
	}

	// If we didn't find a match?
	if(bFound == false)*/
	{
		// Alloc an extra entry in array of records
		SRecordTexture * pNewArray = NULL;
		pNewArray=new SRecordTexture[m_iNumOfRecordedTextures+1];
		assert(pNewArray != NULL);

		int str_len = strlen(tex_file);
		pNewArray[m_iNumOfRecordedTextures].m_pTexPath = NULL;
		pNewArray[m_iNumOfRecordedTextures].m_pTexPath = new char[str_len + 1];
		assert(pNewArray[m_iNumOfRecordedTextures].m_pTexPath != NULL);

		strcpy(pNewArray[m_iNumOfRecordedTextures].m_pTexPath, tex_file);
		assert(pNewArray[m_iNumOfRecordedTextures].m_pTexPath[str_len]=='\0');

		for(int i=0; i<m_iNumOfRecordedTextures; i++)
			pNewArray[i] = m_pRecordedTextures[i];

		res = OpenTexture(tex_file);
		/*bool bAddNewTexture = (res!=NULL);

		// look for a duplicate texture
		if(bAddNewTexture)
		{
			int i=0;
			while(i<m_iNumOfRecordedTextures && bAddNewTexture)
				if(m_pRecordedTextures[i].m_pInternTex[0] == res[0])
				{
					res->CleanUp();
					delete res;
					res = m_pRecordedTextures[i].m_pInternTex;	// get texture
					bAddNewTexture = false;
				}
				else
					++i;
		}
		
		// update list of unique entries
		if(!bAddNewTexture)*/
		if(res==NULL)
		{
			delete [] pNewArray[m_iNumOfRecordedTextures].m_pTexPath;
			delete [] pNewArray;
		}
		else
		{
			delete [] m_pRecordedTextures;
			m_pRecordedTextures = pNewArray;
			m_pRecordedTextures[m_iNumOfRecordedTextures++].m_pInternTex = res;
		}
	}


	return res;
}

char * CTextureCrunch::LocateNextPathFromIFL(char * max_path, char * pCurLocIFL, const char end_ptr[])
{
	// return pointer
	char * res = NULL;

	// remove whitespace
	while(
		  (pCurLocIFL < end_ptr) &&
		  (pCurLocIFL[0]=='\r' || pCurLocIFL[0]=='\t' || pCurLocIFL[0]=='\n' || pCurLocIFL[0]==' ')
		  )
		  ++pCurLocIFL;
	
	// pull out path
	if(pCurLocIFL < end_ptr)
	{
		int32 i=0;
		while((pCurLocIFL < end_ptr) && pCurLocIFL[0]!='\n')
			max_path[i++] = *pCurLocIFL++;

		if(i>1)	// if we were able to remove anything from file
		{
			res = pCurLocIFL;
			max_path[i-1]='\0';	// -1 cuz we skipped past a newline
		}
	}

	return res;
}


// Devil and picture handling functions
CInternTexture * CTextureCrunch::OpenTexture(const char tex_file[])
{
	// return value
	CInternTexture * res = NULL;

	// Disconnect filename from path
	const int32 str_len = strlen(tex_file);
	int32 loc = str_len - 1;
	while(loc>=0 && !( (tex_file[loc]=='\\') || (tex_file[loc]=='/') || (tex_file[loc]==':') ))
		--loc;
	++loc;	// one char back.


	// fetch properties of current texture
	const CTextureProps * pTexProps = m_cPropContainer.TexPropLocate(tex_file+loc);
	assert(pTexProps != NULL);

	// let the reading begin
	ILuint id, Error;

	ilInit();
	ilEnable(IL_ORIGIN_SET);
	ilOriginFunc(IL_ORIGIN_UPPER_LEFT);

	ilGenImages(1, &id);
	ilBindImage(id);

	// load picture
	//ilLoadImage((char *) tex_file);  // Loads into the current bound image
	//Error = ilGetError();
	//if(Error == IL_NO_ERROR)
	if(DevilOpenFile(tex_file))
	{
		// keep image in rgba format
		ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);
		Error = ilGetError();
		if(Error == IL_NO_ERROR)
		{
			// need mipmaps?
			if(pTexProps->GenMipMaps())
			{
				iluBuildMipmaps();
				assert(ilGetError() == IL_NO_ERROR);
			}

			// Allocate buffers for pixels (destination format)
			int32 dst_mode = pTexProps->GetDestMode();
			int32 pix_size;
			switch(dst_mode)
			{
				case INDEXCOLOR16:
					pix_size = 1;
					break;
				case INDEXCOLOR256:
					pix_size = 1;
					break;
				case COLORRGBA32:
					pix_size = 4;
					break;
				default:
					assert(false);	// unknown format
			};

			// do a pixel count
			ILint num_levels = ilGetInteger( IL_NUM_MIPMAPS );	// get index of last level (confusing name)
			int32 iNumPixels = 0;
			for(int i=0; i<num_levels+1; i++)
			{
				ilActiveMipmap(0);	// some stupid devil bug (it's required)
				ILboolean res_last = ilActiveMipmap(i);
				assert(res_last==IL_TRUE || !pTexProps->GenMipMaps());
				ILint width = ilGetInteger( IL_IMAGE_WIDTH );
				ILint height = ilGetInteger( IL_IMAGE_HEIGHT );
				iNumPixels += width*height;
			}

			// alloc data
			uint8 * pPixData = NULL, * pPalPtr = NULL;
			pPixData = new uint8[iNumPixels*pix_size];
			assert(pPixData != NULL);

			// fetch data
			if(dst_mode==INDEXCOLOR16 || dst_mode==INDEXCOLOR256)
			{
				// do colorreduction
				Quantizer quant;

				// Feed quantizer
				for(int i=0; i<num_levels+1; i++)
				{
					ilActiveMipmap(0);	// some stupid devil bug (it's required)
					ILboolean res_last = ilActiveMipmap(i);
					assert(res_last==IL_TRUE || !pTexProps->GenMipMaps());
					ILint width = ilGetInteger( IL_IMAGE_WIDTH );
					ILint height = ilGetInteger( IL_IMAGE_HEIGHT );
					quant.feedImage(ilGetData(), width*height);
				}
				
				// quantize
				quant.quantize((dst_mode==INDEXCOLOR16) ? 16 : 256);

				// copy palette
				pPalPtr = new uint8[256*4];
				assert(pPalPtr != NULL);
				memcpy(pPalPtr, quant.getPalette(), 256*4);

				// Get dither prop
				float max_dither = (pTexProps->GenDither()) ? m_maxDither : 0.0f;

				// fill up buffers
				uint8 * pix_ptr = pPixData;
				for(int i=0; i<num_levels+1; i++)
				{
					ilActiveMipmap(0);	// some stupid devil bug (it's required)
					ILboolean res_last = ilActiveMipmap(i);
					assert(res_last==IL_TRUE || !pTexProps->GenMipMaps());
					ILint width = ilGetInteger( IL_IMAGE_WIDTH );
					ILint height = ilGetInteger( IL_IMAGE_HEIGHT );
					uint8 * devil_data = ilGetData();

					// ask quant for pixels
					for(int y=0; y<height; y++)
						for(int x=0; x<width; x++)
						{
							Quantizer::color col;
							col.r = *devil_data++;
							col.g = *devil_data++;
							col.b = *devil_data++;
							col.a = *devil_data++;
							*pix_ptr++ = quant.mapPixel(col, x, y, max_dither);
						}
				}

				assert(pix_ptr == (pPixData+iNumPixels));
			}
			else
			{
				// fetch pixelData in 32bit format r,g,b,a
				assert(dst_mode==COLORRGBA32);
				uint8 * pix_ptr = pPixData;
				for(int i=0; i<num_levels+1; i++)
				{
					ilActiveMipmap(0);	// some stupid devil bug (it's required)
					ILboolean res_last = ilActiveMipmap(i);
					assert(res_last==IL_TRUE || !pTexProps->GenMipMaps());
					ILint width = ilGetInteger( IL_IMAGE_WIDTH );
					ILint height = ilGetInteger( IL_IMAGE_HEIGHT );
					memcpy(pix_ptr, ilGetData(), width*height*pix_size);
					pix_ptr += (width*height*pix_size);
				}

				assert(pix_ptr == (pPixData+(iNumPixels*pix_size)));
			}

			// Everything worked, now create the CInternTexture
			res = new CInternTexture;
			assert(res != NULL);
			res->m_iNumLevels = num_levels+1;
			res->m_iPixelFormat = pTexProps->GetDestMode();
			res->m_pInternPalette = pPalPtr;
			res->m_pUserDefProps = NULL;
			if(pTexProps->GetUserProps() != NULL)
			{
				res->m_pUserDefProps = new char[strlen(pTexProps->GetUserProps())+1];
				assert(res->m_pUserDefProps != NULL);
				strcpy(res->m_pUserDefProps, pTexProps->GetUserProps());
			}
			res->m_pMipMaps = NULL;
			res->m_pMipMaps = new CInternBinaryBitmap[res->m_iNumLevels];
			assert(res->m_pMipMaps != NULL);

			uint8 * pix_ptr = pPixData;
			for(int i=0; i<num_levels+1; i++)
			{
				ilActiveMipmap(0);	// some stupid devil bug (it's required)
				ILboolean res_last = ilActiveMipmap(i);
				assert(res_last==IL_TRUE || !pTexProps->GenMipMaps());
				res->m_pMipMaps[i].m_iWidth = ilGetInteger( IL_IMAGE_WIDTH );
				res->m_pMipMaps[i].m_iHeight = ilGetInteger( IL_IMAGE_HEIGHT );
				
				const int32 pix_buf_size = res->m_pMipMaps[i].m_iWidth*res->m_pMipMaps[i].m_iHeight*pix_size;
				res->m_pMipMaps[i].m_pPixelData = NULL;
				res->m_pMipMaps[i].m_pPixelData = (uint8 *) new char *[pix_buf_size];
				assert(res->m_pMipMaps[i].m_pPixelData != NULL);
				memcpy(res->m_pMipMaps[i].m_pPixelData, pix_ptr, pix_buf_size);
				pix_ptr += pix_buf_size;
			}

			assert(pix_ptr == (pPixData+(iNumPixels*pix_size)));
			delete [] pPixData;
		}

	}

	// close image
	ilDeleteImages(1, &id);

	// return
	return res;
}

FILE * CTextureCrunch::OpenFile(const char file[])
{
	// first try default filename
	FILE * fptr = NULL;
	bool bFound = (fptr=fopen(file, "rb")) != NULL;

	// try using all combinations of paths given from script
	int t = 0;
	while(t<m_cPropContainer.GetNumTexFolders() && !bFound)
	{
		// length of path, length of filename, 1 for slash/backslash
		// seperator if required, and 1 for a null termination.
		const int32 str_len = strlen(m_cPropContainer.GetTexFolder(t)) + strlen(file) + 1 + 1;
		char * cptr = NULL;
		cptr = new char[str_len];
		assert(cptr != NULL);

		// put a default string in the string buffer
		StitchPathAndName(cptr, m_cPropContainer.GetTexFolder(t), file);
#ifndef WIN32
		DIR * dp;	// handle case insensitivity
		struct dirent * ep;
		if((dp=opendir(m_cPropContainer.GetTexFolder(t))) != NULL)
		{
			while((ep=readdir(dp))!=NULL && !bFound)
				if(strcasecmp(ep->d_name, file)==0)
				{
					StitchPathAndName(cptr, m_cPropContainer.GetTexFolder(t), ep->d_name);
					bFound=true;
				}
			closedir(dp);
		}
#endif
		bFound = (fptr=fopen(cptr, "rb")) != NULL;
		delete [] cptr; cptr = NULL;

		// next
		++t;
	}

	return fptr;
}

bool CTextureCrunch::DevilOpenFile(const char tex_file[])
{
	// first try default filename
	ilLoadImage((char *) tex_file);  // Loads into the current bound image
	bool bFound = (ilGetError() == IL_NO_ERROR);
	
	// try using all combinations of paths given from script
	int t = 0;
	while(t<m_cPropContainer.GetNumTexFolders() && !bFound)
	{
		// length of path, length of filename, 1 for slash/backslash
		// seperator if required, and 1 for a null termination.
		const int32 str_len = strlen(m_cPropContainer.GetTexFolder(t)) + strlen(tex_file) + 1 + 1;
		char * cptr = NULL;
		cptr = new char[str_len];
		assert(cptr != NULL);

		// put a default string in the string buffer
		StitchPathAndName(cptr, m_cPropContainer.GetTexFolder(t), tex_file);
#ifndef WIN32
		DIR * dp;	// handle case insensitivity
		struct dirent * ep;
		if((dp=opendir(m_cPropContainer.GetTexFolder(t))) != NULL)
		{
			while((ep=readdir(dp))!=NULL && !bFound)
				if(strcasecmp(ep->d_name, tex_file)==0)
				{
					StitchPathAndName(cptr, m_cPropContainer.GetTexFolder(t), ep->d_name);
					bFound=true;
				}
			closedir(dp);
		}
#endif
		ilLoadImage((char *) cptr);  // Loads into the current bound image
		bFound = (ilGetError() == IL_NO_ERROR);

		delete [] cptr; cptr = NULL;

		// next
		++t;
	}

	return bFound;

}

void CTextureCrunch::StitchPathAndName(char c_out[], const char path[], const char file[])
{
	// fill up c_out with path
	int32 len_path = strlen(path);
	strcpy(c_out, path);

	// check if we need a seperator
	bool bNeedSepSlash = len_path>0 && path[len_path-1]!='\\' && path[len_path-1]!='/' && path[len_path-1]!=':';
	if(bNeedSepSlash)
	{
		// should we use forward or backwards slash?
		char ch = '/';	// default value
		
		// if we find a backslash in the string then assume DOS notation
		for(int k=0; k<len_path; k++)
			if(path[k]=='\\')
				ch = '\\';

		// insert and increase path length
		c_out[len_path++]=ch;
	}
	
	// copy rest of file name to c_out
	strcpy(c_out+len_path, file);
}

// constructor and destructor
CTextureCrunch::CTextureCrunch(const CTexturePropContainer &texPropContainer, float max_dither) : m_cPropContainer(texPropContainer)
{
	m_iNumOfRecordedTextures = 0;
	m_pRecordedTextures = NULL;
	m_maxDither = max_dither;
}

CTextureCrunch::~CTextureCrunch()
{



}
