#ifndef CRASHZOOM_H
#define CRASHZOOM_H

class Posteffecthelper;

void crashzoom(Posteffecthelper &hlp, int bp, int bp2, int bw, int w, int h,
		int depth, float scale, float alpha, float cx, float cy, float gain = 1);
void crashzoom(Posteffecthelper &hlp, int depth, float scale, float alpha,
		float cx, float cy, float gain = 1);
void crashzoom(int bp, int bp2, int bw, int w, int h, int depth, float scale,
		float alpha, float cx, float cy, float gain = 1);
void crashzoom(int depth, float scale, float alpha, float cx, float cy, float gain = 1);

#endif /* CRASHZOOM_H */
