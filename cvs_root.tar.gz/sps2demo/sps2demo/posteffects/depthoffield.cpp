#include "depthoffield.h"
#include "rgbaindexer.h"
#include "screen.h"
#include "types.h"
#include "dma.h"
#include "posteffecthelper.h"
#include "blur.h"
#include <linux/ps2/dev.h>

DepthOfField::DepthOfField()
{
	u32 pal[256];
	for(int i = 0; i < 256; i++)
	{
		float n = (float)i / 256;
		pal[i] = (int)(n*n*n * 128) * 0x1010101;
	}
	m_pPal = BuildPaletteUploadChain(510, pal);

	m_pTessel1 = BuildIndexChain(300, 0, 300, 510, 0, 0, 640, 480);
	m_pTessel2 = BuildIndexChain(300, 150, 300, 510, 0, 0, 640, 480);
}

DepthOfField::~DepthOfField()
{
}

void DepthOfField::render()
{
	{
		// clear alpha channel to 0x80
		Posteffecthelper hlp;
		hlp.setFrame(screen.getCurrentBuffer() * 150, 10, 0, 0x00ffffff);
		hlp.setRgba(0, 0, 0, 0x80);
		hlp.blit(0, 0, 640, 480);
	}

	// set ztest
	dynDma.startDirect();
	dynDma.startAD();
	dynDma.addAD(PS2_GS_TEST_2, PS2_GS_SETREG_TEST(0, 0, 0, 0, 0, 0, 1, 2));
	dynDma.endAD();
	dynDma.endDirect();

	UploadIndexChain(screen.getCurrentBuffer() ? m_pTessel2 : m_pTessel1, 1, 0x00ffffff, true,
			0x00ffff, false, m_pPal);

	{
		Posteffecthelper hlp;

		hlp.setFrame(300, 10);
		hlp.blit(0, 0, 640, 480, false, true);

		blur(hlp, 300, 450, 10, 640, 480, 2, 1.0f, 0);

		hlp.setClamp(2, 2, 0, 639, 0, 479);
		hlp.setFrame();
		hlp.setTex0(300, 10);
		hlp.setAlpha(1, 0, 1, 0, 0);
		hlp.blit(0, 0, 640, 480, -1.0, -1.0f, 639.0f, 479.0f, true, true);
	}
}
