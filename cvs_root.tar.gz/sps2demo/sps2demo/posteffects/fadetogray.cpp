#include "fadetogray.h"
#include "rgbaindexer.h"
#include "screen.h"
#include "types.h"
#include "dma.h"
#include "posteffecthelper.h"
#include <linux/ps2/dev.h>

FadeToGray::FadeToGray()
{
	u32 pal[256];
	for(int i = 0; i < 256; i++)
		pal[i] = (i / 2) * 0x1010101;

	m_pZPal = BuildPaletteUploadChain(510, pal);
	m_pZTessel1 = BuildIndexChain(300, 0, 300, 510, 0, 0, 640, 480);
	m_pZTessel2 = BuildIndexChain(300, 150, 300, 510, 0, 0, 640, 480);
	
	for(int i = 0; i < 256; i++)
		pal[i] = i * 0x1010101;
	
	m_pGPal = BuildPaletteUploadChain(510, pal);
	m_pGTessel1 = BuildIndexChain(0, 0, 300, 510, 0, 0, 640, 480);
	m_pGTessel2 = BuildIndexChain(150, 150, 300, 510, 0, 0, 640, 480);
}

FadeToGray::~FadeToGray()
{
}

void FadeToGray::render()
{
	{
		// clear alpha channel to 0x80
		Posteffecthelper hlp;
		hlp.setFrame(screen.getCurrentBuffer() * 150, 10, 0, 0x00ffffff);
		hlp.setRgba(0, 0, 0, 0x80);
		hlp.blit(0, 0, 640, 480);
	}
	
	const void *pTessel;

	// set ztest
	dynDma.startDirect();
	dynDma.startAD();
	dynDma.addAD(PS2_GS_TEST_2, PS2_GS_SETREG_TEST(0, 0, 0, 0, 0, 0, 1, 2));
	dynDma.endAD();
	dynDma.endDirect();
	
	pTessel = screen.getCurrentBuffer() ? m_pZTessel2 : m_pZTessel1;

	UploadIndexChain(pTessel, 1, 0x00ffffff, true, 0x00ffff, false, m_pZPal);

	// disable ztest, set alpha blend
	dynDma.startDirect();
	dynDma.startAD();
	dynDma.addAD(PS2_GS_ALPHA_2, PS2_GS_SETREG_ALPHA(1, 0, 1, 0, 0));
	dynDma.endAD();
	dynDma.endDirect();
	
	pTessel = screen.getCurrentBuffer() ? m_pGTessel2 : m_pGTessel1;
	
	UploadIndexChain(pTessel, 1, 0x00000000, false, 0xffffff, true, m_pGPal);
}
