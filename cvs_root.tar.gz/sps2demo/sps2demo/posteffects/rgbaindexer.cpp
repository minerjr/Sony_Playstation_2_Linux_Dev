#include "rgbaindexer.h"
#include "dma.h"
#include "debug.h"
#include "vucode.h"
#include <linux/ps2/dev.h>


const uint32 UnfoldAddList(uint32 * pVramLoc, const bool bFirst, uint32 uCurPageCount, const uint32 delivery_number, const uint32 uActHorzPages, const uint32 uAdder, const uint32 uPading, const uint32 uVifStartAddr);

const void * BuildIndexChain(const uint32 uVRamSrc, const uint32 uVRamDst, const uint32 uVRamZbufArg, const uint32 uVRamPaletteLocation,
									  const int32 x, const int32 y, const int32 dimx, const int32 dimy, const bool bEnableZwrite, const uint32 uBufferWidth )
{
	// record location
	const void * pPhysChain = (const void *) staticDma.getPtr();
	
	// snap to surrounding page grid
	const int32 X0 = x & (~63);
	const int32 Y0 = y & (~31);
	const int32 dimX = (dimx+(x&63)+63) & (~63);
	const int32 dimY = (dimy+(y&31)+31) & (~31);
	ASSERT((X0&63)==0 && (dimX&63)==0);
	ASSERT((Y0&31)==0 && (dimY&31)==0);
	int32 num_pages = (dimX/64)*(dimY/32);

	// define horizontal area in pages
	ASSERT((uBufferWidth&63)==0 && dimX<=(int32) uBufferWidth);
	const uint32 uActHorzPages = dimX/64;
	const uint32 uRemHorzPages = (uBufferWidth/64) - uActHorzPages;

	// Make initial locations in vram
	const uint32 uVRamOffs = (Y0/32)*(uBufferWidth/64) + (X0/64);
	uint32 uVRamFrame = uVRamDst + uVRamOffs;
	uint32 uVRamTex0 = (uVRamSrc + uVRamOffs)*32;
	uint32 uVRamZBuf = uVRamZbufArg + uVRamOffs;

	//const uint32 uNumPageLines = dimY/32;

	// deliver attributes
	uint32 uCurPageCount = 0;
	bool bFirstRun = true;
	while(num_pages>0)
	{
		const int32 deliver_pages = (num_pages > 40) ? 40 : num_pages;
		staticDma.addItop( deliver_pages );		// num_pages
					
		// set Mode to difference mode
		staticDma.stmod(2);
		staticDma.addStcycl(3,1);

		// set FRAME and MASK
		// set row FRAME_2(uVRamFrame, 1, 0, uMask)
		staticDma.stmask(0x58585858);
		staticDma.strow();
		staticDma.add64( PS2_GS_SETREG_FRAME(uVRamFrame, 1, 0, 0) );
		staticDma.add64( PS2_GS_FRAME_2 );

		// unfold the next "deliver_pages" FRAMEs
		UnfoldAddList(&uVRamFrame, bFirstRun, uCurPageCount, deliver_pages, uActHorzPages, 1, (uRemHorzPages+1), 3);
		
		// set TEX0
		// set row TEX0_2(uVRamTex0, 2*uWidth/64, ..)
		staticDma.stmask(0x54545454);
		staticDma.strow();
		staticDma.add64( PS2_GS_SETREG_TEX0(uVRamTex0, 2, 0x13, 7, 6, 1, 1, uVRamPaletteLocation*32, 0, 0, 0, 1) );
		staticDma.add64( PS2_GS_TEX0_2 );
			
		// unfold the next "deliver_pages" TEX0s
		UnfoldAddList(&uVRamTex0, bFirstRun, uCurPageCount, deliver_pages, uActHorzPages, 32, (uRemHorzPages+1)*32, 4);

		// set ZBUF
		// set row ZBUF_2(uVRamZBuf, 1, 1)
		staticDma.strow();
		staticDma.add64( PS2_GS_SETREG_ZBUF(uVRamZBuf, 1, ((bEnableZwrite)?0:1)) );
		staticDma.add64( PS2_GS_ZBUF_2 );

		// unfold the next "deliver_pages" ZBUFs
		uCurPageCount = UnfoldAddList(&uVRamZBuf, bFirstRun, uCurPageCount, deliver_pages, uActHorzPages, 1, (uRemHorzPages+1), 5);

		// disable difference mode and restore stcycl pattern
		staticDma.stmod(0);
		staticDma.addStcycl(1,1);
      
		// mscall
		staticDma.addMscal(2);
		
		// next
		num_pages -= deliver_pages;
		bFirstRun = false;

		if(num_pages > 0)
		{
			staticDma.addUnpack(S_32, 1, 1, true);

			// add information (-1) means same settings as for last batch
			staticDma.add32( 0xffffffff );	// Flag
		}
	}

	// terminate and return physical location of chain
	staticDma.ret();
		
	return pPhysChain;
}

// my vu program
extern "C" u64 vu1rgba_indexer_vu[];
VuCode * g_pVUcode = NULL;

void UploadIndexChain(const void * pPhysCallChain, const int channel_number, const uint32 uMask,
							 const bool bIsZbuffer, const uint32 uZdepth, const bool bAlphaEnabled,
							 const void * pPhysPaletteUploadChain)
{
	// make bools
	const bool bRedOrBlue = (channel_number&1)==0;
	const bool bRedOrGreen = channel_number<2;
	
	// if VU code was never created
	if(g_pVUcode==NULL)
		 g_pVUcode = vumanager.createVuCode(vu1rgba_indexer_vu, 512);
	
	// control
	static bool bOldRedOrGreen = false;
	static uint32 uOldMask = 0;
	static int old_channel_number = 0;
	static bool bOldIsZbuffer = false;
	static uint32 uOldZdepth = 0;
	static bool bOldAlphaEnabled = false;
	
	// if code hasn't been uploaded already.
	if(!g_pVUcode->isCurrentCode())
	{
		// set default to change
		bOldRedOrGreen = !bRedOrGreen;
		uOldMask = ~uMask;
		old_channel_number = ~channel_number;
		bOldIsZbuffer = !bIsZbuffer;
		uOldZdepth = ~uZdepth;
		bOldAlphaEnabled = !bAlphaEnabled;

			
		// add micro program
		g_pVUcode->send();

		// mscall init program
		//dynDma.addBase(0);
		//dynDma.addOffset(512);
		dynDma.addStcycl(1,1);
		dynDma.addMscal(0);	// initialize program

		// set Mask
		dynDma.stmod(0);
		
		// set XYOFFSET
		dynDma.startDirect();
		dynDma.startAD();
		dynDma.addAD(PS2_GS_XYOFFSET_2, PS2_GS_SETREG_XYOFFSET(0,0) );
		dynDma.addAD(PS2_GS_SCISSOR_2, PS2_GS_SETREG_SCISSOR(0,640-1,0,480-1) );
		dynDma.addAD(PS2_GS_TEX1_2, PS2_GS_SETREG_TEX1(0,0,0,0,0,0,0) );
		dynDma.endAD();
		dynDma.endDirect();
	}

	// if Palette has been set
	if(pPhysPaletteUploadChain != NULL)
	{
		dynDma.addFlush();
		dynDma.call((const uint32) pPhysPaletteUploadChain);
	}

	// set new MASK
	if(uOldMask != uMask)
	{
		dynDma.stcol();
		for(int k=0; k<4; k++) dynDma.add32(uMask);

		uOldMask = uMask;
	}

	// set CLAMP
	if(bOldRedOrGreen != bRedOrGreen)
	{
		if(pPhysPaletteUploadChain == NULL)
			dynDma.addFlush();
		dynDma.startDirect();
		dynDma.startAD();
		dynDma.addAD(PS2_GS_CLAMP_2, PS2_GS_SETREG_CLAMP(3,0,0xf7,((bRedOrGreen)?0:0x8),0,0) );
		dynDma.addAD(PS2_GS_TEXFLUSH, 0);
		dynDma.endAD();
		dynDma.endDirect();

		bOldRedOrGreen = bRedOrGreen;
	}
	else
	{
		dynDma.startDirect();
		dynDma.startAD();
		dynDma.addAD(PS2_GS_TEXFLUSH, 0);
		dynDma.endAD();
		dynDma.endDirect();
	}
	
	// trigger initial settings
	if(old_channel_number != channel_number ||
		bOldIsZbuffer != bIsZbuffer ||
		uOldZdepth != uZdepth ||
		bOldAlphaEnabled != bAlphaEnabled )
	{	
		dynDma.addUnpack(V4_32, 0, 2, true);

		// add giftag
		const uint32 abe = (bAlphaEnabled)?1:0;
		const uint64 uPrim = PS2_GS_SETREG_PRIM(6, 0, 1, 0, abe, 0, 1, 1, 0);
		dynDma.add64( PS2_GIFTAG_SET_TOPHALF(8*8+8*4, 1, 1, uPrim, PS2_GIFTAG_FLG_PACKED, 4) );
		dynDma.add64( PS2_GIFTAG_REGS_UV | (PS2_GIFTAG_REGS_XYZ2<<4) | ((PS2_GIFTAG_REGS_UV | (PS2_GIFTAG_REGS_XYZ2<<4))<<8));

		// add information, remaining information will be added in the prebuilt chain
		dynDma.add32( (((bRedOrBlue)?1:0) | ((bIsZbuffer)?2:0)) );	// Flag
		dynDma.add32( uZdepth );				// zbuffer depth
		dynDma.add32( 0 );
		dynDma.add32( 0 );

		// update settings
		old_channel_number = channel_number;
		bOldIsZbuffer = bIsZbuffer;
		uOldZdepth = uZdepth;
		bOldAlphaEnabled = bAlphaEnabled;
	}
	else
	{
			// add information (-1) means same settings as for last batch
			dynDma.addUnpack(S_32, 1, 1, true);
			dynDma.add32( 0xffffffff );	// Flag
	}
	
	// add call chain
	ASSERT(pPhysCallChain!=NULL);
	dynDma.call((const uint32) pPhysCallChain);
}



/////////// Add to chain ////////////

void IncCurPageCount(uint32 * pCurPageCount, const uint32 uActHorzPages)
{ 
	const uint32 uCurPageCount = (*pCurPageCount)+1;
	(*pCurPageCount) = (uCurPageCount>=uActHorzPages) ? (uCurPageCount-uActHorzPages) : uCurPageCount;
	ASSERT((*pCurPageCount)<uActHorzPages);
}

const uint32 UnfoldAddList(uint32 * pVramLoc, const bool bFirst, uint32 uCurPageCount, const uint32 delivery_number, const uint32 uActHorzPages, const uint32 uAdder, const uint32 uPading, const uint32 uVifStartAddr)
{
	uint32 uPagesLeft = delivery_number;
	uint32 uVifAddr = uVifStartAddr;
	bool bFirstRun = bFirst;
	
	while(uPagesLeft>0)
	{
		const uint32 uNumBeforeBorder = (uActHorzPages-uCurPageCount)-((bFirstRun)?0:1);
		bool bNeedStitch = ((uPading > 255) && (uPagesLeft>uNumBeforeBorder));
		
		const uint32 uDelivery = (bNeedStitch) ? uNumBeforeBorder:uPagesLeft;
		if(uDelivery>0)
		{
			staticDma.addUnpack(S_8, uVifAddr, uDelivery, true, true, true);
			for(uint32 k=0; k<((uDelivery+3)>>2); k++)
			{
				uint8 uAdders[] = {0,0,0,0};
				ASSERT(k*4<uDelivery);
				const uint32 num_adding = ((uDelivery-k*4)>=4)?4:(uDelivery&3);
				ASSERT(num_adding>0 && num_adding<=4);
				for(uint32 i=0; i<num_adding; i++)
				{	
					if(bFirstRun)
					{	uAdders[i] = 0; bFirstRun = false; }
					else
					{
						IncCurPageCount(&uCurPageCount, uActHorzPages);
						ASSERT(uCurPageCount!=0 || uPading<=255);
						uAdders[i] = (uCurPageCount==0)?uPading:uAdder;
						(*pVramLoc) += (uCurPageCount==0)?uPading:uAdder;
					}
				}
				staticDma.add32(((((uint32) uAdders[3])<<24)|(((uint32) uAdders[2])<<16)|(((uint32) uAdders[1])<<8)|uAdders[0]));
			}
		
			uVifAddr += (uDelivery*3);
			uPagesLeft -= uDelivery;
		}

		ASSERT(bFirstRun==false);
		
		if(bNeedStitch)
		{
			IncCurPageCount(&uCurPageCount, uActHorzPages);
			ASSERT(uCurPageCount==0);
			ASSERT(uPagesLeft>0);
			staticDma.addUnpack(S_32, uVifAddr, 1, true, true, true);
			staticDma.add32(uPading);
		
			(*pVramLoc) += uPading;
			uVifAddr += 3;
			--uPagesLeft;
		}
	}

	// return page_number % uActHorzPages
	return uCurPageCount;
}



////////// Build Palette upload chain

const void * BuildPaletteUploadChain(const uint32 uVRamPaletteLocation, const uint32 uSrcColors[256])
{
	// swizzle colors
	uint32 uDstColors[256];
	for(int p=0; p<256; p++)
		uDstColors[(p & 231) + ((p&8)<<1) + ((p&16)>>1)] = uSrcColors[p];

	// record location
	const void * pPhysChain = (const void *) staticDma.getPtr();

	const uint32 uQPal = (16*16)/4;

	staticDma.startDirect();
	staticDma.add64(PS2_GIFTAG_SET_TOPHALF(3, 0, 0, 0, PS2_GIFTAG_FLG_PACKED, 1));	// PS2_GIFTAG_SET_TOPHALF(nloop, eop, pre, prim, flg, nreg)
	staticDma.add64(PS2_GIFTAG_REGS_AD);

	staticDma.add64(PS2_GS_SETREG_BITBLTBUF(0, 0, 0, uVRamPaletteLocation*32, 1, 0));
	staticDma.add64(PS2_GS_BITBLTBUF);
	staticDma.add64(PS2_GS_SETREG_TRXREG(16, 16));
	staticDma.add64(PS2_GS_TRXREG);
	staticDma.add64(PS2_GS_SETREG_TRXDIR(0));
	staticDma.add64(PS2_GS_TRXDIR);

	staticDma.add64(PS2_GIFTAG_SET_TOPHALF(uQPal, 0, 0, 0, PS2_GIFTAG_FLG_IMAGE, 0));
	staticDma.add64(0);

	for(int p=0; p<256; p++)
		staticDma.add32(uDstColors[p]);
	
	staticDma.endDirect();


	// terminate and return physical location of chain
	staticDma.ret();
		
	return pPhysChain;
}

