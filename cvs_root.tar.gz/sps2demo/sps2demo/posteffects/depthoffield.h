#ifndef DEPTHOFFIELD_H
#define DEPTHOFFIELD_H

class DepthOfField
{
	public:
					DepthOfField();
					~DepthOfField();
		void		render();

	protected:

		const void	*m_pTessel1;
		const void	*m_pTessel2;
		const void	*m_pPal;
};

#endif /* DEPTHOFFIELD_H */
