#include "crashzoom.h"
#include "posteffecthelper.h"
#include "screen.h"
#include <stdio.h>

void crashzoom(int depth, float scale, float alpha, float cx, float cy, float gain)
{
	Posteffecthelper hlp;
	crashzoom(hlp, screen.getCurrentBuffer() * 150, 300, 10, 640, 480, depth, scale,
			alpha, cx, cy, gain);
}

void crashzoom(Posteffecthelper &hlp, int depth, float scale, float alpha, float cx,
		float cy, float gain)
{
	crashzoom(hlp, screen.getCurrentBuffer() * 150, 300, 10, 640, 480, depth, scale,
			alpha, cx, cy, gain);
}

void crashzoom(int bp, int bp2, int bw, int w, int h, int depth, float scale,
		float alpha, float cx, float cy, float gain)
{
	Posteffecthelper hlp;
	crashzoom(hlp, bp, bp2, bw, w, h, depth, scale, alpha, cx, cy, gain);
}

void crashzoom(Posteffecthelper &hlp, int bp, int bp2, int bw, int w, int h,
		int depth, float scale, float alpha, float cx, float cy, float gain)
{
	int i, a;
	float zoom1, zoom2, alpha1, alpha2, bright1, bright2, realalpha;
	float tmp, factor;
	int tmpbuf;

	hlp.setFrame(bp2, bw);
	hlp.setTex0(bp, bw);

	hlp.blit(0, 0, w, h, false, true);

	zoom1 = zoom2 = alpha1 = alpha2 = bright1 = bright2 = 1;
	if(depth & 1)
	{
		tmpbuf = bp; bp = bp2; bp2 = tmpbuf;
	}
	
	for(i = 0; i < depth; i++)
	{
		zoom2 *= scale;
		alpha2 *= alpha;
		realalpha = alpha2 * bright1 / bright2;
		factor = gain / (1.0f + realalpha);
		realalpha *= factor;
		bright1 *= factor;
		a = (int)(realalpha * 128.0f);
		hlp.setAlpha(1, 2, 2, 0, factor * 128);
		hlp.setRgba(a, a, a, 0);
		hlp.setTex0(bp, bw);
		hlp.setFrame(bp2, bw);
		factor = 1.0f / zoom2;
		hlp.setTexflush();
		hlp.blit(0, 0, w, h, cx - cx*factor + 0.5f, cy - cy*factor + 0.5f,
				cx + (w - cx)*factor + 0.5f, cy + (h - cy)*factor + 0.5f, true);

		tmp = zoom1; zoom1 *= zoom2; zoom2 = tmp;
		tmp = alpha1; alpha1 *= alpha2; alpha2 = tmp;
		tmp = bright1; bright1 = bright2; bright2 = tmp;
		tmpbuf = bp; bp = bp2; bp2 = tmpbuf;
	}
}
