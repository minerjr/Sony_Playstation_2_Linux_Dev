#include "posteffecthelper.h"
#include "../shared/dma.h"
#include "../shared/screen.h"
#include <linux/ps2/dev.h>
#include <stdio.h>

const int Posteffecthelper::regAddress [Posteffecthelper::NUM_REGS] = {
	0x42,
	0x08,
	0x4c,
	0x01,
	0x40,
	0x47,
	0x06,
	0x3f,
	0x18,
	0x14,
};

Posteffecthelper::Posteffecthelper()
{
	dynDma.addFlush();
	setAlpha(0, 1, 0, 1, 0);
	setClamp(0, 0, 0, 0, 0, 0);
	setFrame(screen.getCurrentBuffer() * 150, 10, 0, 0);
	setRgba(128, 128, 128, 128);
	setScissor(0, 0, 639, 479);
	setTest(1, 0, 0, 1, 0, 0, 1, 1);
	setTex0(screen.getCurrentBuffer() * 150, 10, 0, 10, 9, 1, 0);
	setTexflush();
	setFiltering(1);
	setXyoffset(0, 0);
}

Posteffecthelper::~Posteffecthelper()
{
	setAlpha(0, 1, 0, 1, 0);

	flushRegisters();
}

void Posteffecthelper::setAlpha(int a, int b, int c, int d, int fix)
{
	registerChanged[ALPHA] = true;
	registers[ALPHA] = a + (b << 2) + (c << 4) + (d << 6) +
		((u64)fix << 32);
}

void Posteffecthelper::setClamp(int wms, int wmt, int minu, int maxu,
		int minv, int maxv)
{
	registerChanged[CLAMP] = true;
	registers[CLAMP] = wms + (wmt << 2) + (minu << 4) + (maxu << 14) +
		((u64)minv << 24) + ((u64)maxv << 34);
}

void Posteffecthelper::setClamp(int w, int h)
{
	setClamp(2, 2, 0, w-1, 0, h-1);
}

void Posteffecthelper::setFrame()
{
	setFrame(screen.getCurrentBuffer() * 150, 10);
}

void Posteffecthelper::setFrame(int fbp, int fbw, int psm, int fbmsk)
{
	registerChanged[FRAME] = true;
	registers[FRAME] = fbp + (fbw << 16) + (psm << 24) +
		((u64)fbmsk << 32);
}

void Posteffecthelper::setRgba(int r, int g, int b, int a)
{
	registerChanged[RGBAQ] = true;
	registers[RGBAQ] = r + (g << 8) + (b << 16) + ((u64)a << 24) +
		((u64)0x3f800000 << 32);
}

void Posteffecthelper::setScissor(int scax0, int scay0, int scax1,
		int scay1)
{
	registerChanged[SCISSOR] = true;
	registers[SCISSOR] = scax0 + (scax1 << 16) + ((u64)scay0 << 32) +
		((u64)scay1 << 48);
}

void Posteffecthelper::setTest(int ate, int atst, int aref, int afail,
		int date, int datm, int zte, int ztst)
{
	registerChanged[TEST] = true;
	registers[TEST] = ate + (atst << 1) + (aref << 4) + (afail << 12) +
		(date << 14) + (datm << 15) + (zte << 16) + (ztst << 17);
}

void Posteffecthelper::setTex0()
{
	setTex0(screen.getCurrentBuffer() * 150, 10);
}

void Posteffecthelper::setTex0(int tbp0, int tbw, int psm, int tw,
		int th, int tcc, int tfx)
{
	registerChanged[TEX0] = true;
	registers[TEX0] = tbp0*32 + (tbw << 14) + (psm << 20) + (tw << 26) +
		((u64)th << 30) + ((u64)tcc << 34) + ((u64)tfx << 35);
	textureWidth = 1 << tw;
	textureHeight = 1 << th;
}

void Posteffecthelper::setFiltering(int filtering)
{
	registerChanged[TEX1] = true;
	registers[TEX1] = (filtering << 5) + (filtering << 6);
}

void Posteffecthelper::setTexflush()
{
	registerChanged[TEXFLUSH] = true;
}

void Posteffecthelper::setXyoffset(int ofx, int ofy)
{
	registerChanged[XYOFFSET] = true;
	registers[XYOFFSET] = ofx + ((u64)ofy << 32);
}

void Posteffecthelper::flushRegisters()
{
	int i;

	dynDma.startDirect();
	dynDma.startAD();

	for(i = 0; i < NUM_REGS; i++)
		if(registerChanged[i])
		{
			dynDma.addAD(regAddress[i], registers[i]);
			registerChanged[i] = false;
		}

	dynDma.endAD();
	dynDma.endDirect();
}

void Posteffecthelper::blit(int x0, int y0, int x1, int y1, bool alpha,
		bool texture, bool flip)
{
	blit(x0, y0, x1, y1, x0 + 0.5f, y0 + 0.5f, x1 + 0.5f, y1 + 0.5f,
			alpha, texture, flip);
}

void Posteffecthelper::blit(int x0, int y0, int x1, int y1,
		float u0, float v0, float u1, float v1, bool alpha,
		bool texture, bool flip)
{
	float ud, maxu;
	int nstrips, xstep, maxx, i;
	
	if(flip)
	{
		float w, h;
		w = u1 - u0;
		h = v1 - v0;
		u0 = u1 - w / (x1 - x0);
		v0 = v1 - h / (y1 - y0);
		u1 = u0 - w;
		v1 = v0 - h;
	}

	ud = (u0 < u1) ? u1 - u0 : u0 - u1;
	nstrips = (int)(ud + 32) / 32;
	xstep = (x1 - x0 + nstrips - 1) / nstrips;
	ud = (u1 - u0) * xstep / (x1 - x0);
	
	maxx = x1;
	maxu = u1;
	x1 = x0 + xstep;
	u1 = u0 + ud;

	flushRegisters();

	dynDma.startDirect();

	dynDma.add64(PS2_GIFTAG_SET_TOPHALF(nstrips, 1, 1, 6 + (alpha ? 64 : 0) +
				(texture ? 16 : 0), 0, 4));
	dynDma.add64(0x5252);

	for(i = 0; i < nstrips; i++)
	{
		dynDma.addFloat(u0 / textureWidth);
		dynDma.addFloat(v0 / textureHeight); dynDma.add64(0);
		dynDma.add32(x0 * 16); dynDma.add32(y0 * 16); dynDma.add64(0);
		dynDma.addFloat(u1 / textureWidth);
		dynDma.addFloat(v1 / textureHeight); dynDma.add64(0);
		dynDma.add32(x1 * 16); dynDma.add32(y1 * 16); dynDma.add64(0);
		
		x0 = x1; x1 += xstep;
		u0 = u1; u1 += ud;
		if(x1 > maxx)
		{
			x1 = maxx;
			u1 = maxu;
		}
	}

	dynDma.endDirect();
}

void Posteffecthelper::downSample(int x0, int y0, int x1, int y1, bool alpha)
{
	blit(x0, y0, x1, y1, x0*2+1, y0*2+1, x1*2+1, y1*2+1, alpha);
}

void Posteffecthelper::upSample(int x0, int y0, int x1, int y1, bool alpha)
{
	blit(x0, y0, x1, y1, (float)x0/2, (float)y0/2, (float)x1/2, (float)y1/2, alpha);
}

void Posteffecthelper::drawBox(int x0, int y0, int x1, int y1, bool alpha)
{
	flushRegisters();

	dynDma.startDirect();

	dynDma.add64(PS2_GIFTAG_SET_TOPHALF(5, 1, 1, 2 + (alpha ? 64 : 0), 0, 1));
	dynDma.add64(0x5);

	dynDma.add32(x0 * 16); dynDma.add32(y0 * 16); dynDma.add64(0);
	dynDma.add32(x1 * 16); dynDma.add32(y0 * 16); dynDma.add64(0);
	dynDma.add32(x1 * 16); dynDma.add32(y1 * 16); dynDma.add64(0);
	dynDma.add32(x0 * 16); dynDma.add32(y1 * 16); dynDma.add64(0);
	dynDma.add32(x0 * 16); dynDma.add32(y0 * 16); dynDma.add64(0);

	dynDma.endDirect();
}
