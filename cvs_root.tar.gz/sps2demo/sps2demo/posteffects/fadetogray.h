#ifndef FADETOGRAY_H
#define FADETOGRAY_H

class FadeToGray
{
	public:
					FadeToGray();
					~FadeToGray();
		void		render();

	protected:
		
		const void	*m_pZTessel1;
		const void	*m_pZTessel2;
		const void	*m_pZPal;
		const void	*m_pGTessel1;
		const void	*m_pGTessel2;
		const void	*m_pGPal;
};

#endif /* FADETOGRAY_H */
