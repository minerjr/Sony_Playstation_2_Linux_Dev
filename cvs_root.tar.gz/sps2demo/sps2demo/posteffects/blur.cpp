#include "blur.h"
#include "posteffecthelper.h"

void blur(Posteffecthelper &hlp, int bp0, int bp1, int bw, int w,
		int h, int depth, float gain, float clampBlack)
{
	int hw = (bw & 1) ? (bw+1)/2 : bw / 2;
	
	hlp.setClamp(2, 2, 0, w-1, 0, h-1);
	hlp.setFrame(bp0, bw);
	hlp.setTex0(bp0, bw);

	if(clampBlack > 0)
	{
		hlp.setAlpha(2, 1, 2, 1, clampBlack * 128);
		hlp.drawBox(0, 0, w-1, h-1, true);
		hlp.setTexflush();
	}
		
	hlp.setAlpha(1, 0, 2, 0, 32);
	hlp.blit(0, 0, w, h, 1.8333f, 0.5f, w+1.8333f, h+0.5f, true);
	hlp.setTexflush();
	hlp.blit(0, 0, w, h, 0.5f, 1.8333f, w+0.5f, h+1.8333f, true);
	hlp.setTexflush();
	
	hlp.setFrame(bp1, hw);
	hlp.setRgba(gain*128, gain*128, gain*128, 128);
	hlp.blit(0, 0, w/2, h/2, 1, 1, w+1, h+1, false, true, true);
	hlp.setTexflush();
	hlp.setRgba(128, 128, 128, 128);
	
	if(depth > 1)
		blur(hlp, bp1, bp0, hw, w/2, h/2, depth-1, gain, clampBlack);

	hlp.setClamp(2, 2, 0, w/2-1, 0, h/2-1);
	hlp.setFrame(bp1, hw);
	hlp.setTex0(bp1, hw);

	if(clampBlack > 0)
	{
		hlp.setAlpha(2, 1, 2, 1, clampBlack * 128);
		hlp.drawBox(0, 0, w/2-1, h/2-1, true);
		hlp.setAlpha(1, 0, 2, 0, 32);
		hlp.setTexflush();
	}
		
	hlp.blit(0, 0, w/2, h/2, 1.8333f, 0.5f, w/2+1.8333f, h/2+0.5f, true);
	hlp.setTexflush();
	hlp.blit(0, 0, w/2, h/2, 0.5f, 1.8333f, w/2+0.5f, h/2+1.8333f, true);
	hlp.setTexflush();
	
	hlp.setFrame(bp0, bw);
	hlp.setTex0(bp1, hw);
	hlp.setRgba(gain*128, gain*128, gain*128, 128);
	hlp.blit(0, 0, w, h, 0.25f, 0.25f, w/2 + 0.25f, h/2 + 0.25f, false, true, true);
	hlp.setTexflush();
	hlp.setRgba(128, 128, 128, 128);
}

void blur(int bp0, int bp1, int bw, int w, int h, int depth, float gain,
		float clampBlack)
{
	Posteffecthelper hlp;
	
	blur(hlp, bp0, bp1, bw, w, h, depth, gain, clampBlack);
}
