#ifndef __RGBAINDEXER_H__
#define __RGBAINDEXER_H__

#include "exttypes.h"
#include <stdio.h>

// vram pointers are delivered in page numbers [0; 511]
// src colors are delivered in normal linear layout (not swizzled)
const void * BuildPaletteUploadChain(const uint32 uVRamPaletteLocation, const uint32 uSrcColors[256]);
const void * BuildIndexChain(const uint32 uVRamSrc, const uint32 uVRamDst, const uint32 uVRamZbufArg, const uint32 uVRamPaletteLocation, 
									  const int32 x, const int32 y, const int32 dimx, const int32 dimy, const bool bEnableZwrite=false, const uint32 uBufferWidth = 640 );

void UploadIndexChain(const void * pPhysCallChain, const int channel_number, const uint32 uMask,
							 const bool bIsZbuffer, const uint32 uZdepth, const bool bAlphaEnabled=false,
							 const void * pPhysPaletteUploadChain=NULL);


#endif
