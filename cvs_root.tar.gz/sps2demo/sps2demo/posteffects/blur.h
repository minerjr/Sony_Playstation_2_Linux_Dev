#ifndef BLUR_H
#define BLUR_H

class Posteffecthelper;

void blur(Posteffecthelper &hlp, int bp0, int bp1, int bw, int w, int h,
		int depth, float gain = 1.0f, float clampBlack = 0);
void blur(int bp0, int bp1, int bw, int w, int h, int depth,
		float gain = 1.0f, float clampBlack = 0);

#endif /* BLUR_H */
