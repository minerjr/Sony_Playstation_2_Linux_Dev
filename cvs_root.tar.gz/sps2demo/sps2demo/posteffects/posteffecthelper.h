#ifndef POSTEFFECTHELPER_HPP
#define POSTEFFECTHELPER_HPP

#include "../shared/types.h"

class Posteffecthelper
{
public:
	Posteffecthelper();
	~Posteffecthelper();

	void		setAlpha(int a, int b, int c, int d, int fix);
	void		setClamp(int wms, int wmt, int minu, int maxi,
						int minv, int maxv);
	void		setClamp(int w, int h);
	void		setFrame();
	void		setFrame(int fbp, int fbw, int psm = 0, int fbmsk = 0);
	void		setRgba(int r, int g, int b, int a);
	void		setScissor(int scax0, int scay0, int scax1, int scay1);
	void		setTest(int ate, int atst, int aref, int afail,
						int date, int datm, int zte, int ztst);
	void		setTex0();
	void		setTex0(int tbp0, int tbw, int psm = 0, int tw = 10,
						int th = 10, int tcc = 0, int tfx = 0);
	void		setFiltering(int filtering);
	void		setTexflush();
	void		setXyoffset(int ofx, int ofy);
	void		flushRegisters();

	void		blit(int x0, int y0, int x1, int y1, bool alpha = false,
					bool texture = false, bool flip = false);
	void		blit(int x0, int y0, int x1, int y1,
					float u0, float v0, float u1, float v1,
					bool alpha = false, bool texture = true, bool flip = false);
	void		downSample(int x0, int y0, int x1, int y1, bool alpha = false);
	void		upSample(int x0, int y0, int x1, int y1, bool alpha = false);

	void		drawBox(int x0, int y0, int x1, int y1, bool alpha = false);
	
protected:
	enum REGS {
		ALPHA,
		CLAMP,
		FRAME,
		RGBAQ,
		SCISSOR,
		TEST,
		TEX0,
		TEXFLUSH,
		XYOFFSET,
		TEX1,
		NUM_REGS
	};

	static const int regAddress[NUM_REGS];
	u64			registers[NUM_REGS];
	bool		registerChanged[NUM_REGS];
	int			textureWidth, textureHeight;
};

#endif /* POSTEFFECTHELPER_HPP */
