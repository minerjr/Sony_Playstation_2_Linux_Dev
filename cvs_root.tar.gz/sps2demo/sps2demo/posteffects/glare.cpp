#include "glare.h"
#include "posteffecthelper.h"
#include "blur.h"
#include "screen.h"

void glare(float cutoff, int depth, float sourceScale, float gain, float clampBlack)
{
	Posteffecthelper hlp;
	int offset;

	hlp.setFrame(300, 5);
	hlp.downSample(0, 0, 320, 240);
	
	if(cutoff > 0)
	{
		hlp.setAlpha(2, 0, 2, 1, cutoff * 256);
		hlp.blit(0, 0, 320, 240, true);
	}

	blur(hlp, 300, 375, 5, 320, 240, depth, gain, 0.5f);
	
	hlp.setTexflush();
	hlp.setFrame();
	hlp.setTex0(300, 5);
	hlp.setClamp(2, 2, 0, 319, 0, 239);
	if(sourceScale > 0)
		hlp.setAlpha(1, 2, 2, 0, sourceScale * 128);
	else
		hlp.setAlpha(2, 1, 2, 0, -sourceScale * 128);
	offset = (depth & 1) ? (1 << (depth-2)) : -(1 << (depth-2));
	hlp.blit(0, 0, 640, 480, offset, offset, 320+offset, 240+offset, true);
}
