#ifndef GLARE_H
#define GLARE_H

void glare(float cutoff, int depth, float sourceScale, float gain, float clampBlack = 0.5f);

#endif /* GLARE_H */
