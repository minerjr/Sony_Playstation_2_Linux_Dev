#include "sps2.h"
#include "screen.h"
#include "dma.h"
#include "signalhandler.h"
#include "sps2registers.h"
#include <linux/ps2/dev.h>
#include <stdio.h>

bool end = false;

void render()
{
	dynDma.startDirect();
	dynDma.startAD();

	dynDma.addAD(PS2_GS_XYOFFSET_1, PS2_GS_SETREG_XYOFFSET(32768 - 320*16, 32768 - 240*16));
	dynDma.addAD(PS2_GS_SCISSOR_1, PS2_GS_SETREG_SCISSOR(0, 639, 0, 439));
	dynDma.addAD(PS2_GS_FRAME_1, PS2_GS_SETREG_FRAME(screen.getCurrentBuffer() * 150, 10, 0, 0));

	dynDma.addAD(PS2_GS_PRIM, PS2_GS_SETREG_PRIM(6, 0, 0, 0, 0, 0, 0, 0, 0));
	dynDma.addAD(PS2_GS_RGBAQ, PS2_GS_SETREG_RGBAQ(0, 0, 0, 0, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2(32768 - 320*16, 32768 - 240*16, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2(32768 + 320*16, 32768 + 240*16, 0));
	
	dynDma.addAD(PS2_GS_PRIM, PS2_GS_SETREG_PRIM(3, 1, 0, 0, 0, 0, 0, 0, 0));
	dynDma.addAD(PS2_GS_RGBAQ, PS2_GS_SETREG_RGBAQ(255, 0, 0, 0, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2((-128 + 2048) * 16,
				(-128 + 2048) * 16, 100));
	dynDma.addAD(PS2_GS_RGBAQ, PS2_GS_SETREG_RGBAQ(0, 255, 0, 0, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2((128 + 2048) * 16,
				(-128 + 2048) * 16, 100));
	dynDma.addAD(PS2_GS_RGBAQ, PS2_GS_SETREG_RGBAQ(0, 0, 255, 0, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2((0 + 2048) * 16,
				(128 + 2048) * 16, 100));
	dynDma.endAD();
	dynDma.endDirect();
}

int sigHandler(int signal)
{
	if(end)
		return 0;
	end = true;
	return 1;
}

int main()
{
	sps2.open();
	sps2.alloc(32);
	dynDma.init(8);
	staticDma.init(16);
	screen.open();
	signalHandler.registerHandler(sigHandler);
	
	while(!end)
	{
		render();
		
		sps2.waitForDma(1);
		while((*EE_VIF1_STAT & (3 | 8 | (31 << 24))));
		while((*EE_GIF_STAT & (0xfc0 | (31 << 24))));
		
		screen.vblankWait();
		screen.flipBuffers();
		
		dynDma.send();
	}

	printf("finished!\n");
	
	return 0;
}
