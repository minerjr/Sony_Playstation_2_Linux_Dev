#ifndef SPS2_H
#define SPS2_H

#include "types.h"

class Mem;

class Sps2
{
public:
	Sps2();
	~Sps2();
	void open();
	void close();
	void alloc(int numPages);
	int flushCache();
	int waitForDma(int channel);
	void getMem(Mem *mem, int qwords);
	void *allocLinearMem(int qwords);
	void *phys2virt(u32 ptr);
	u32 virt2phys(void *ptr);
protected:
	static int sigHandler(int signal);
	int sps2fd;
	int numPages;
	void *memory;
	int *pageFree;
};

extern Sps2 sps2;

class Mem
{
public:
	Mem() { cached = NULL; uncached = NULL; physical = 0; size = 0; }
	Mem(int qwords) { sps2.getMem(this, qwords); }
	~Mem();
	void setAddress(void *c, void *uc, int p, int s)
		{ cached = c; uncached = uc; physical = p; size = s; }
	void *getCached() { return cached; }
	void *getUncached() { return cached; }
	int getPhysical() { return physical; }
protected:
	void *cached;
	void *uncached;
	u32 physical;
	int size;
};

#endif /* SPS2_H */
