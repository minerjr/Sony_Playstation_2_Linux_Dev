#ifndef VUCODE_H
#define VUCODE_H

#include "types.h"

class VuManager;

class VuCode
{
	friend VuManager;
public:
	VuCode(u64 *code, int _offset);
	~VuCode();
	bool isCurrentCode() { return currentCode == codeptr; }
	void send();
protected:
	u32 ptr;
	u64 *codeptr;
	int offset;
	VuCode *next;
	static u64 *currentCode;
};

class VuManager
{
public:
	VuManager();
	~VuManager();
	VuCode *createVuCode(u64 *code, int offset = 0);
protected:
	VuCode *vuCodeList;
};

extern VuManager vumanager;

#endif /* VUCODE_H */
