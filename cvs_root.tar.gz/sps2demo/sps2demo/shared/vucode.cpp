#include "vucode.h"
#include "dma.h"
#include <stdio.h>

u64 *VuCode::currentCode = NULL;

VuCode::VuCode(u64 *code, int _offset)
{
	int len = ((u32*)code)[-4];
	int i;
	printf("vucode size: %d\n", len);
	codeptr = code;
	offset = _offset;
	StaticDma &dma = staticDma;
	ptr = dma.getPtr();
	dma.addOffset(_offset);
	dma.startMPG(0);
	for(i = 0; i < (len >> 3); i++)
		dma.addMPG(*code++);
	dma.endMPG();
	dma.ret();
}

VuCode::~VuCode()
{
}

void VuCode::send()
{
	DynDma &dma = dynDma;
	dma.addFlushe();
	dma.addBase(0);
	dma.call(ptr);
}

VuManager vumanager;

VuManager::VuManager()
{
	vuCodeList = (VuCode*)0;
}

VuManager::~VuManager()
{
	VuCode *ptr, *next = 0;
	if(vuCodeList != NULL)
	{
		ptr = vuCodeList;
		while(ptr != NULL)
		{
			next = ptr->next;
			delete ptr;
			ptr = next;
		}
	}
}

VuCode *VuManager::createVuCode(u64 *code, int offset)
{
	VuCode *ptr = vuCodeList;
	while(ptr != NULL)
		if(ptr->codeptr == code && ptr->offset == offset)
			return ptr;
		else
			ptr = ptr->next;
	ptr = new VuCode(code, offset);
	ptr->next = vuCodeList;
	vuCodeList = ptr;
	return ptr;
}
