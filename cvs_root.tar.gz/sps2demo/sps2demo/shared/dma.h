#ifndef DMA_H
#define DMA_H

#include "types.h"

class Vector;
class Matrix;

typedef enum {
	S_32 = 0, S_16 = 1, S_8 = 2,
	V2_32 = 4, V2_16 = 5, V2_8 = 6,
	V3_32 = 8, V3_16 = 9, V3_8 = 10,
	V4_32 = 12, V4_16 = 13, V4_8 = 14,
	V4_5 = 15} VUP_FORMAT;

class RefData
{
	friend class StaticDma;
	
public:
	RefData();
	~RefData();

	void			addToChain(class DmaMem &dma, u64 tte);
protected:
	void			addPage(u32 ptr, u32 qwc, u64 tte);
	
	struct PageList
	{
		PageList	*pNext;
		u32			ptr;
		u32			qwc;
		u64			tte;
	}				*m_pPages;
};

class DmaMem
{
public:
	void open();
	void add32(u32 v)
	{
		if(ptr >= endPtr)
			nextPage();
		*ptr++ = v;
	}
	void add64(u64 v) { add32((u32)v); add32((u32)(v >> 32)); }
	void add128(u128 v) { add64((u64)v); add64((u64)(v >> 64)); }
	void addFloat(float v) { add32(*(u32*)&v); }
	void addFloatByte(float f, u8 b) {
		u32 tmp = *(u32*)&f;
		*(u8*)&tmp = b;
		add32(tmp); }
	void addVector(const Vector &vec);
	void addVector3(const Vector &vec);
	void addMatrix(const Matrix &mat);
	void prepareForDmaTag();
	void end();
	void ret();
	void call(u32 ptr);
	void ref(u32 ptr, u32 size, u64 tte = 0);
	void ref(RefData *refData, u64 tte = 0) { refData->addToChain(*this, tte); }
	void startDirect();
	void endDirect();
	void startAD();
	void endAD();
	void addAD(int addr, u64 data) { add64(data); add64(addr); (*ADgifTag)++; }
	void startMPG(int addr);
	void endMPG();
	void addMPG(u64 data);
	void addOffset(int offset) { add32((0x2 << 24) + offset); }
	void addFlushe() { add32(0x10 << 24); }
	void addFlush() { add32(0x11 << 24); }
	void addFlusha() { add32(0x13 << 24); }
	void addBase(int num) { add32((3 << 24) + num); }
	void addMscalf(int addr) { add32((0x15 << 24) + addr); }
	void addMscnt() { add32(0x17 << 24); }
	void addMscal(int addr) { add32((0x14 << 24) + addr); }
	void addItop(int num) { add32((4 << 24) + num); }
	void addStcycl(int cl, int wl) { add32((1 << 24) + cl + (wl << 8)); }
	void addUnpack(VUP_FORMAT format, int addr, int num, int usetops = 0,
			int nosign = 1, int masking = 0)
		{
			add32((0x60 << 24) + (format << 24) + (masking << 28) + (usetops << 15) +
				(nosign << 14) + (num << 16) + addr);
		}
	void stmod(const int mode) { add32((0x5<<24) | (mode&0x3)); }
	void stmask(const unsigned int mask) { add32(0x20<<24); add32(mask); }
	void strow()	{ add32(0x30<<24); }
	void stcol()	{ add32(0x31<<24); }
protected:
	typedef enum { VIF_BASE, VIF_DIRECT } vifState_t;
	void close();
	void align(int align, int offset = 0);
	void nextPage();
	void newTag();
	virtual u32 getNewPage() = 0;
	u32 physPtr;
	u32 *ptr;
	u32 *endPtr;
	vifState_t vifState;
	u64 *dmaTag;
	u32 *vifTag;
	u32 *ADgifTag;
	int mpgCount;
	int mpgAddr;
};

class Mem;

class DynDma : public DmaMem
{
public:
	DynDma();
	virtual ~DynDma();
	void init(int numPages);
	void send(int disas = 0);
	Mem &getTempPage();
protected:
	virtual u32 getNewPage();
	Mem *pageList;
	int numPages;
	int currentPage;
	int currentBuffer;
};

extern DynDma dynDma;

class StaticDma : public DmaMem
{
public:
				StaticDma();
	virtual		~StaticDma();
	void		init(int numPages);
	u32			getPtr();
	RefData		*startRefData();
	void		endRefData();
protected:
	virtual u32	getNewPage();
	void		addRefPage();
	int			physOffset;
	Mem			*pageList;
	int			numPages;
	int			currentPage;
	RefData		*m_pRefData;
};

extern StaticDma staticDma;

#endif /* DMA_H */
