#ifndef REGDEFINES_H
#define REGDEFINES_H

#include "types.h"

#define ALPHA_1 	0x42
#define ALPHA_2		0x43
#define TEST_1		0x47
#define TEST_2		0x48
#define TEXA		0x3b
#define BITBLTBUF	0x50
#define CLAMP_1		0x08
#define CLAMP_2		0x09
#define COLCLAMP	0x46
#define FBA_1		0x4a
#define FBA_2		0x4b
#define FOGCOL		0x3d
#define FRAME_1		0x4c
#define FRAME_2		0x4d
#define TEX0_1		0x06
#define TEX0_2		0x07
#define TEX1_1		0x14
#define TEX1_2		0x15
#define TEX2_1		0x16
#define TEX2_2		0x17
#define TEXCLUT		0x1c
#define TRXDIR		0x53
#define TRXPOS		0x51
#define TRXREG		0x52
#define MIPTBP1_1	0x34
#define MIPTBP1_2	0x35
#define MIPTBP2_1	0x36
#define MIPTBP2_2	0x37
#define SCISSOR_1	0x40
#define SCISSOR_2	0x41
#define XYOFFSET_1	0x18
#define XYOFFSET_2	0x19
#define RGBAQ		0x01
#define ST			0x02
#define UV			0x03
#define XYZ2		0x05
#define XYZ3		0x0d
#define XYZF2		0x04
#define XYZF3		0x0c
#define PABE		0x49
#define PRIM		0x00
#define PRMODECONT	0x1a
#define PRMODE		0x1b
#define LABEL		0x62
#define SIGNAL		0x60
#define ZBUF_1		0x4e
#define ZBUF_2		0x4f
#define HWREG		0x54
#define SCANMSK		0x22
#define DTHE		0x45
#define DIMX		0x44
#define FINISH		0x61
#define TEXFLUSH	0x3f


#define ALPHA_SET(A, B, C, D, FIX) ((A) | ((B) << 2) | ((C) << 4) | \
	((D) << 6) | ((u64)(FIX) << 32))

#define TEST_SET(ATE, ATST, AREF, AFAIL, DATE, DATM, ZTE, ZTST) ((ATE) | \
	((ATST) << 1) | ((AREF) << 4) | ((AFAIL) << 12) | ((DATE) << 14) | \
	((DATM) << 15) | ((ZTE) << 16) | ((ZTST) << 17))

#define TEXA_SET(TA0, AEM, TA1) ((TA0) | ((AEM) << 15) | ((u64)(TA1) << 32))

#define BITBLTBUF_SET(SBP, SBW, SPSM, DBP, DBW, DPSM) ((SBP) | \
	((SBW) << 16) | ((SPSM) << 24) | ((u64)(DBP) << 32) | \
	((u64)(DBW) << 48) | ((u64)(DPSM) << 56))

#define CLAMP_SET(WMS, WMT, MINU, MAXU, MINV, MAXV) ((WMS) | \
	((WMT) << 2) | ((MINU) << 4) | ((MAXU) << 14) | ((u64)(MINV) << 24) | \
	((u64)(MAXV) << 34))

#define FOGCOL_SET(FCR, FCG, FCB) ((FCR) | ((FCG) << 8) | ((FCB) << 16))

#define FRAME_SET(FBP, FBW, PSM, FBMSK) ((FBP) | ((FBW) << 16) | \
	((PSM) << 24) | ((u64)(FBMSK) << 32))

#define TEX0_SET(TBP0, TBW, PSM, TW, TH, TCC, TFX, CBP, CPSM, CSM, CSA, CLD) \
	((TBP0) | ((TBW) << 14) | ((PSM) << 20) | ((TW) << 26) | ((u64)(TH) << 30) | \
	((u64)(TCC) << 34) | ((u64)(TFX) << 35) | ((u64)(CBP) << 37) | \
	((u64)(CPSM) << 51) | ((u64)(CSM) << 55) | ((u64)(CSA) << 56) | \
	((u64)(CLD) << 61))

#define TEX1_SET(LCM, MXL, MMAG, MMIN, MTBA, L, K) ((LCM) | ((MXL) << 2) | \
	((MMAG) << 5) | ((MMIN) << 6) | ((MTBA) << 9) | ((L) << 19) | \
	((u64)(K) << 32))

#define TEX2_SET(PSM, CBP, CPSM, CSM, CSA, CLD) (((PSM) << 20) | \
	((u64)(CBP) << 37) | ((u64)(CPSM) << 51) | ((u64)(CSM) << 55) | \
	((u64)(CSA) << 56) | ((u64)(CLD) << 61))

#define TEXCLUT_SET(CBW, COU, COV) ((CBW) | ((COU) << 6) | ((COV) << 12))

#define TRXPOS_SET(SSAX, SSAY, DSAX, DSAY, DIR) ((SSAX) | ((SSAZ) << 16) | \
	((u64)(DSAX) << 32) | ((u64)(DSAY) << 48) | ((u64)(DIR) << 59))

#define TRXREG_SET(RRW, RRH) ((RRW) | ((u64)(RRH) << 32))
	
#define MIPTBP1_SET(TBP1, TBW1, TBP2, TBW2, TBP3, TBW3) ((TBP1) | \
	((TBW1) << 14) | ((u64)(TBP2) << 20) | ((u64)(TBW2) << 34) | \
	((u64)(TBP3) << 40) | ((u64)(TBW3) << 54))
#define MIPTBP2_SET(TBP4, TBW4, TBP5, TBW5, TBP6, TBW6)	\
	MIPTBP1_SET(TBP4, TBW4, TBP5, TBW5, TBP6, TBW6)

#define SCISSOR_SET(SCAX0, SCAX1, SCAY0, SCAY1) ((SCAX0) | \
	((SCAX1) << 16) ((u64)(SCAY0) << 32) | ((u64)(SCAY1) << 48))

#define XYOFFSET_SET(OFX, OFY) ((OFX) | ((u64)(OFY) << 32))

#define RGBAQ_SET(R,G,B,A,Q) ((R) | ((G) << 8) | ((B) << 16) | ((A) << 24) | \
	((u64)(Q) << 32))

#define ST_SET(S,T) ((S) | ((u64)(T) << 32))

#define UV_SET(U,V) ((U) | ((V) << 16))

#define XYZ2_SET(X, Y, Z) ((X) | ((Y) << 16) | ((u64)Z << 32))

#define XYZ3_SET(X, Y, Z) XYZ2_SET(X,Y,Z)

#define XYZF2_SET(X, Y, Z, F) ((X) | ((Y) << 16) | ((u64)(Z) << 32) | \
	((u64)(F) << 56))

#define XYZF3_SET(X, Y, Z, F) XYZF2_SET(X,Y,Z,F)

#define PRMODE_SET(IIP, TME, FGE, ABE, AA1, FST, CTXT, FIX) \
	(((IIP) << 3) | ((TME) << 4) | ((FGE) << 5) | ((ABE) << 6) | \
	((AA1) << 7) | ((FST) << 8) | ((CTXT) << 9) | ((FIX) << 10))

#define PRIM_SET(PRIM, IIP, TME, FGE, ABE, AA1, FST, CTXT, FIX) \
	(PRMODE_SET(IIP, TME, FGE, ABE, AA1, FST, CTXT, FIX)|PRIM)

#define LABEL_SET(ID, IDMSK) ((ID) | ((u64)(IDMSK) << 32))

#define SIGNAL_SET(ID, IDMSK) ((ID) | ((u64)(IDMSK) << 32))

#define ZBUF_SET(ZBP, PSM, ZMSK) ((ZBP) | ((PSM) << 24) | \
	((u64)(ZMSK) << 32))

#define DIMX_SET(DM00, DM01, DM02, DM03, DM10, DM11, DM12, DM13, DM20, DM21, DM22, DM23, DM30, DM31, DM32, DM33) \
	(((DM00) & 7) | (((DM01) & 7) << 4) | (((DM02) & 7) << 8) | (((DM03) & 7) << 12) | \
	(((DM10) & 7) << 16) | (((DM11) & 7) << 20) | (((DM12) & 7) << 24) | (((DM13) & 7) << 28) | \
	(((u64)(DM20) & 7) << 32) | (((u64)(DM21) & 7) << 36) | (((u64)(DM22) & 7) << 40) | (((u64)(DM23) & 7) << 44) | \
	(((u64)(DM30) & 7) << 48) | (((u64)(DM31) & 7) << 52) | (((u64)(DM32) & 7) << 56) | (((u64)(DM33) & 7) << 60))


#endif /* REGDEFINES_H */
