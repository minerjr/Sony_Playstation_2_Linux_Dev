#!/usr/bin/env python
import sys
import re

re_include = re.compile(' *# *include *"(.*)"', re.I)
re_ifdef = re.compile(' *# *ifndef| *# *else| *# *endif', re.I)
re_define = re.compile(r' *# *define ([a-zA-Z_]+)(.*)', re.I)

def directives(line):
	global defines, defines_dict
	file = re_include.match(line)
	if file != None:
		process(file.group(1))
		return ""
	if re_ifdef.match(line) != None:
		return ""
	define = re_define.match(line)
	if define != None:
		value = re.match(r'\s*(.*)\s*$', define.group(2))
		defines_dict[define.group(1)] = value.group(1)
		defines.insert(0, [re.compile('([^a-zA-Z_])'+define.group(1)+'(?=[^a-zA-Z_])'), r'\g<1>' + value.group(1)])
		return ""
	return line

def replace_defines(line):
	for define in defines:
		line = define[0].sub(define[1], line)
	return line

def replace_decimal(match):
	num = match.group(0)
	leading = num[0]
	num = num[1:]
	tzeros = re.match('0\.(0+)[1-9]', num)
	if tzeros == None:
		return leading + num
	num = re.sub('0\.0+(?=[1-9])', '', num)[2:] + 'E-' + repr(len(tzeros.group(1)))
	return leading + num

re_hex = re.compile('0x(?=[a-fA-F0-9])')
re_dec = re.compile('\D0\.0[0-9]+(?![eE])')
	
def process(file):
	f = open(file)
	while 1:
		line = f.readline()
		if line == "":
			break
		line = directives(line)
		line = replace_defines(line)
		line = re_hex.sub("H'", line)
		line = re_dec.sub(replace_decimal, line)
		print line,
	f.close()

if len(sys.argv) != 2:
	print "Usage: pp.py <input>"
	sys.exit(1)

defines = []
defines_dict = {}
process(sys.argv[1])
