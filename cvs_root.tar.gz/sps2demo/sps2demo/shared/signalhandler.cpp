#include <signal.h>
#include "signalhandler.h"
#include <stdio.h>

SignalHandler signalHandler;

SignalHandler::SignalHandler()
{
	int i;
	for(i = 0; i < 32; ++i)
		handlers[i] = (sigHandler*)NULL;
}

void SignalHandler::registerHandler(int (*handler)(int signal), int signal = 0)
{
	if(signal > 0)
		regHandler(handler, signal);
	else
	{
		unsigned int i;
		const int defaultSignals[] = {
			1, 2, 3, 4, 6, 8, 11, 13, 15, 17, 19, 23, 18, 20, 24, 10, 5, 7, 16};
		for(i = 0; i < sizeof(defaultSignals)/sizeof(int); i++)
			regHandler(handler, defaultSignals[i]);
	}
}

void SignalHandler::unregisterHandler(int (*handler)(int signal), int signal = 0)
{
	if(signal > 0)
		unregHandler(handler, signal);
	else
	{
		unsigned int i;
		const int defaultSignals[] = {
			1, 2, 3, 4, 6, 8, 11, 13, 15, 17, 19, 23, 18, 20, 24, 10, 5, 7, 16};
		for(i = 0; i < sizeof(defaultSignals)/sizeof(int); i++)
			unregHandler(handler, defaultSignals[i]);
	}
}

void SignalHandler::g_signalHandler(int sig)
{
	signalHandler.doHandling(sig);
}

void SignalHandler::doHandling(int sig)
{
	sigHandler *handler = handlers[sig];
	sigHandler **prevNext = &handlers[sig];
	int handled = 0;
	printf("got signal %d\n", sig);
	while(handled == 0 && handler != NULL)
	{
		handled = handler->handler(sig);
		if(handled == 0)
		{
			sigHandler *temp = handler;
			*prevNext = temp->next;
			handler = handler->next;
			delete temp;
		}
		else
		{
			prevNext = &handler->next;
			handler = handler->next;
		}
	}
	if(handled)
		return;
	signal(sig, SIG_DFL);
	raise(sig);
}

void SignalHandler::regHandler(int (*handler)(int signal), int sig)
{
	if(handlers[sig] == NULL)
		signal(sig,  g_signalHandler);
	sigHandler *newHandler = new sigHandler(handler);
	newHandler->next = handlers[sig];
	handlers[sig] = newHandler;
}

void SignalHandler::unregHandler(int (*handl)(int signal), int sig)
{
	sigHandler *handler = handlers[sig];
	sigHandler **prevNext = &handlers[sig];
	while(handler != NULL)
	{
		if(handler->handler == handl)
		{
			sigHandler *temp = handler;
			*prevNext = temp->next;
			handler = handler->next;
			delete temp;
		}
		else
		{
			prevNext = &handler->next;
			handler = handler->next;
		}
	}
}
