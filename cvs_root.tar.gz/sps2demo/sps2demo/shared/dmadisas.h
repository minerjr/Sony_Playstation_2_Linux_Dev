#ifndef DMADISASM_H
#define DMADISASM_H

#include "types.h"

class DmaDisas
{
public:
	DmaDisas();
	~DmaDisas();
	void start(u32 ptr);
protected:
	void disdma(u32 ptr);
	void disdata(u32 *ptr, int num);
	void disvif(u32 data);
	void disgif(u32 data);
	void disad(int reg, u64 data);
	u32 readWord(u32 ptr);
	enum VIFSTATE { VS_READTAG, VS_DIRECT, VS_MPG, VS_UNPACK };
	VIFSTATE vifstate;
	enum GIFSTATE { GS_READTAG, GS_PACKED, GS_IMAGE };
	GIFSTATE gifstate;
	int gifqcount;
	int gifcount;
	u128 giftag;
	u128 gifqword;
	int nreg;
	int vifcount;
	int timeout;
};

#endif /* DMADISASM_H */
