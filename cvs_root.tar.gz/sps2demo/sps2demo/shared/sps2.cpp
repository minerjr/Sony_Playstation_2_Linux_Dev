#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <sys/mman.h>
#include "sps2.h"
#include "debug.h"
#include "signalhandler.h"
#include "sps2lib.h"

Sps2 sps2;

Sps2::Sps2()
{
	memory = NULL;
	numPages = 0;
	pageFree = NULL;
	sps2fd = -1;
}

void Sps2::open()
{
	signalHandler.registerHandler(sigHandler);
	sps2fd = sps2Init();
	ASSERT(sps2fd >= 0);
	if(*EE_D1_CHCR & 256)
	{
		printf("DMA 1 is still running, that is not good...\n");
		exit(1);
	}
//	*EE_VIF1_FBRST = 1;			// reset vif1 // harmful?
}

Sps2::~Sps2()
{
	close();
}

void Sps2::close()
{
	if(sps2fd < 0)
		return;
	if(*EE_D1_CHCR & 256)
	{
		printf("DMA 1 has not finished yet.\nWaiting one second before continuing.\n");
		sleep(1);
		printf("vifcode: %08x\n", *EE_VIF1_CODE);
		printf("vifnum: %d\n", *EE_VIF1_NUM);
		printf("vifstat: %08x\n", *EE_VIF1_STAT);
		printf("viferr: %x\n", *EE_VIF1_ERR);
	}
	if(*EE_D1_CHCR & 256)
	{
		*EE_D_ENABLEW = 1 << 16;
		*EE_D1_CHCR = 0;
		*EE_D_ENABLEW = 0;
	}
	if(memory != NULL)
		sps2Free((sps2Memory_t*)memory);
	if(pageFree != NULL)
		delete[] pageFree;
	if(sps2fd >= 0)
		sps2Release(sps2fd);
}

int Sps2::sigHandler(int signal)
{
	sps2.close();
	return 0;
}

void Sps2::alloc(int _numPages)
{
	numPages = _numPages;
	memory = sps2Allocate(numPages * 4096, SPS2_MAP_BLOCK_4K | SPS2_MAP_CACHED, sps2fd);
	ASSERT(memory != NULL);
	pageFree = new int[numPages];
	ASSERT(pageFree != NULL);
	for(int i = 0; i < numPages; i++)
		pageFree[i] = 256;
}

int Sps2::flushCache()
{
	return sps2FlushCache(sps2fd);
}

int Sps2::waitForDma(int channel)
{
	return sps2WaitForDMA(channel, sps2fd);
}

void Sps2::getMem(Mem *pmem, int qwords)
{
	int i, offset;
	void *virtptr;
	sps2Memory_t *mem = (sps2Memory_t*)memory;
	ASSERT(mem != NULL);
	for(i = 0; i < numPages; i++)
	{
		if(pageFree[i] >= qwords)
		{
			offset = (256 - pageFree[i]) * 16;
			pageFree[i] -= qwords;
			virtptr = (void*)((int)mem->pvStart + i * 4096 + offset);
			pmem->setAddress(virtptr,
						NULL, sps2GetPhysicalAddress(virtptr, mem), qwords);
			return;
		}
	}
	ASSERT(!"Sps2: out of memory");
}

void *Sps2::allocLinearMem(int qwords)
{
	int i, start, qwc;
	sps2Memory_t *mem = (sps2Memory_t*)memory;
	ASSERT(mem != NULL);
	start = 0;
	qwc = 0;
	for(i = 0; i < numPages; i++)
	{
		if(pageFree[i] != 256)
		{
			start = i;
			qwc = pageFree[i];
		}
		else
			qwc += pageFree[i];
		
		if(qwc >= qwords)
		{
			void *result = (void*)((int)mem->pvStart + start * 4096 + 4096 - pageFree[start] * 16);
			for(i = start; qwords > 0; i++)
				if(pageFree[i] < qwords)
				{
					qwords -= pageFree[i];
					pageFree[i] = 0;
				}
				else
				{
					pageFree[i] -= qwords;
					qwords = 0;
				}
			return result;
		}
	}
	ASSERT(!"Not enough linear memory available");
	return NULL;
}

void *Sps2::phys2virt(u32 ptr)
{
	int i;
	sps2Memory_t *mem = (sps2Memory_t*)memory;
	ASSERT(mem != NULL);
	for(i = 0; i < numPages; i++)
		if((ptr & 0x7ffff000) == sps2GetPhysicalAddress((void*)((int)mem->pvStart +
						i * 4096), mem))
			return (void*)((int)mem->pvStart + i * 4096 + (ptr & 0xfff));
	ASSERT(!"Didn't find page\n");
	return NULL;
}

u32 Sps2::virt2phys(void *ptr)
{
	sps2Memory_t *mem = (sps2Memory_t*)memory;
	ASSERT(mem != NULL);
	return sps2GetPhysicalAddress(ptr, mem);
}

Mem::~Mem()
{
	// TODO return memory
}
