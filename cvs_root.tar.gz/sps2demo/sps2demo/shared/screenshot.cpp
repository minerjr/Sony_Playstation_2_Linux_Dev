#include "screenshot.h"
#include "screen.h"
#include "sps2.h"
#include "dma.h"
#include "debug.h"
#include "sps2registers.h"
#include <linux/ps2/dev.h>
#include <stdio.h>
#include <sys/ioctl.h>

int screenshot_number = 0;

void screenshot()
{
	Mem &page = dynDma.getTempPage();
	char name[256];
	unsigned char *data;
	unsigned char tmp;
	
	sprintf(name, "../screenshots/test_%02d.tga", screenshot_number++);
	
	FILE *f = fopen(name, "wb");

	// write a constant targa header for a 640x480, 32bit picture
	unsigned char header[18] = {
		0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x80, 2, 0xe0, 1, 32, 8
	};
	fwrite(header, 18, 1, f);

	for(int y = 0; y < 480; y++)
	{
		downloadVram(page.getCached(), page.getPhysical(), 0, 10, 0, 479 - y, 640, 1);

		// convert RGBA to BGRA
		data = (unsigned char *)page.getCached();
		for(int x = 0; x < 640; x++)
		{
			tmp = data[0];
			data[0] = data[2];
			data[2] = tmp;
			data += 4;
		}

		fwrite(page.getCached(), 4, 640, f);
	}
	fclose(f);
}

void downloadVram(void *virtPage, int physPage, int addr, int bufw, int x, int y, int w, int h)
{
	u32 * pDmaMem = (u32*)virtPage;//<-- point to sps2 allocated unswapable memory.

	u32 uSrcPtr = addr;
	u32 uQSize = (w*h*4)/16; // assuming 24/32bit framebuffer

	// Setup transfer texture back to memory
	pDmaMem[0] = 0; //NOP;
	pDmaMem[1] = 0x06008000; //MSKPATH3(0x8000);
	pDmaMem[2] = 0x13000000; //FLUSHA;
	pDmaMem[3] = 0x50000006; //DIRECT(6);

	void * pPhysDmaMem = (void*)physPage;

	// Add GifTag Data
	u64 *pDmaMem64 = (u64 *) (pDmaMem + 4);
	pDmaMem64[0] = (PS2_GIFTAG_SET_TOPHALF(5, 1, 0, 0, 0, 1)); // GIFTAG(NLOOP, EOP, PRE, PRIM, FLG, NREG)
	pDmaMem64[1] = (0xe);

	pDmaMem64[2] = (PS2_GS_SETREG_BITBLTBUF( uSrcPtr, bufw, 0, 0, 0, 0 ));
	pDmaMem64[3] = (PS2_GS_BITBLTBUF);

	pDmaMem64[4] = (PS2_GS_SETREG_TRXPOS(x, y, 0, 0, 0)); // SSAX, SSAY, DSAX, DSAY, DIR
	pDmaMem64[5] = (PS2_GS_TRXPOS);

	pDmaMem64[6] = (PS2_GS_SETREG_TRXREG(w, h)); // RRW, RRh
	pDmaMem64[7] = (PS2_GS_TRXREG);

	pDmaMem64[8] = (0);
	pDmaMem64[9] = (PS2_GS_FINISH);

	pDmaMem64[10] = (PS2_GS_SETREG_TRXDIR(1)); // XDIR
	pDmaMem64[11] = (PS2_GS_TRXDIR);

	u32 prev_chcr = *EE_D1_CHCR;

	// vif1 must be available
	if ((*EE_D1_CHCR & 0x0100) != 0)
	{
		ASSERT("Blah");
	}	
	
	// set the FINISH event
	ioctl(screen.getEventFd(), PS2IOC_ENABLEEVENT, PS2EV_FINISH);
	ioctl(screen.getEventFd(), PS2IOC_GETEVENT, PS2EV_FINISH);

	// DMA from memory and start DMA transfer
	sps2.flushCache();

	*EE_D1_QWC = 0x7;
	*EE_D1_MADR = ( unsigned int ) pPhysDmaMem & 0x0FFFFFFF ;
	*EE_D1_CHCR = (1<<0) | (0<<2) | (0<<4) | (0<<6) | (0<<7) | (1<<8);

	asm __volatile__( " sync.l " );
	// check if DMA is complete (STR=0)
	while ( *EE_D1_CHCR & 0x0100 );

	ioctl(screen.getEventFd(), PS2IOC_WAITEVENT, PS2EV_FINISH);
	
	// wait for VIF1-FIFO to empty and become idle
	while ( *EE_VIF1_STAT & 0x1f000003 );
	//((tVIF1_STAT*)VIF1_STAT)->FDR = 1;
	*EE_VIF1_STAT = (1<<23);
	DPUT_GS_BUSDIR( ( u64 ) 0x00000001 );
	sps2.flushCache();
	*EE_D1_QWC = uQSize;
	*EE_D1_MADR = ( u32 ) physPage & 0x0FFFFFFF ;
	*EE_D1_CHCR = 0 | (0<<2) | (0<<4) | (0<<6) | (0<<7) | (1<<8);

	asm __volatile__( " sync.l " );

	// check if DMA is complete (STR=0)
	while ( *EE_D1_CHCR & 0x0100 );
	*EE_D1_CHCR = prev_chcr;
	asm __volatile__( " sync.l " );

	// wait for VIF1-FIFO to empty and become idle
	while ( *EE_VIF1_STAT & 0x1f000003 );
	//((tVIF1_STAT*)VIF1_STAT)->FDR = 0;
	*EE_VIF1_STAT = 0;
	DPUT_GS_BUSDIR( ( u64 ) 0 );

	static u32 enable_path3[4] QALIGN = {
	0x06000000, //MSKPATH3(0),
	0,
	0,
	0};

	DPUT_EE_VIF1_FIFO( *( u128 * ) enable_path3 );

	// back to the VBSTART event
	ioctl(screen.getEventFd(), PS2IOC_ENABLEEVENT, PS2EV_VBSTART);
}
