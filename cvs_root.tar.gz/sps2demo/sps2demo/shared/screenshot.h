#ifndef SCREENSHOT_H
#define SCREENSHOT_H

void screenshot();
void downloadVram(void *virtPage, int physPage, int addr, int bufw, int x, int y, int w, int h);

#endif /* SCREENSHOT_H */
