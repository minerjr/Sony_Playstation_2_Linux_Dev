#ifndef FRAMEWORK_H
#define FRAMEWORK_H

#include "types.h"

class PadState
{
	friend class Framework;
public:
	PadState() {
		cnt = ~0; trg = 0; sticks[0] = sticks[1] = sticks[2] = sticks[3] = 0.0f; }
	u32 getCnt() const { return cnt; }
	u32 getTrg() const { return trg; }
	bool isPressed(u32 mask) const { return (cnt & mask); }
	bool isTriggered(u32 mask) const { return (trg & mask); }
	float getLeftX() const { return sticks[0]; }
	float getLeftY() const { return sticks[1]; }
	float getRightX() const { return sticks[2]; }
	float getRightY() const { return sticks[3]; }
protected:
	u32 cnt;
	u32 trg;
	float sticks[4];
};

class Framework
{
public:
					Framework();
					~Framework();
	void			init(int staticPages, int dynPages, int customPages = 0);
	void			mainloop(void (*callback)());
	void			exit() { m_end = true; }
	int				getNumPads() const { return m_numpads; }
	const PadState 	&getPad(int num) const { return m_pad[num]; }
	float			getTime() const { return m_time; }
	float			getTimestep() const { return m_timestep; }
	void			setDmaDisas(int flags) { m_dmaDisas = flags; }
protected:
	enum {MAXPADS = 2};
	void			updatePads();
	static int		sigHandler(int signal);
	static volatile bool m_end;
	float			m_time;
	float			m_timestep;
	int				m_numpads;
	PadState		m_pad[MAXPADS];
	u32				m_noplist;
	bool			m_rastertime;
	int				m_dmaDisas;
};

extern Framework framework;

#endif /* FRAMEWORK_H */
