#include <linux/ps2/dev.h>
#include "dma.h"
#include "screen.h"
#include "vucamera.h"
#include "camera.h"
#include "framework.h"

Camera::Camera()
{
	width = 640; height = 480;
	xoffset = 0; yoffset = 0;
	base = 0; offset = 150; bufferWidth = 10;
	zbufAddr = 300; zbufFormat = 1;
	near = 1.0f; far = 100.0f;
	viewWindowSize = 2.0f;
	aspectRatio = (float)width / (float)height;
	setPosition(Vector(0.0f, 0.0f, -15.0f));
	lookAt(Vector(0.0f, 0.0f, 0.0f), Vector(0.0f, 1.0f, 0.0f));
	xrotate = yrotate = 0.0f;
	bgr = 128; bgg = 120; bgb = 120;
}

Camera::~Camera()
{
}

void Camera::init()
{
	int i;
	float maxZ = 65535;
	if(zbufFormat == 0)
		maxZ = 0xffffffffU;
	else if(zbufFormat == 1)
		maxZ = 0xffffff;
	StaticDma &dma = staticDma;
	for(i = 0; i < 2; i++)
	{
		cameraPacket[i] = dma.getPtr();

		dma.addUnpack(V4_32, VU_VIEWSHIFT, 4);
		
		dma.addFloat(2048.0f); dma.addFloat(2048.0f); dma.addFloat(0.0f); dma.addFloat(0.0f);
		
		dma.addFloat((float)width * 0.5f); dma.addFloat((float)height * 0.5f);		
		dma.addFloat(near * maxZ / 16.0f); dma.add32(0);

		dma.addFloat(viewWindowSize / 2.0f);
		dma.addFloat(viewWindowSize / 2.0f * aspectRatio);
		dma.addFloat(1.0f); dma.addFloat(1.0f);

		dma.addFloat(1.0f/2000.0f);
		dma.addFloat(1.0f/2000.0f);
		dma.addFloat((near + far) / (near - far));
		dma.addFloat(2 * near * far / (near + far));
		
		dma.startDirect();
		
		dma.startAD();

		dma.addAD(PS2_GS_PRMODECONT, 1);
		dma.addAD(PS2_GS_XYOFFSET_1,
				PS2_GS_SETREG_XYOFFSET(32768 - width * 8 - xoffset * 16, 32768 - height * 8 - yoffset * 16));
		dma.addAD(PS2_GS_SCISSOR_1, PS2_GS_SETREG_SCISSOR(xoffset, xoffset + width -1,
					yoffset, yoffset + height - 1));
		dma.addAD(PS2_GS_TEST_1, PS2_GS_SETREG_TEST(0, 1, 0, 0, 0, 0, 1, 1));
		regFrame[i] = PS2_GS_SETREG_FRAME(base + offset * i, bufferWidth, 0, 0);
		dma.addAD(PS2_GS_FRAME_1, regFrame[i]);
		if(zbufAddr >= 0)
			dma.addAD(PS2_GS_ZBUF_1, PS2_GS_SETREG_ZBUF(zbufAddr, zbufFormat, 0));
		else
			dma.addAD(PS2_GS_ZBUF_1, PS2_GS_SETREG_ZBUF(0, 0, 1));
		
		dma.endAD();

		dma.add64(PS2_GIFTAG_SET_TOPHALF(1, 1, 1, 6, 0, 3));
		dma.add64(0x551);

		dma.add32(bgr); dma.add32(bgg); dma.add32(bgb); dma.add32(0);
		
		dma.add32(32768 - width * 8); dma.add32(32768 - height * 8);
		dma.add64(0);
		
		dma.add32(32768 + width * 8); dma.add32(32768 + height * 8);
		dma.add64(0);

		dma.startAD();
		dma.addAD(PS2_GS_TEST_1, PS2_GS_SETREG_TEST(1, 6, 96, 3, 0, 0, 1, 2));
		dma.endAD();

		dma.endDirect();
	
		dma.ret();
	}
}

void Camera::begin()
{
	viewMatrix = cameraMatrix.invert();
	DynDma &dma = dynDma;
	dma.addUnpack(V4_32, VU_CAMMAT, 4);
	dma.addMatrix(viewMatrix);
	currentBuffer = screen.getCurrentBuffer();
	dma.call(cameraPacket[currentBuffer]);
}

void Camera::end()
{
}

void Camera::lookDir(const Vector &at, const Vector &up)
{
	cameraMatrix.z = at;
	cameraMatrix.z.normalize();
	cameraMatrix.x = cameraMatrix.z.cross(up) * -1.0f;
	cameraMatrix.x.normalize();
	cameraMatrix.y = cameraMatrix.x.cross(cameraMatrix.z);
}

void Camera::freeCam()
{
	Vector pos;
	const PadState &pad = framework.getPad(0);
	float timestep = framework.getTimestep();
	if(timestep == 0.0f)
		timestep = 1.0f / 60.0f;
	yrotate += pad.getRightX() * timestep * 2.0f;
	xrotate -= pad.getRightY() * timestep * 2.0f;
	pos = cameraMatrix.pos;
	cameraMatrix.unitmatrix();
	cameraMatrix.rotateX(xrotate);
	cameraMatrix.rotateY(yrotate);
	pos = pos + (cameraMatrix.x * pad.getLeftX()
			- cameraMatrix.z * pad.getLeftY()) * (timestep * 10.0f);
	if(pad.isPressed(PS2PAD_BUTTON_R1))
		pos = pos + cameraMatrix.y * (timestep * 10.0f);
	if(pad.isPressed(PS2PAD_BUTTON_R2))
		pos = pos - cameraMatrix.y * (timestep * 10.0f);
	cameraMatrix.pos = pos;
	cameraMatrix.y = cameraMatrix.y * -1.0f;
}
