#define VU_GIFTAG 0x3ef
#define VU_INVMAT 0x3f0
#define VU_OBJMAT 0x3f4
#define VU_VIEWSHIFT 0x3f8
#define VU_VIEWSCALE 0x3f9
#define VU_CLIPSCALE 0x3fa
#define VU_CLIPVEC 0x3fb
#define VU_CAMMAT 0x3fc
