#ifndef SCREEN_H
#define SCREEN_H

#include "types.h"

struct ps2_crtmode;
struct ps2_screeninfo;

class Screen
{
public:
	Screen();
	~Screen();
	void open();
	void close();
	void vblankWait();
	void flipBuffers();
	int getCurrentBuffer() { return currentBuffer; }
	void writeSmode2(int i, int ffmd, int dpms);
	void writeBgcolor(int r, int g, int b);
	void writeDispfb1(int fbp, int fbw, int psm, int dbx, int dby);
	void writeDisplay1(int dx, int dy, int magh, int magc, int dw, int dh);
	void writeDispfb2(int fbp, int fbw, int psm, int dbx, int dby);
	void writeDisplay2(int dx, int dy, int magh, int magc, int dw, int dh);
	void writePmode(int en1, int en2, int crtmd, int mmod, int amod, int slbg, int alp);
	int getTty() { return ttyfd; }
	int getEventFd() { return eventfd; }
protected:
	void openTty();
	void closeTty();
	static int sigHandler(int signal);
	int gsfd, ttyfd, eventfd, startup_vc;
	int currentBuffer;
	ps2_crtmode *crtmode;
	ps2_screeninfo *old_screeninfo;
	struct
	{
		int dx, dy;
		int magh, magv;
		int dh, dw;
	} displayArea;
};

extern Screen screen;

#endif /* SCREEN_H */
