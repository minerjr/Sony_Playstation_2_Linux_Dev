#ifndef SIGNALHANDLER_H
#define SIGNALHANDLER_H

class SignalHandler
{
public:
	SignalHandler();
	void registerHandler(int (*handler)(int signal), int signal = 0);
	void unregisterHandler(int (*handler)(int signal), int signal = 0);
	void doHandling(int signal);
protected:
	void regHandler(int (*handler)(int signal), int signal);
	void unregHandler(int (*handler)(int signal), int signal);
	static void g_signalHandler(int signal);
	struct sigHandler
	{
		sigHandler(int (*_handler)(int signal)) : handler(_handler){}
		int (*handler)(int signal);
		sigHandler *next;
	};
	sigHandler *handlers[32];
};

extern SignalHandler signalHandler;

#endif // SIGNALHANDLER_H
