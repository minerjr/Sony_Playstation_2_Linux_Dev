#ifndef DEBUG_H
#define DEBUG_H

#ifdef __cplusplus
extern "C" {
#endif

int printassert(const char *expr, const char *file, int line, const char *func);

#ifdef DEBUG

#define ASSERT(expr) ((expr) ? 0 : printassert(#expr, __FILE__, __LINE__, __PRETTY_FUNCTION__))

#else

#define ASSERT(expr) ((void)0)

#endif
  
#ifdef __cplusplus
}
#endif

#endif /* DEBUG_H */
