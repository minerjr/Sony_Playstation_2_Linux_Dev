#ifndef TYPES_H
#define TYPES_H

#include <asm/types.h>

typedef __u8 u8;
typedef __s8 s8;
typedef __u16 u16;
typedef __s16 s16;
typedef __u32 u32;
typedef __s32 s32;
typedef __u64 u64;
typedef __s64 s64;
typedef __u128 u128;
typedef __s128 s128;

static inline void writedword(void *ptr, u64 value)
{
	u32 h, l;
	h = value >> 32;
	l = value;
	asm("
	.set mips3
	.set noat
	pextlw	$1, %1, %2
	sd		$1, 0(%0)
	.set at
	.set mips0
	" : : "r" (ptr), "r" (h), "r" (l) : "$1");
}

#define FRAND(range) (((float)rand()) / ((float)RAND_MAX) * range)
#define SFRAND(range) (FRAND(range) * 2.0f - range)

#define PI 3.14159265f

#ifndef NULL
#define NULL 0
#endif

#define QALIGN __attribute__((aligned(16)))

#endif // TYPES_H
