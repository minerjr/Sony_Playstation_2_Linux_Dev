#include "uploadattribs.h"
#include "swizzle.h"
#include "debug.h"

#define MAX_LEVELS		12

struct STexAtt
{
	uint16 width, height, gs_mode, max_miplevels;
	
	struct STexLevAtt
	{
		uint16 block;		// used for bitbltbuf, tex0 and miptbp
		
		uint16 buffer_width, up_mode;	// used for bitbltbuf
		uint16 up_dimX, up_dimY;		// used for trxreg
	
		uint16 actual_bufw;	// used for tex0 and miptbp
		uint16 pad;
	}	sTexLevAtt[MAX_LEVELS];
} sTexAtt;


// attribute pickup functions
uint32 GetMaxMipLevels()
{
	return sTexAtt.max_miplevels;
}

uint64 GetBitBltBuf(const int32 iLevelNumber)
{
	const STexAtt::STexLevAtt &texLoc = sTexAtt.sTexLevAtt[iLevelNumber];

	const uint32 DBP = texLoc.block;
	const uint32 DBW = texLoc.buffer_width;
	const uint32 DPSM = texLoc.up_mode;
	ASSERT(DBP<(1<<14));
	ASSERT(DBW<(1<<6));
	ASSERT(DPSM==0x0 || DPSM==0x2 || DPSM==0x13 || DPSM==0x14);
	
	return (((uint64) DPSM) << 56) | (((uint64) DBW) << 48) | (((uint64) DBP) << 32);
}

uint64 GetTrxReg(const int32 iLevelNumber)
{
	const STexAtt::STexLevAtt &texLoc = sTexAtt.sTexLevAtt[iLevelNumber];

	const uint32 RRW = texLoc.up_dimX;
	const uint32 RRH = texLoc.up_dimY;
	ASSERT(RRW<(1<<12));
	ASSERT(RRH<(1<<12));
	
	return (((uint64) RRH) << 32) | RRW;
}

// only information regarding texel location (relative to page zero)
// and texture dimension issues are delivered, and sampling mode (PSM).
// TBP, TBW, PSM, TW, TH
int32 LeadZeroCountW(const int32 value)
{ 
	int32 res = 31;
	while(((1<<res)&value)==0 && res>=0)
		--res;
	return 31-(res+1);
}

uint64 GetTex0()
{
	const STexAtt::STexLevAtt &texLoc = sTexAtt.sTexLevAtt[0];

	const uint32 TBP = texLoc.block;
	const uint32 TBW = texLoc.actual_bufw;
	const uint32 PSM = sTexAtt.gs_mode;
	ASSERT(TBP<(1<<14));
	ASSERT(TBW<(1<<6));
	ASSERT(PSM==0x0 || PSM==0x2 || PSM==0x13 || PSM==0x14);

	int32 TW = 31 - (LeadZeroCountW(sTexAtt.width) + 1);
	int32 TH = 31 - (LeadZeroCountW(sTexAtt.height) + 1);
	if((1<<TW)<sTexAtt.width) ++TW;
	if((1<<TH)<sTexAtt.height) ++TH;
	ASSERT(((1<<TW)>=sTexAtt.width) && (TW>0 && TW<=10));
	ASSERT(((1<<TH)>=sTexAtt.height) && (TH>0 && TH<=10));

	return (((uint64) TH)<<30) | (((uint64) TW)<<26) | (PSM<<20) | (TBW<<14) | TBP;
}

uint64 GetMipTbp1()
{
	const STexAtt::STexLevAtt &texLoc1 = sTexAtt.sTexLevAtt[1];
	const STexAtt::STexLevAtt &texLoc2 = sTexAtt.sTexLevAtt[2];
	const STexAtt::STexLevAtt &texLoc3 = sTexAtt.sTexLevAtt[3];

	const uint32 TBP1 = texLoc1.block;
	const uint32 TBW1 = texLoc1.actual_bufw;
	const uint32 TBP2 = texLoc2.block;
	const uint32 TBW2 = texLoc2.actual_bufw;
	const uint32 TBP3 = texLoc3.block;
	const uint32 TBW3 = texLoc3.actual_bufw;
	ASSERT((TBP1<(1<<14)) && (TBP2<(1<<14)) && (TBP3<(1<<14)));
	ASSERT((TBW1<(1<<6)) && (TBW2<(1<<6)) && (TBW3<(1<<6)));

	return (((uint64) TBW3)<<54) | (((uint64) TBP3)<<40) | (((uint64) TBW2)<<34) | (((uint64) TBP2)<<20) | (TBW1<<14) | TBP1;
}

uint64 GetMipTbp2()
{
	const STexAtt::STexLevAtt &texLoc4 = sTexAtt.sTexLevAtt[4];
	const STexAtt::STexLevAtt &texLoc5 = sTexAtt.sTexLevAtt[5];
	const STexAtt::STexLevAtt &texLoc6 = sTexAtt.sTexLevAtt[6];

	const uint32 TBP4 = texLoc4.block;
	const uint32 TBW4 = texLoc4.actual_bufw;
	const uint32 TBP5 = texLoc5.block;
	const uint32 TBW5 = texLoc5.actual_bufw;
	const uint32 TBP6 = texLoc6.block;
	const uint32 TBW6 = texLoc6.actual_bufw;
	ASSERT((TBP4<(1<<14)) && (TBP5<(1<<14)) && (TBP6<(1<<14)));
	ASSERT((TBW4<(1<<6)) && (TBW5<(1<<6)) && (TBW6<(1<<6)));

	return (((uint64) TBW6)<<54) | (((uint64) TBP6)<<40) | (((uint64) TBW5)<<34) | (((uint64) TBP5)<<20) | (TBW4<<14) | TBP4;
}


// initialization functions
uint32 MakeBufWidth(const int32 dimX, const int32 mode)
{
	ASSERT(mode==MODE_T4 || mode==MODE_T8 || mode==MODE_CT16 || mode==MODE_CT32);
	return (mode==MODE_T4 || mode==MODE_T8)?(((dimX+127)/128)*2):((dimX+63)/64);
}

uint32 GetModeGS(const int32 mode)
{
	ASSERT(mode==MODE_T4 || mode==MODE_T8 || mode==MODE_CT16 || mode==MODE_CT32);
	return (mode==MODE_T4) ? 0x14 : ( (mode==MODE_T8) ? 0x13 : ( (mode==MODE_CT16) ? 0x2 : 0 ) );
}

bool IsSwizzable(const int32 width, const int32 height, const int32 mode)
{
	return ( (mode==MODE_T4) && IsSwizzable4(width, height) ) ||
			 ( (mode==MODE_T8) && IsSwizzable8(width, height) ) ||
			 ( (mode==MODE_CT16) && IsSwizzable16(width, height) );
}


uint32 InsertMiniLevels(const uint32 block_offs[], const uint32 bl_offs_len, uint32 level_number,
		const uint32 page_number, uint32 proc_width, uint32 proc_height, const uint32 min_subwidth,
		const uint32 min_subheight, const bool select_width);

void MakeUploadAttributes(const int32 width, const int32 height, const int32 mode)
{
	ASSERT(width>0 && height>0);
	ASSERT(width<=4096 && height<=4096);

	// Just incase either dimension is
	// smaller than 8, we must leave this initialized
	sTexAtt.sTexLevAtt[0].block = 0;
			
	//
	int32 min_subwidth=8, min_subheight=8;
	int32 proc_width=width, proc_height=height;
	
	switch(mode)
	{
		case MODE_CT32:
			break;
		case MODE_CT16:	// transpose
			proc_width=height;
			proc_height=width>>1;
			min_subheight>>=1;
			break;
		case MODE_T8:
			proc_width=width>>1;
			proc_height=height>>1;
			min_subwidth>>=1;
			min_subheight>>=1;
			break;
		case MODE_T4:	// transpose
			proc_width=height>>1;
			proc_height=width>>2;
			min_subwidth>>=1;
			min_subheight>>=2;
			break;
		default:
			ASSERT(false);
	};

	// Choose a block location for every
	// mipmap level, relative to page zero.
	// alloc blocks in mode MODE_CT32
	int32 level_number = 0;
	int32 page_number = 0;

	while(proc_width>=64 && proc_height>=32)
	{
		ASSERT(level_number<MAX_LEVELS);

		// trivial soloution
		// use cur_page
		sTexAtt.sTexLevAtt[level_number].block = page_number*32;

		page_number += ((proc_width*proc_height)/(64*32));

		++level_number;
		proc_width >>= 1;
		proc_height >>= 1;
	}

	
	if(proc_height<32)
	{
		const uint32 block_offs[] = {0,2,8,10,26};
		page_number += InsertMiniLevels(block_offs, 5, level_number, page_number, proc_width, proc_height, min_subwidth, min_subheight, false);
	}
	else
	{
		ASSERT(proc_width<64);
		const uint32 block_offs[] = {0,1,4,5,16,17,20,21};
		page_number += InsertMiniLevels(block_offs, 8, level_number, page_number, proc_width, proc_height, min_subwidth, min_subheight, true);
	}


	// initialize remaining arguments
	ASSERT(width<=4096 && height<=4096);

	int32 width_ = width, height_ = height;
	int32 cur_level = 0;
	do
	{
		STexAtt::STexLevAtt * pTexLoc = &sTexAtt.sTexLevAtt[cur_level++];

		pTexLoc->up_dimX = width_;
		pTexLoc->up_dimY = height_;
	
		const bool bSwizzable = IsSwizzable(width_,height_,mode);

		switch(mode)
		{
			case MODE_CT16:	// transpose		
				if(bSwizzable)
				{
					pTexLoc->up_dimX = height_;
					pTexLoc->up_dimY = width_>>1;
				}
			case MODE_T8:
				if(bSwizzable)
				{
					pTexLoc->up_dimX = width_>>1;
					pTexLoc->up_dimY = height_>>1;
				}
				break;
			case MODE_T4:	// transpose
				if(bSwizzable)
				{
					pTexLoc->up_dimX = height_>>1;
					pTexLoc->up_dimY = width_>>2;
				}
				break;
			default:
				ASSERT(mode == MODE_CT32);
		};

		pTexLoc->up_mode = (bSwizzable) ? 0x0 : GetModeGS(mode);
		pTexLoc->buffer_width = MakeBufWidth( pTexLoc->up_dimX, ((bSwizzable) ? MODE_CT32 : mode) );
		pTexLoc->actual_bufw	 = MakeBufWidth( width_, mode );
				
		// next level
		width_ >>= 1; height_ >>= 1;
	}
	while(width_>=8 && height_>=8);

	// set maximum number of mipmap levels
	// and remaining attributes.
	int32 TW = 31 - (LeadZeroCountW(width) + 1);
	int32 TH = 31 - (LeadZeroCountW(height) + 1);
	const bool bPowerOfTwo = width==(1<<TW) && height==(1<<TH);
	
	sTexAtt.max_miplevels = (bPowerOfTwo) ? ((cur_level>7)?7:cur_level) : 1;
	sTexAtt.width = width;
	sTexAtt.height = height;
	sTexAtt.gs_mode = GetModeGS(mode); 
}


// insert levels that are smaller then a single page (64x32) on either dimension
uint32 InsertMiniLevels(const uint32 block_offs[], const uint32 bl_offs_len, uint32 level_number,
		const uint32 page_number, uint32 proc_width, uint32 proc_height, const uint32 min_subwidth,
		const uint32 min_subheight, const bool select_width)
{
	ASSERT(min_subwidth>=4 && min_subheight>=2);
	const uint32 uConsLastPages = (!select_width) ? ((proc_width + 63) / 64) : ((proc_height + 31) / 32);
	const uint32 uBlockNr = page_number*32;

	int32 dim_sum = 0;
	while(proc_width>=min_subwidth && proc_height>=min_subheight)
	{
		STexAtt::STexLevAtt &texLoc = sTexAtt.sTexLevAtt[level_number++];

		const uint32 index = dim_sum>>3;
		ASSERT(index>=0 && index<bl_offs_len);
		if(!select_width && proc_height==2 && proc_width>16 && index==(bl_offs_len-1))
		{
			// special case (for 4 bit only, textures (height/width)>=16 )
			const uint32 uPrevLevelCrossesNumPages = ((proc_width<<1) + 63) / 64;
			const uint32 uLowerLeftBlockNumber = block_offs[bl_offs_len-2];
			texLoc.block = uBlockNr + uPrevLevelCrossesNumPages*32 + uLowerLeftBlockNumber;
		}
		else
			texLoc.block = uBlockNr + block_offs[index];

		const int32 iAdder = (select_width) ? proc_width : proc_height;
		dim_sum += (iAdder<8) ? 8 : iAdder;
		proc_width >>= 1;
		proc_height >>= 1;
	}

	return uConsLastPages;
}
