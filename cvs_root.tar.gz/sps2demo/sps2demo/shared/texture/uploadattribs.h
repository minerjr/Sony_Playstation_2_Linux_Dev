#ifndef __UPLOADATTRIBS_H__
#define __UPLOADATTRIBS_H__

#define MODE_CT32			0
#define MODE_CT16			1
#define MODE_T8			2
#define MODE_T4			3

#include "exttypes.h"


// initialization function
void MakeUploadAttributes(const int32 width, const int32 height, const int32 mode);

// attribute pickup functions
// vram pointers are returned with a
// block offset relative to page zero.
// tex0 is delivered incomplete.
uint32 GetMaxMipLevels();
uint64 GetBitBltBuf(const int32 iLevelNumber);
uint64 GetTrxReg(const int32 iLevelNumber);
uint64 GetTex0();		// values set: TBP, TBW, PSM, TW, TH
uint64 GetMipTbp1();
uint64 GetMipTbp2();

// mode conversion function
uint32 GetModeGS(const int32 mode);
bool IsSwizzable(const int32 width, const int32 height, const int32 mode);


#endif
