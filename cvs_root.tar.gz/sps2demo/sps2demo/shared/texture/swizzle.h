#ifndef __SWIZZLE_H__
#define __SWIZZLE_H__

#include "exttypes.h"

// this function works for the following resolutions
// Width:	32, 64, 96, 128, any multiple of 128 smaller then or equal to 4096
// Height:	16, 32, 48, 64, 80, 96, 112, 128, any multiple of 128 smaller then or equal to 4096

// the texels must be uploaded as a 32bit texture
// width_32bit = height_4bit / 2
// height_32bit = width_4bit / 4
// remember to adjust the mapping coordinates when
// using a dimension which is not a power of two
void Swizzle4to32(void * pSwizTexels, const void * pInTexels, const int32 width, const int32 height);
bool IsSwizzable4(const int32 width, const int32 height);



// this function works for the following resolutions
// Width:	any multiple of 16 smaller then or equal to 4096
// Height:	any multiple of 4 smaller then or equal to 4096

// the texels must be uploaded as a 32bit texture
// width_32bit = width_8bit / 2
// height_32bit = height_8bit / 2
// remember to adjust the mapping coordinates when
// using a dimension which is not a power of two
void Swizzle8to32(void * pSwizTexels, const void * pInTexels, const int32 width, const int32 height);
bool IsSwizzable8(const int32 width, const int32 height);



// this function works for the following resolutions
// Width:	16, 32, 48, 64, any multiple of 64 smaller then or equal to 4096
// Height:	8, 16, 24, 32, 40, 48, 56, 64, any multiple of 64 smaller then or equal to 4096

// the texels must be uploaded as a 32bit texture
// width_32bit = height_16bit
// height_32bit = width_16bit / 2
// remember to adjust the mapping coordinates when
// using a dimension which is not a power of two
void Swizzle16to32(void * pSwizTexels, const void * pInTexels, const int32 width, const int32 height);
bool IsSwizzable16(const int32 width, const int32 height);

#endif
