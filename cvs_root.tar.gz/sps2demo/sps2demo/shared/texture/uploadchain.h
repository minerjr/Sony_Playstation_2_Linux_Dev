#ifndef __UPLOADCHAIN_H__
#define __UPLOADCHAIN_H__

#include "exttypes.h"

// MakeUploadAttributes() must be called before this function
// pTexels and pPalette should be the unswapable and swizzled representation
// uDstVRamBlock is the block number in vram < 512*32
// uQTopSize is the quad size of the biggest level.

enum GS_CONTEXT
{
	GS_CONTEXT_1=1,
	GS_CONTEXT_2
};

const void * MakeUploadChain(const void * pTexels, const void * pPalette, const uint32 uDstVRamBlock, const uint32 uQTopSize, const uint32 uNumLevels, const int32 iTexelMode, const GS_CONTEXT context=GS_CONTEXT_1);


#endif
