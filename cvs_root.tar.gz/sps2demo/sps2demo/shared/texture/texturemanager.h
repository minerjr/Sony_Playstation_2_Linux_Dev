#ifndef TEXTUREMANAGER_H
#define TEXTUREMANAGER_H

class TextureManager
{
	public:
						TextureManager();
						~TextureManager();
		int				loadTexture(const char *pName);

	protected:

		struct ManagedTexture
		{
			ManagedTexture	*pNext;
			int				id;
			char			*pName;
		}				*m_pTextures;
};

extern TextureManager textureManager;

#endif /* TEXTUREMANAGER_H */
