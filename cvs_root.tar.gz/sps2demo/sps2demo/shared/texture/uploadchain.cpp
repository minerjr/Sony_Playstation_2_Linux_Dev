#include "uploadchain.h"
#include "uploadattribs.h"
#include "debug.h"
#include "dma.h"
#include "sps2.h"
#include <linux/ps2/dev.h>


// MakeUploadAttributes() must be called before this function
// pTexels and pPalette should be the unswapable and swizzled representation
// uDstVRamBlock is the block number in vram < 512*32
// uQTopSize is the quad size of the biggest level.
void DirectByRef(const void * pData, const uint32 uQuads);

const void * MakeUploadChain(const void * pTexels, const void * pPalette, const uint32 uDstVRamBlock, const uint32 uQTopSize, const uint32 uNumLevels, const int32 iTexelMode, const GS_CONTEXT context)
{
	ASSERT(iTexelMode==MODE_T4 || iTexelMode==MODE_T8 || iTexelMode==MODE_CT16 || iTexelMode==MODE_CT32);
	ASSERT(uNumLevels>0 && uNumLevels<=7);
	const void * pPhysPtr = (const void *) staticDma.getPtr();

	const bool bGotPalette = (iTexelMode==MODE_T4 || iTexelMode==MODE_T8);

	// texel destination in vram
	const uint64 uTexelStart=uDstVRamBlock+((bGotPalette)?4:0);

	////// Palette specific area begin //////
	if(bGotPalette)
	{
		int32 palW, palH;
		if(iTexelMode==MODE_T4) { palW=8; palH=2; }
		else { palW=16; palH=16; }
		const uint32 uQPal = (palW*palH)/4;

		staticDma.startDirect();
		staticDma.add64(PS2_GIFTAG_SET_TOPHALF(3, 0, 0, 0, PS2_GIFTAG_FLG_PACKED, 1));	// PS2_GIFTAG_SET_TOPHALF(nloop, eop, pre, prim, flg, nreg)
		staticDma.add64(PS2_GIFTAG_REGS_AD);

		staticDma.add64(PS2_GS_SETREG_BITBLTBUF(0, 0, 0, uDstVRamBlock, 1, 0));
		staticDma.add64(PS2_GS_BITBLTBUF);
		staticDma.add64(PS2_GS_SETREG_TRXREG(palW, palH));
		staticDma.add64(PS2_GS_TRXREG);
		staticDma.add64(PS2_GS_SETREG_TRXDIR(0));
		staticDma.add64(PS2_GS_TRXDIR);

		staticDma.add64(PS2_GIFTAG_SET_TOPHALF(uQPal, 0, 0, 0, PS2_GIFTAG_FLG_IMAGE, 0));
		staticDma.add64(0);
		staticDma.endDirect();
	
		DirectByRef((const void *) pPalette, uQPal);
	}
	/////// Palette specific area end ///////

	// Adding texels
	uint32 uQsize = uQTopSize;

	// skip the top mipmap level
	const uint128 * pData = (const uint128 *) pTexels;

	for(int32 m=0; m<(int32) uNumLevels; m++)
	{
		staticDma.startDirect();
		staticDma.add64(PS2_GIFTAG_SET_TOPHALF(3, 0, 0, 0, PS2_GIFTAG_FLG_PACKED, 1));	// PS2_GIFTAG_SET_TOPHALF(nloop, eop, pre, prim, flg, nreg)
		staticDma.add64(PS2_GIFTAG_REGS_AD);
		staticDma.add64((GetBitBltBuf(m)+(((uint64) uTexelStart)<<32)));
		staticDma.add64(PS2_GS_BITBLTBUF);
		staticDma.add64(GetTrxReg(m));
		staticDma.add64(PS2_GS_TRXREG);
		staticDma.add64(PS2_GS_SETREG_TRXDIR(0));
		staticDma.add64(PS2_GS_TRXDIR);
		staticDma.add64(PS2_GIFTAG_SET_TOPHALF(uQsize,((m==(((int32)uNumLevels)-1))?1:0),0,0,PS2_GIFTAG_FLG_IMAGE,0));
		staticDma.add64(0);
		staticDma.endDirect();

		ASSERT(uQsize<0x8000);
		DirectByRef((const void *) pData, uQsize);

		pData += uQsize;
		
		ASSERT(((uQsize&3)==0) || (m==((int32) uNumLevels-1)));
		uQsize >>= 2;
	}

	// values set: TBP, TBW, PSM, TW, TH
	const int32 mxl = uNumLevels - 1;
	const uint32 L = 0;
	const uint32 K = (0xfffl)&(-0x50);
	const uint32 Mag = 1;	// bilinear
	const uint32 Min = (uNumLevels>1)?4:1;	// bilinear
	const uint64 uPtrOffset = (((uint64) uTexelStart)<<40) | (((uint64) uTexelStart)<<20) | uTexelStart;

	// set texture attribs
	staticDma.startDirect();
	staticDma.startAD();
	const bool bCntxt = context == GS_CONTEXT_1;

	const uint64 tex0_addr = (bCntxt)?PS2_GS_TEX0_1:PS2_GS_TEX0_2;
	const uint64 tex1_addr = (bCntxt)?PS2_GS_TEX1_1:PS2_GS_TEX1_2;
	const uint64 miptbp1_addr = (bCntxt)?PS2_GS_MIPTBP1_1:PS2_GS_MIPTBP1_2;
	const uint64 miptbp2_addr = (bCntxt)?PS2_GS_MIPTBP2_1:PS2_GS_MIPTBP2_2;
	
	staticDma.addAD(tex0_addr, (GetTex0() + PS2_GS_SETREG_TEX0(uTexelStart, 0, 0, 0, 0, 1, 0, uDstVRamBlock, 0, 0, 0, (bGotPalette)?1:0)));
	staticDma.addAD(tex1_addr, PS2_GS_SETREG_TEX1(0, mxl, Mag, Min, 0, L, K));
	staticDma.addAD(miptbp1_addr, (GetMipTbp1() + uPtrOffset));
	staticDma.addAD(miptbp2_addr, (GetMipTbp2() + uPtrOffset));
	staticDma.addAD(PS2_GS_TEXFLUSH, 0);
	
	staticDma.endAD();
	staticDma.endDirect();


	// Terminate
	staticDma.ret();
	return pPhysPtr;
}


void DirectByRef(const void * pData, const uint32 uQuads)
{
	//staticDma.startDirect();
	//for(uint32 k=0; k<uQuads; k++)
	//{
	//	staticDma.add64(((const uint64 *)pData)[2*k+0]);
	//	staticDma.add64(((const uint64 *)pData)[2*k+1]);
	//}
	//staticDma.endDirect();
	//return;
	
	uint32 uAddr = (uint32) pData;
	ASSERT((uAddr&0xf)==0 && uQuads>0);	// 16byte alignment is required
	uint32 uQleft = uQuads;

	while(uQleft>0)
	{
		const uint32 uNextPage = (uAddr + 4096) & (~4095);
		ASSERT(((uNextPage - uAddr)&0xf)==0);
		const uint32 uMaxDelivery = (uNextPage - uAddr)>>4;
		ASSERT(uMaxDelivery>0 && uMaxDelivery<=(4096/16));
		const uint32 uDelivery = (uQleft < uMaxDelivery)?uQleft:uMaxDelivery;
		ASSERT(uDelivery <= uQleft);
		staticDma.ref(sps2.virt2phys((void*)uAddr),uDelivery, ((uint64) PS2_VIF_SET_CODE(uDelivery, 0, PS2_VIF_DIRECT, 0))<<32);

		// next
		uQleft -= uDelivery;
		uAddr += (uDelivery*16);
	}
}

#if 0
	ASSERT(iTexelMode==MODE_T4 || iTexelMode==MODE_T8 || iTexelMode==MODE_CT16 || iTexelMode==MODE_CT32);
	ASSERT(uNumLevels>0 && uNumLevels<=7);
	const bool bGotPalette = (iTexelMode==MODE_T4 || iTexelMode==MODE_T8);

	// texel destination in vram
	const uint64 uTexelStart=uDstVRamBlock+((bGotPalette)?4:0);

	////// Palette specific area begin //////
	if(bGotPalette)
	{
		int32 palW, palH;
		if(iTexelMode==MODE_T4) { palW=8; palH=2; }
		else { palW=16; palH=16; }
		const uint32 uQPal = (palW*palH)/4;

		pChain->BeginCntPacket();
		pChain->Add64(GIFTAG(3, 0, 0, 0, 0, 1));
		pChain->Add64(GIFTAG_REGS1(AD));
		pChain->AddReg(BITBLTBUF, BITBLTBUF_SET(0, 0, 0, uDstVRamBlock, 1, 0));
		pChain->AddReg(TRXREG, TRXREG_SET(palW, palH));
		pChain->AddReg(TRXDIR, TRXDIR_SET(0));
		pChain->Add64(GIFTAG(uQPal, 0, 0, 0, 2, 0));	// GIFTAG(NLOOP, EOP, PRE, PRIM, FLG, NREG)
		pChain->Add64(0);
		pChain->EndPacket();

		pChain->AddRefPacket(pPalette,uQPal);
	}
	/////// Palette specific area end ///////

	// Adding texels
	uint32 uQsize = uQTopSize;

	// skip the top mipmap level
	const uint128 * pData = (const uint128 *) pTexels;

	for(int32 m=0; m<uNumLevels; m++)
	{
		pChain->BeginCntPacket();

		pChain->Add64(GIFTAG(3, 0, 0, 0, 0, 1));
		pChain->Add64(GIFTAG_REGS1(AD));
		pChain->AddReg(BITBLTBUF, (GetBitBltBuf(m)+(((uint64) uTexelStart)<<32)));
		pChain->AddReg(TRXREG, GetTrxReg(m));
		pChain->AddReg(TRXDIR, TRXDIR_SET(0));
		pChain->Add64(GIFTAG(uQsize,((m==(uNumLevels-1))?1:0),0,0,2,0));	// GIFTAG(NLOOP, EOP, PRE, PRIM, FLG, NREG)
		pChain->Add64(0);
		
		pChain->EndPacket();

		pChain->AddRefPacket((void*)pData,uQsize);
		pData += uQsize;
		
		ASSERT(((uQsize&3)==0) || (m==(uNumLevels-1)));
		uQsize >>= 2;
	}

	pChain->AddRetPacket();

	// values set: TBP, TBW, PSM, TW, TH
	const uint64 uTex0 = GetTex0() + TEX0_SET(uTexelStart, 0, 0, 0, 0, 1, 0, uDstVRamBlock, 0, 0, 0, (bGotPalette)?1:0);

	const int32 mxl = uNumLevels - 1;
	const uint32 L = 0;
	const uint32 K = (0xfffl)&(-0x90);
	const uint32 Mag = 1;	// bilinear
	const uint32 Min = (uNumLevels>1)?4:1;	// bilinear
	const uint64 uTex1 = TEX1_SET(0, mxl, Mag, Min, 0, L, K);

	const uint64 uPtrOffset = (((uint64) uTexelStart)<<40) | (((uint64) uTexelStart)<<20) | uTexelStart;
	const uint64 uMipTBP1 = GetMipTbp1() + uPtrOffset;
	const uint64 uMipTBP2 = GetMipTbp2() + uPtrOffset;
#endif

