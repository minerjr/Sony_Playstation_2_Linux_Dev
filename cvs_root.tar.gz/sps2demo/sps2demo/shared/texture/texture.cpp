#include "texture.h"
#include "swizzle.h"
#include "uploadattribs.h"
#include "uploadchain.h"
#include <intmd/textureintmd.h>
#include <intmd/pixel_formats.h>
#include "debug.h"
#include "sps2.h"
#include "dma.h"


// internal texture chain reference array
struct STexChains
{
	const void * pBuf1Cntxt1;
	const void * pBuf1Cntxt2;
	const void * pBuf2Cntxt1;
	const void * pBuf2Cntxt2;
};

int num_registered_textures = 0;
STexChains * pRegTextures = NULL;	// internal array of registered textures


bool CreateTexture(const CTextureIntmd &texture, int * pTexID)
{	
	// Allocate a texture entry
	ASSERT((pRegTextures==NULL && num_registered_textures==0) || (pRegTextures!=NULL && num_registered_textures>0));

	*pTexID = 0;	// default dead ID value
	STexChains * pOldRegTextures = pRegTextures;
	pRegTextures = new STexChains[num_registered_textures+1];
	if(pRegTextures == NULL) { pRegTextures = pOldRegTextures; return false; }
	for(int t=0; t<num_registered_textures; t++)				// copy all the old entries
		pRegTextures[t] = pOldRegTextures[t];
	if(pOldRegTextures!=NULL) delete [] pOldRegTextures;	// clean up old internal array

	// setup texture
	int32 num_levels = texture.GetNumLevels();
	ASSERT(num_levels>0);
	const int32 intmdPixFormat = texture.GetPixelFormat();

	const int32 dimX = texture.GetLevel(0).GetWidth();
	const int32 dimY = texture.GetLevel(0).GetHeight();

	const int32 mode = (intmdPixFormat==INDEXCOLOR16)?MODE_T4:((intmdPixFormat==INDEXCOLOR256)?MODE_T8:MODE_CT32);
	ASSERT(mode!=MODE_CT32 || intmdPixFormat==COLORRGBA32);
	ASSERT(mode==MODE_T4 || mode==MODE_T8 || mode==MODE_CT16 || mode==MODE_CT32);


	// create all GS related registers for the texture uploading
	MakeUploadAttributes(dimX, dimY, mode);

	// clamp amount of mipmap levels to be used
	if(GetMaxMipLevels()<(uint32) num_levels) num_levels = (int32) GetMaxMipLevels();

	// allocate unswapable memory and move/swizzle texels into it
	const uint32 uShift = (mode==MODE_T4)?3:((mode==MODE_T8)?2:((mode==MODE_CT16)?1:0));
	const uint32 uQTopSize = (dimX*dimY)>>(2+uShift);

	// allocate extra if we have a palette
	uint32 uQuadsAlloc = (mode==MODE_T4)?4:((mode==MODE_T8)?64:0);
	for(int32 l=0; l<num_levels; l++)
		uQuadsAlloc += (uQTopSize>>(l*2));

	uint128 * pUnswapData = (uint128 *) sps2.allocLinearMem( uQuadsAlloc );//AllocStatic( uQuadsAlloc );
	if(pUnswapData == NULL)
		return false;
	uint128 * pData = pUnswapData;

	// transfer texels
	for(int32 l=0; l<num_levels; l++)
	{
		const int32 sub_dimX = dimX >> l;
		const int32 sub_dimY = dimY >> l;
		const bool bSwizzable = IsSwizzable(sub_dimX, sub_dimY, mode);
		const void * pTexels = texture.GetLevel(l).GetTexelData();
		const uint32 uQSize = uQTopSize>>(l*2);

		if(bSwizzable)
		{
			ASSERT(mode!=MODE_CT32);
			if(mode==MODE_T4) Swizzle4to32(pData, pTexels, sub_dimX, sub_dimY);
			else if(mode==MODE_T8) Swizzle8to32(pData, pTexels, sub_dimX, sub_dimY);
			else Swizzle16to32(pData, pTexels, sub_dimX, sub_dimY);
		}
		else if(mode == MODE_T4)
			for(int q=0; q<(sub_dimX*sub_dimY); q++)
			{
				const int32 bits_set = q&1;	// 0,1		(lower/upper 4 bits)
				((uint8 *) pData)[(q>>1)] = (((uint8 *) pData)[(q>>1)] & (-bits_set)) | (((const uint8 *) pTexels)[q]<<(bits_set*4));
			}
		else memcpy(pData, pTexels, uQSize*16);

		pData += uQSize;
	}

	// transfer palette into current location of pData
	if(mode==MODE_T4) memcpy(pData, texture.GetPalette(), 16*4);
	else if(mode==MODE_T8)
		for(int32 p=0; p<256; p++)
			((uint32 *) pData)[(p & 231) + ((p&8)<<1) + ((p&16)>>1)] = ((const uint32 *) texture.GetPalette())[p];

	// Make 4 callchains, one for every of 4 vram locations.
	// pTexels, pPalette, uDstVRamBlock, 
	STexChains sNewRegTex;
	sNewRegTex.pBuf1Cntxt1 = MakeUploadChain(pUnswapData, pData, 450*32, uQTopSize, num_levels, mode, GS_CONTEXT_1);
	sNewRegTex.pBuf1Cntxt2 = MakeUploadChain(pUnswapData, pData, 465*32, uQTopSize, num_levels, mode, GS_CONTEXT_2);
	sNewRegTex.pBuf2Cntxt1 = MakeUploadChain(pUnswapData, pData, 480*32, uQTopSize, num_levels, mode, GS_CONTEXT_1);
	sNewRegTex.pBuf2Cntxt2 = MakeUploadChain(pUnswapData, pData, 495*32, uQTopSize, num_levels, mode, GS_CONTEXT_2);

	pRegTextures[num_registered_textures] = sNewRegTex;	// add new registered texture
	++num_registered_textures;
	*pTexID = num_registered_textures;
	
	return true;
}


void UploadContext1(const int32 iTexID)
{
	ASSERT(iTexID>0 && iTexID<=num_registered_textures);
	const STexChains &sRegTex = pRegTextures[iTexID-1];
	const void * ptr_array[] = {sRegTex.pBuf1Cntxt1, sRegTex.pBuf2Cntxt1};

	static uint32 buffer = 0;

	dynDma.call((const uint32) ptr_array[buffer]);
	buffer = 1 - buffer;
}

void UploadContext2(const int32 iTexID)
{
	ASSERT(iTexID>0 && iTexID<=num_registered_textures);
	const STexChains &sRegTex = pRegTextures[iTexID-1];
	const void * ptr_array[] = {sRegTex.pBuf1Cntxt2, sRegTex.pBuf2Cntxt2};

	static uint32 buffer = 0;
	
	dynDma.call((const uint32) ptr_array[buffer]);
	buffer = 1 - buffer;
}
