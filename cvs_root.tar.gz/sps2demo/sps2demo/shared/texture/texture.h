#ifndef __TEXTURE_H__
#define __TEXTURE_H__

#include "exttypes.h"

class CTextureIntmd;

bool CreateTexture(const CTextureIntmd &texture, int * pTexID);
void UploadContext1(const int32 iTexID);
void UploadContext2(const int32 iTexID);


#endif
