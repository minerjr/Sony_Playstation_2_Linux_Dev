#ifndef TEXTUREINTMDLOADER_H
#define TEXTUREINTMDLOADER_H

#include "intmd/textureintmd.h"

class CTextureIntmdLoader : public CTextureIntmd
{
	public:
				~CTextureIntmdLoader();
		void	load(const char *filename);
};

#endif /* TEXTUREINTMDLOADER_H */
