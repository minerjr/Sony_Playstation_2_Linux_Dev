#include "texturemanager.h"
#include "texture.h"
#include "textureintmdloader.h"
#include <string.h>
#include <malloc.h>

TextureManager textureManager;

TextureManager::TextureManager()
{
	m_pTextures = NULL;
}

TextureManager::~TextureManager()
{
	ManagedTexture *pCur, *pNext;

	pCur = m_pTextures;
	while(pCur != NULL)
	{
		pNext = pCur->pNext;
		free(pCur->pName);
		delete pCur;
		pCur = pNext;
	}
}

int TextureManager::loadTexture(const char *pName)
{
	if(pName[0] == 0)
		return 0;
	
	ManagedTexture *pCur = m_pTextures;

	while(pCur != NULL)
	{
		if(strcmp(pCur->pName, pName) == 0)
			return pCur->id;
		pCur = pCur->pNext;
	}

	printf("loading texture: '%s'\n", pName);
	
	pCur = new ManagedTexture;
	
	CTextureIntmdLoader texture;
	texture.load(pName);

	CreateTexture(texture, &pCur->id);

	pCur->pName = strdup(pName);

	pCur->pNext = m_pTextures;
	m_pTextures = pCur;

	return pCur->id;
}
