#include "textureintmdloader.h"
#include "file.h"
#include <stdio.h>
#include "debug.h"

class CSceneCreatorIntmd
{
	public:
		static void ohMyGodWhatAHack(CTextureIntmd &tex, const char *filename);
		static void horribleHackPart2(CTextureIntmd &tex);
};

CTextureIntmdLoader::~CTextureIntmdLoader()
{
	CSceneCreatorIntmd::horribleHackPart2(*this);
}

void CTextureIntmdLoader::load(const char *filename)
{
	CSceneCreatorIntmd::ohMyGodWhatAHack(*this, filename);
}

// load a texture into a CTextureIntmd structure
void CSceneCreatorIntmd::ohMyGodWhatAHack(CTextureIntmd &tex, const char *filename)
{
	File file(filename, "tex");

	file.read(&tex.m_iPixelFormat, 4);
	if(tex.m_iPixelFormat == 1)
	{
		tex.m_pInternPalette = new uint8[4*16];
		file.read(tex.m_pInternPalette, 4*16);
	}
	else if(tex.m_iPixelFormat == 2)
	{
		tex.m_pInternPalette = new uint8[4*256];
		file.read(tex.m_pInternPalette, 4*256);
	}
	else
		tex.m_pInternPalette = NULL;

	file.read(&tex.m_iNumLevels, 4);
	tex.m_pMipMaps = new CBinaryBitmapIntmd[tex.m_iNumLevels];

	for(int i = 0; i < tex.m_iNumLevels; i++)
	{
		CBinaryBitmapIntmd &bm = tex.m_pMipMaps[i];
		file.read(&bm.m_iWidth, 4);
		file.read(&bm.m_iHeight, 4);
		if(tex.m_iPixelFormat == 4)
		{
			bm.m_pTexelData = new uint8[bm.m_iWidth * bm.m_iHeight * 4];
			file.read(bm.m_pTexelData, bm.m_iWidth * bm.m_iHeight * 4);
		}
		else
		{
			bm.m_pTexelData = new uint8[bm.m_iWidth * bm.m_iHeight];
			file.read(bm.m_pTexelData, bm.m_iWidth * bm.m_iHeight);
		}
	}
}

// free the previously loaded data in a CTextureIntmd structure
void CSceneCreatorIntmd::horribleHackPart2(CTextureIntmd &tex)
{
	delete [] tex.m_pInternPalette;

	for(int i = 0; i < tex.m_iNumLevels; i++)
		delete [] tex.m_pMipMaps[i].m_pTexelData;

	delete [] tex.m_pMipMaps;
}
