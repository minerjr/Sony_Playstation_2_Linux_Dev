#include "dma.h"
#include "sps2.h"
#include "debug.h"
#include "dmadisas.h"
#include "math.h"
#include "sps2registers.h"
#include <stdio.h>
#include <fcntl.h>

DynDma dynDma;
StaticDma staticDma;

void DmaMem::open()
{
	vifState = VIF_BASE;
	physPtr = getNewPage();
	newTag();
}

void DmaMem::close()
{
}

void DmaMem::addVector(const Vector &vec)
{
	addFloat(vec.x);
	addFloat(vec.y);
	addFloat(vec.z);
	addFloat(vec.w);
}

void DmaMem::addVector3(const Vector &vec)
{
	addFloat(vec.x);
	addFloat(vec.y);
	addFloat(vec.z);
}

void DmaMem::addMatrix(const Matrix &mat)
{
	addVector(mat.x);
	addVector(mat.y);
	addVector(mat.z);
	addVector(mat.pos);
}

inline void DmaMem::prepareForDmaTag()
{
	ASSERT(vifState == VIF_BASE);
	align(4);
	if(ptr == endPtr)
		add64(0);		// HACK! but better than nothing
}

void DmaMem::end()
{
	prepareForDmaTag();
	*dmaTag = (7 << 28) + (ptr - (u32*)dmaTag) / 4 - 1;
	close();
}

void DmaMem::ret()
{
	prepareForDmaTag();
	*dmaTag = (6 << 28) + (ptr - (u32*)dmaTag) / 4 - 1;
	newTag();
}

void DmaMem::call(u32 addr)
{
	prepareForDmaTag();
	*dmaTag = ((u64)addr << 32) + (5 << 28) + (ptr - (u32*)dmaTag) / 4 - 1;
	newTag();
}

void DmaMem::ref(u32 addr, u32 size, u64 tte)
{
	if(ptr - 2 != (u32*)dmaTag ||	// no data for the last CNT tag? then just reuse it for the REF
			ptr + 4 >= endPtr)		// but only if we are not in the last qword of a page
	{
		prepareForDmaTag();
		*dmaTag = (1 << 28) + (ptr - (u32*)dmaTag) / 4 - 1;	// add a CNT
		newTag();
		if(ptr + 4 >= endPtr)
			add64(0);		// ANOTHER HACK! but it should work...
	}
	add64(tte);
	prepareForDmaTag();
	*dmaTag = ((u64)addr << 32) + (3 << 28) + size;
	newTag();
}

void DmaMem::newTag()
{
	ASSERT(ptr != endPtr);
	dmaTag = (u64*)ptr;
	add64(0);
}

void DmaMem::startDirect()
{
	ASSERT(vifState == VIF_BASE);
	align(4, 3);
	vifState = VIF_DIRECT;
	vifTag = ptr;
	add32(0);
}

void DmaMem::endDirect()
{
	int size;
	ASSERT(vifState == VIF_DIRECT);
	align(4);
	size = (ptr - vifTag - 1) / 4;
	if(size != 0)
		*vifTag = (0x50 << 24) + size;
	vifState = VIF_BASE;
}

void DmaMem::startAD()
{
	if(ptr >= endPtr)
	{
		endDirect();
		startDirect();
	}
	ADgifTag = ptr;
	add64((1<<15) + (1ULL<<60));
	add64(0xe);
}

void DmaMem::endAD()
{
}

void DmaMem::startMPG(int addr)
{
	ASSERT(vifState == VIF_BASE);
	align(2, 1);
	vifTag = ptr;
	add32((0x4a << 24) + addr);
	mpgCount = 0;
	mpgAddr = addr;
}

void DmaMem::endMPG()
{
	*vifTag += (mpgCount & 255) << 16;
}

void DmaMem::addMPG(u64 data)
{
	if(mpgCount >= 256)
	{
		ASSERT(mpgCount == 256);
		endMPG();
		startMPG(mpgAddr + mpgCount);
	}
	add64(data);
	mpgCount++;
}

void DmaMem::align(int align, int offset = 0)
{
	int p = (((int)ptr >> 2) - offset) & (align - 1);
	if(p == 0)
		return;
	for(p = align - p; p > 0; p--)
		add32(0);
}

void DmaMem::nextPage()
{
	vifState_t state = vifState;
	if(state == VIF_DIRECT)
		endDirect();
	ASSERT(vifState == VIF_BASE);
	*dmaTag = ((u64)getNewPage() << 32) + (2 << 28) + (ptr - (u32*)dmaTag) / 4 - 1;
	newTag();
	if(state == VIF_DIRECT)
		startDirect();
	ASSERT(vifState == state);
}

DynDma::DynDma()
{
	pageList = (Mem*)0;
	currentBuffer = 0;
	currentPage = 0;
}

DynDma::~DynDma()
{
	if(pageList != NULL)
		delete[] pageList;
}

void DynDma::init(int _numPages)
{
	int i;
	if(*EE_D1_CHCR & 256)
	{
		ASSERT(!"DMA 1 is already running, not good.");
		printf("DMA 1 is running, trying to stop it\n");
		*EE_D_ENABLEW = 1<<16;
		*EE_D1_CHCR = 0;
		*EE_D_ENABLEW = 0;
	}
	*EE_VIF1_ERR = 2;			// do not detect DMA mismatch
	numPages = _numPages;
	pageList = new Mem[numPages * 2];
	for(i = 0; i < numPages * 2; i++)
		sps2.getMem(&pageList[i], 256);
	open();
}

u32 DynDma::getNewPage()
{
	ASSERT(pageList != NULL);
	ASSERT(currentPage < numPages);
	ptr = (u32*)pageList[currentPage + currentBuffer * numPages].getCached();
	endPtr = ptr + 1024;
	return pageList[(currentPage++) + currentBuffer * numPages].getPhysical();
}

#include <unistd.h>

void DynDma::send(int disas)
{
	end();
	if(disas & 1)
	{
		DmaDisas disas;
		printf("disas: %x\n", physPtr);
		disas.start(physPtr);
	}
	if(disas & 2)
		exit(0);
	asm("sync.l");
	sps2.flushCache();
	
	while(*EE_D1_CHCR & 256);
	*EE_D1_QWC = 0;
	*EE_D1_TADR = physPtr & 0x8ffffff0;
	if(!(disas & 4))
		*EE_D1_CHCR = 0x145;
	asm("sync.l");
	currentPage = 0;
	currentBuffer ^= 1;
	open();
}

Mem &DynDma::getTempPage()
{
	return pageList[(currentBuffer ^ 1) * numPages];
}

StaticDma::StaticDma()
{
	pageList = (Mem*)0;
	currentPage = 0;
	m_pRefData = NULL;
}

StaticDma::~StaticDma()
{
	if(pageList != NULL)
		delete [] pageList;
}

void StaticDma::init(int _numPages)
{
	int i;
	numPages = _numPages;
	pageList = new Mem[numPages];
	for(i = 0; i < numPages; i++)
		sps2.getMem(&pageList[i], 256);
	open();
}

u32 StaticDma::getNewPage()
{
	u32 phys;
	ASSERT(pageList != NULL);
	ASSERT(currentPage < numPages);
	if(m_pRefData != NULL)
		addRefPage();
	ptr = (u32*)pageList[currentPage].getCached();
	endPtr = ptr + 1024;
	phys = pageList[(currentPage++)].getPhysical();
	physOffset = phys - (int)ptr;
	return phys;
}

u32 StaticDma::getPtr()
{
	return (int)dmaTag + physOffset;
}

RefData *StaticDma::startRefData()
{
	ASSERT(!"This has not been tested, yet.");
	m_pRefData = new RefData;
	add64(0);					// this will be replaced by the tte given to the transfer method
	return m_pRefData;
}

void StaticDma::endRefData()
{
	addRefPage();
	end();
	m_pRefData = NULL;
}

void StaticDma::addRefPage()
{
	m_pRefData->addPage(getPtr() + 16, (ptr - (u32*)dmaTag) / 4 - 1, ((u64*)dmaTag)[1]);
}

RefData::RefData()
{
	m_pPages = NULL;
}

RefData::~RefData()
{
	PageList *cur, *next;

	cur = m_pPages;
	while(cur != NULL)
	{
		next = cur->pNext;
		delete cur;
		cur = next;
	}
}

void RefData::addPage(u32 ptr, u32 qwc, u64 tte)
{
	PageList *cur, *page;

	page = new PageList;
	page->pNext = NULL;
	page->ptr = ptr;
	page->qwc = qwc;
	page->tte = tte;

	if(m_pPages == NULL)
		m_pPages = page;
	else
	{
		for(cur = m_pPages; cur->pNext != NULL; cur = cur->pNext);
		cur->pNext = page;
	}
}

void RefData::addToChain(DmaMem &dma, u64 tte)
{
	bool first = true;
	PageList *cur = m_pPages;

	while(cur != NULL)
	{
		dma.ref(cur->ptr, cur->qwc, first ? tte : cur->tte);
		cur = cur->pNext;
	}
}
