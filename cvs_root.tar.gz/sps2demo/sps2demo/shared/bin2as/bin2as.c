#include <stdio.h>
#include <assert.h>

int main(int argc, char *argv[])
{
	FILE *in;
	int x, c;
	assert(argc == 3);
	in = fopen(argv[2], "rb");
	assert(in != NULL);
	printf("\t.text\n\t.balign 16\n\t.global %s\n.word %s_end - %s, 0, 0, 0\n%s:",
			argv[1], argv[1], argv[1], argv[1]);
	x = 0;
	c = fgetc(in);
	while(c != EOF)
	{
		if(x == 0)
			printf("\n\t.byte ");
		else
			printf(", ");
		printf("0x%02x", c);
		x = ++x & 15;
		c = fgetc(in);
	}
	printf("\n%s_end:\n", argv[1]);
	fclose(in);
	return 0;
}
