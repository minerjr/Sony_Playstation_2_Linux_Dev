#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/vt.h>
#include <sys/stat.h>
#include <linux/kd.h>
#include <linux/ps2/dev.h>
#include "screen.h"
#include "signalhandler.h"
#include "sps2registers.h"
#include "debug.h"
#include <termios.h>

Screen screen;

termios g_saved_termios;
int g_saved_kbd_mode;

Screen::Screen()
{
	gsfd = -1;
	ttyfd = -1;
	eventfd = -1;
	currentBuffer = 0;
	crtmode = new ps2_crtmode;
	ASSERT(crtmode != NULL);
	old_screeninfo = new ps2_screeninfo;
	ASSERT(old_screeninfo != NULL);
}

Screen::~Screen()
{
	close();
	if(crtmode != NULL)
		delete crtmode;
	if(old_screeninfo != NULL)
		delete old_screeninfo;
}

#define vSYNCV(VS,VDP,VBPE,VBP,VFPE,VFP) \
	(((u64)(VS)<<53) | ((u64)(VDP)<<42) | ((u64)(VBPE)<<32) | \
	 ((u64)(VBP)<<20) | ((u64)(VFPE)<<10) | ((u64)(VFP)<<0))

void Screen::open()
{
	signalHandler.registerHandler(sigHandler);
	openTty();
	gsfd = ::open(PS2_DEV_GS, O_RDWR);
	eventfd = ::open(PS2_DEV_EVENT, O_RDWR);
	if(gsfd == -1 || eventfd == -1)
	{
		printf("Unable to open GS device\n");
		close();
		exit(1);
	}
	ioctl(eventfd, PS2IOC_ENABLEEVENT, PS2EV_VBSTART);
	ioctl(gsfd, PS2IOC_GSCREENINFO, old_screeninfo);
	switch(old_screeninfo->mode)
	{
		case PS2_GS_VESA:
			crtmode->mode = PS2_GS_VESA;
			crtmode->res = PS2_GS_640x480 | PS2_GS_60Hz;
			displayArea.dx = 272;
			displayArea.dy = 32;
			displayArea.magh = 1;
			displayArea.magv = 0;
			displayArea.dw = 1279;
			displayArea.dh = 479;
			break;
		case PS2_GS_PAL:
		case PS2_GS_NTSC:
			crtmode->mode = old_screeninfo->mode; //PS2_GS_NTSC;
			crtmode->res = PS2_GS_INTERLACE | PS2_GS_FIELD;
			displayArea.dx = 680;
			displayArea.dy = 70;
			displayArea.magh = 3;
			displayArea.magv = 0;
			displayArea.dw = 2553;
			displayArea.dh = 479;
			break;
		default:
			printf("Unknown current mode\n");
			close();
			exit(1);
			break;
	}
	ioctl(ttyfd, KDSETMODE, KD_GRAPHICS);
	ioctl(gsfd, PS2IOC_SCRTMODE, crtmode);
	if(old_screeninfo->mode == PS2_GS_PAL)
		DPUT_GS_SYNCV(vSYNCV(6,480,6,26,6,1));
	writePmode(1, 0, 1, 1, 0, 1, 255);
	writeDisplay1(displayArea.dx, displayArea.dy, displayArea.magh,
			displayArea.magv, displayArea.dw, displayArea.dh);
	writeBgcolor(0, 0, 0);
}

void Screen::close()
{
	if(ttyfd != -1)
	{
		ioctl(ttyfd, KDSETMODE, KD_TEXT);
	}
	if(gsfd != -1)
		ioctl(gsfd, PS2IOC_SSCREENINFO, old_screeninfo);
	if(eventfd != -1)
		::close(eventfd);
	if(gsfd != -1)
		::close(gsfd);
	closeTty();
}

void Screen::openTty()
{
	struct vt_mode vtm;
	struct stat sbuf;
	if(fstat(2, &sbuf) >= 0 &&
			ioctl(2, VT_GETMODE, &vtm) >= 0 &&
			(sbuf.st_rdev & 0xff00) == 0x400 &&
			sbuf.st_rdev & 0xff)
		ttyfd = 2;
	if(ttyfd == -1)
	{
		int m_console_fd;
		int err;
		int new_vc;
		struct vt_stat vts;
		char fname[256];
//		ASSERT(!"Unable to get graphic TTY\n");
		m_console_fd = ::open( "/dev/console", O_RDWR );

		if (m_console_fd<0)
		{
			ASSERT(!"Unable to open /dev/console");
		}

		err=ioctl(m_console_fd, VT_OPENQRY, &new_vc);
		::close(m_console_fd);
		if (err==-1)
		{
			ASSERT(!"ioctl(VT_OPENQRY)");
		}
		if (new_vc<=0)
		{
			ASSERT(!"ioctl(VT_OPENQRY) (wrong new_vc returned)");
		}

		sprintf(fname, "/dev/tty%d", new_vc);

		setpgid(0,getppid());
		setsid();

		ttyfd = ::open(fname, O_RDWR);
		ASSERT(ttyfd);

		ioctl(ttyfd, VT_GETSTATE, &vts);
		startup_vc=vts.v_active;

		ioctl(ttyfd, VT_ACTIVATE, new_vc);

		while (ioctl(ttyfd, VT_WAITACTIVE, new_vc) < 0)
		{
			if ((errno != EAGAIN) && (errno != EINTR))
			{
				ASSERT(!"ioctl(VT_WAITACTIVE)");
			}
			usleep(150000);
		}
	}
	
	// set tty to nonblocking for the keyboard input
	fcntl(screen.getTty(), F_SETFL, O_NONBLOCK);
}

void Screen::closeTty()
{
	if(ttyfd > 2)
	{
		ioctl(ttyfd, VT_ACTIVATE, startup_vc);
		::close(ttyfd);
	}
}

int Screen::sigHandler(int signal)
{
	screen.close();
	return 0;
}

void Screen::vblankWait()
{
	ioctl(eventfd, PS2IOC_GETEVENT, PS2EV_VBSTART);
	ioctl(eventfd, PS2IOC_WAITEVENT, PS2EV_VBSTART);
}

void Screen::flipBuffers()
{
	currentBuffer ^= 1;
	writeDispfb1(currentBuffer * 150, 10, 0, 0, 0);
}

void Screen::writeSmode2(int i, int ffmd, int dpms)
{
	DPUT_GS_SMODE2(i + (i << 1) + (i << 2));
}

void Screen::writeBgcolor(int r, int g, int b)
{
	DPUT_GS_BGCOLOR(r + (g << 8) + (b << 16));
}

void Screen::writeDispfb1(int fbp, int fbw, int psm, int dbx,
		int dby)
{
	DPUT_GS_DISPFB1(fbp + (fbw << 9) + (psm << 15) +
			((u64)dbx << 32) + ((u64)dby << 43));
}

void Screen::writeDispfb2(int fbp, int fbw, int psm, int dbx,
		int dby)
{
	DPUT_GS_DISPFB2(fbp + (fbw << 9) + (psm << 15) +
			((u64)dbx << 32) + ((u64)dby << 43));
}

void Screen::writeDisplay1(int dx, int dy, int magh, int magv,
		int dw, int dh)
{
	DPUT_GS_DISPLAY1(dx + (dy << 12) + (magh << 23) +
			(magv << 27) + ((u64)dw << 32) + ((u64)dh << 44));
}

void Screen::writeDisplay2(int dx, int dy, int magh, int magv,
		int dw, int dh)
{
	DPUT_GS_DISPLAY2(dx + (dy << 12) + (magh << 23) +
			(magv << 27) + ((u64)dw << 32) + ((u64)dh << 44));
}

void Screen::writePmode(int en1, int en2, int crtmd, int mmod, int amod,
		int slbg, int alp)
{
	DPUT_GS_PMODE(en1 + (en2 << 1) + (crtmd << 2) + (mmod << 5) +
			(amod << 6) + (slbg << 7) + (alp << 8));
}

