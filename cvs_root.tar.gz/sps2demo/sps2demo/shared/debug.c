#include <stdio.h>
#include "debug.h"

int printassert(const char *expr, const char *file, int line, const char *func)
{
	fprintf(stderr, "assertion in %s, %s:%d: %s\n", func, file, line, expr);
	exit(1);
	return 0;
}
