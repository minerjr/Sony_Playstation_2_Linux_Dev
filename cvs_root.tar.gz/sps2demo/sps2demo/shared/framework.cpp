#include "framework.h"
#include "sps2.h"
#include "screen.h"
#include "dma.h"
#include "signalhandler.h"
#include "sps2registers.h"
#include "joypadlib.h"
#include "screenshot.h"
#include <linux/ps2/dev.h>
#include <stdio.h>

Framework framework;

volatile bool Framework::m_end = false;

int Framework::sigHandler(int signal)
{
	if(m_end)
		return 0;
	m_end = true;
	return 1;
}

Framework::Framework()
{
	joypadlib_initialize();
	m_numpads = joypadlib_num_supported_joypads();
	for(int i = 0; i < m_numpads; i++)
		joypadlib_set_joypad_mode(i, MODE_ANALOG, MODE_LOCK);
	m_time = 0;
	m_timestep = 0;
	m_rastertime = false;
	m_dmaDisas = 0;
}

Framework::~Framework()
{
}

void Framework::init(int staticPages, int dynamicPages, int customPages)
{
	sps2.open();
	sps2.alloc(staticPages + dynamicPages * 2 + customPages);
	dynDma.init(dynamicPages);
	staticDma.init(staticPages);
	screen.open();
	signalHandler.registerHandler(sigHandler);

	m_noplist = staticDma.getPtr();
	staticDma.startDirect();
	for(int i = 0; i < 16; i++)
	{
		staticDma.add64(PS2_GIFTAG_SET_TOPHALF(1, 1, 1, 6, 0, 2));
		staticDma.add64(0x55);
		staticDma.add128(0);
		staticDma.add128(0);
	}
	staticDma.endDirect();
	staticDma.ret();
}

int sscnt = 3;

void Framework::mainloop(void (*callback)())
{
	while(!m_end)
	{
		m_timestep = 1.0f / 60.0f;
		updatePads();

		// init TRXPOS
		dynDma.startDirect();
		dynDma.startAD();
		dynDma.addAD(PS2_GS_TRXPOS, 0);
		dynDma.endAD();
		dynDma.endDirect();
		
		callback();
		
		dynDma.call(m_noplist);
		
		screen.writeBgcolor(255, 0, 0);
		sps2.waitForDma(1);
		while((*EE_VIF1_STAT & (3 | 8 | (31 << 24))));
		while((*EE_GIF_STAT & (0xfc0 | (31 << 24))));
		screen.writeBgcolor(0, 0, 0);

		if(getPad(0).isTriggered(PS2PAD_BUTTON_L1))
			screenshot();
		
		screen.vblankWait();
		screen.flipBuffers();

		if(m_rastertime)
			screen.writePmode(1, 0, 1, 1, 0, 1, 128);
		else
			screen.writePmode(1, 0, 1, 1, 0, 1, 255);
		
		dynDma.send(m_dmaDisas);

		m_time += m_timestep;
	}
}

void Framework::updatePads()
{
	int i;
	u32 b;
	joypadlib_update();
	for(i = 0; i < m_numpads; i++)
	{
		b = joypadlib_get_joypad_buttons(i, NULL, 0);
		m_pad[i].trg = b &~ m_pad[i].cnt;
		m_pad[i].cnt = b;
		joypadlib_get_joypad_sticks(i, m_pad[i].sticks, m_pad[i].sticks + 2);
	}
	if(m_pad[0].isTriggered(PS2PAD_BUTTON_SELECT))
		m_rastertime = !m_rastertime;
}
