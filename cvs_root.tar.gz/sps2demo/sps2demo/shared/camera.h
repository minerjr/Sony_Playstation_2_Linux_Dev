#ifndef CAMERA_H
#define CAMERA_H

#include "math.h"

class Camera
{
public:
	Camera();
	~Camera();
	void setSize(int w, int h) { width = w; height = h; }
	void setOffset(int x, int y) { xoffset = x; yoffset = y; }
	void setFrame(int b, int o, int w) { base = b; offset = o;
		bufferWidth = w; }
	void setZBuffer(int addr, int format = 10) { zbufAddr = addr; zbufFormat = format; }
	void setNearPlane(float f) { near = f; }
	void setFarPlane(float f) { far = f; }
	void setViewWindowSize(float size) { viewWindowSize = size; }
	void setAspectRatio(float ratio) { aspectRatio = ratio; }
	void setBgColor(int r, int g, int b) { bgr = r; bgg = g; bgb = b; }
	void init();
	void begin();
	void end();
	void setPosition(const Vector &pos)
		{ cameraMatrix.pos = pos; }
	Vector getPosition()
		{ return cameraMatrix.pos; }
	void lookDir(const Vector &at, const Vector &up);
	void lookAt(const Vector &poi, const Vector &up)
		{ lookDir(poi - getPosition(), up); }
	void freeCam();
	u64 getRegFrame() { return regFrame[currentBuffer]; }
protected:
	int width, height;
	int xoffset, yoffset;
	int base, offset, bufferWidth;
	int zbufAddr, zbufFormat;
	float near, far;
	float viewWindowSize, aspectRatio;
	int bgr, bgg, bgb;
	u32 cameraPacket[2];
	Matrix cameraMatrix;
	Matrix viewMatrix;
	float xrotate, yrotate;
	u64 regFrame[2];
	int currentBuffer;
};

#endif /* CAMERA_H */
