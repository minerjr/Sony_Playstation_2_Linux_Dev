#include "file.h"
#include "debug.h"
#include <stdio.h>

File::File()
{
	m_pFile = NULL;
}

File::File(const char *filename, const char *ext)
{
	m_pFile = NULL;
	open(filename, ext);
}

File::~File()
{
	if(m_pFile != NULL)
		fclose((FILE*)m_pFile);
}

void File::open(const char *filename, const char *ext)
{
	ASSERT(m_pFile == NULL);

	char tmp[256];
	if(ext != NULL)
		sprintf(tmp, "../data/%s.%s", filename, ext);
	else
		sprintf(tmp, "../data/%s", filename);
	m_pFile = fopen(tmp, "rb");

	if(m_pFile == NULL)
	{
		printf("Unable to open file '%s'\n", filename);
		exit(1);
	}
}

void File::close()
{
	ASSERT(m_pFile != NULL);

	fclose((FILE*)m_pFile);

	m_pFile = NULL;
}

void File::read(void *pBuffer, int nBytes)
{
	ASSERT(m_pFile != NULL);

	int read = fread(pBuffer, 1, nBytes, (FILE*)m_pFile);
	ASSERT(read == nBytes);
}
