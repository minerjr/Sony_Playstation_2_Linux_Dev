#ifndef FILE_H
#define FILE_H

class File
{
	public:
						File();
						File(const char *filename, const char *ext = (const char *)0);
						~File();
		void			open(const char *filename, const char *ext = (const char *)0);
		void			close();
		void			read(void *buffer, int nBytes);

	protected:

		void			*m_pFile;
};

#endif /* FILE_H */
