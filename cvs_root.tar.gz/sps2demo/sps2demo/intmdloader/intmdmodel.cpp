#include "intmdmodel.h"
#include "intmd/sceneintmd.h"
#include "vucode.h"
#include "vucamera.h"
#include "texture.h"
#include "intmdvu.h"
#include "dma.h"
#include "debug.h"
#include "texture/texture.h"
#include <linux/ps2/dev.h>
#include <stdio.h>

extern "C" u64 intmdrender_vu[];

VuCode *IntmdModel::m_vuCode = (VuCode*)0;

IntmdModel::IntmdModel()
{
	m_surfaceChains = NULL;
}

IntmdModel::~IntmdModel()
{
	if(m_surfaceChains != NULL)
		delete [] m_surfaceChains;
}

void IntmdModel::init(CSceneIntmd &scene, CMeshIntmd &mesh)
{
	if(m_vuCode == NULL)
		m_vuCode = vumanager.createVuCode(intmdrender_vu, INT_MAXVERTICES * 4);
	
	m_numSurfaces = mesh.GetNumSurfaces();
	m_surfaceChains = new u32[m_numSurfaces];
	m_surfaceTextures = new int[m_numSurfaces];
	for(int s = 0; s < m_numSurfaces; s++)
	{
		m_chunk = new Vertex[INT_MAXVERTICES];
		m_chunkIndex = 0;
		m_firstChunk = true;
		
		CSurfaceIntmd &surf = mesh.GetSurface(s);

		// find material
		CMaterialIntmd &mat = scene.GetMaterial(surf.GetMaterialIndex());
		CTextureSeqIntmd &tseq = mat.GetDiffTexture();

		if(tseq.GetNumTexFrames() == 0)
			m_surfaceTextures[s] = 0;
		else
		{
			CTextureIntmd &texture = scene.GetTexture(tseq.GetTexFrameIndex(0));
//			m_surfaceTextures[s] = new Texture;
//			createTexture(*m_surfaceTextures[s], texture);
			ASSERT(CreateTexture(texture, &m_surfaceTextures[s]));
		}
		
		m_surfaceChains[s] = staticDma.getPtr();
		staticDma.addFlush();
		staticDma.addStcycl(4, 1);

		for(int k = 0; k < surf.GetNumStrips(); k++)
		{
			CStripIntmd &strip = surf.GetStrip(k);

			for(int i = 0; i < strip.GetArrayLen(); i++)
			{
				int index = strip.GetIndex(i);
				Vector pos = Vector(surf.GetVertex(index).x,
						surf.GetVertex(index).y,
						-surf.GetVertex(index).z);
				Vector normal = Vector(surf.GetNormal(index).x,
						surf.GetNormal(index).y,
						-surf.GetNormal(index).z);
				Vector color = Vector(surf.GetTangent(index).x,
						surf.GetTangent(index).y,
						surf.GetTangent(index).z);
				addVertex(pos, normal, color * 255, surf.GetST(index).x,
						1.0f - surf.GetST(index).y, i >= 2);
			}
		}
		flushChunk();

		staticDma.addStcycl(1, 1);
		staticDma.ret();
	}

	delete [] m_chunk;
}

void IntmdModel::addVertex(Vector pos, Vector normal, Vector color, float u, float v, bool kickFlag)
{
	if(m_chunkIndex >= INT_MAXVERTICES)
		flushChunk();

	m_chunk[m_chunkIndex].pos = pos;
	m_chunk[m_chunkIndex].normal = normal;
	m_chunk[m_chunkIndex].color = color;
	m_chunk[m_chunkIndex].u = u;
	m_chunk[m_chunkIndex].v = v;
	m_chunk[m_chunkIndex].kickFlag = kickFlag;

	m_chunkIndex++;
}

void IntmdModel::flushChunk()
{
	int i;
	ASSERT(m_chunkIndex > 2);
	ASSERT(m_chunkIndex <= INT_MAXVERTICES);
	
	staticDma.addUnpack(V3_32, 0, m_chunkIndex, 1);
	for(i = 0; i < m_chunkIndex; i++)
		staticDma.addVector3(m_chunk[i].pos);

	staticDma.addUnpack(V4_32, 1, m_chunkIndex, 1);
	for(i = 0; i < m_chunkIndex; i++)
	{
		staticDma.addVector3(m_chunk[i].normal);
		staticDma.add32(m_chunk[i].kickFlag ? 0 : 0x8000);
	}

	staticDma.addUnpack(V3_32, 2, m_chunkIndex, 1);
	for(i = 0; i < m_chunkIndex; i++)
		staticDma.addVector3(m_chunk[i].color);

	staticDma.addUnpack(V2_32, 3, m_chunkIndex, 1);
	for(i = 0; i < m_chunkIndex; i++)
	{
		staticDma.addFloat(m_chunk[i].u);
		staticDma.addFloat(m_chunk[i].v);
	}

	staticDma.addItop(m_chunkIndex);

	if(m_firstChunk)
		staticDma.addMscalf(0);
	else
		staticDma.addMscnt();

	m_firstChunk = false;

	m_chunk[0] = m_chunk[m_chunkIndex - 2];
	m_chunk[1] = m_chunk[m_chunkIndex - 1];
	m_chunk[0].kickFlag = false;
	m_chunk[1].kickFlag = false;
	m_chunkIndex = 2;
}

int IntmdModel::log2(int v)
{
	int r = 0;
	while((1 << r) < v)
		r++;

	ASSERT((1 << r) == v);
	return r;
}

void IntmdModel::render(const Matrix &matrix)
{
	bool texture;
	m_vuCode->send();

	dynDma.addStcycl(1, 1);

	dynDma.addUnpack(V4_32, VU_INVMAT, 8);
	Matrix inv = matrix.lightMatrix();
	dynDma.addMatrix(inv);
	dynDma.addMatrix(matrix);

	// unpack lights
	dynDma.addUnpack(V3_32, INT_LIGHTS, 7);
	dynDma.addVector3(Vector(-0.25f, 0.5f, -0.5f));
	dynDma.addVector3(Vector(0.4f, 0.1f, -0.2f));
	dynDma.addVector3(Vector(0, -0.3, 0.4f));
	dynDma.addVector3(Vector(0.8f, 0.7f, 0.7f));
	dynDma.addVector3(Vector(0.7f, 0.8f, 0.7f));
	dynDma.addVector3(Vector(0.7f, 0.7f, 0.8f));
	dynDma.addVector3(Vector(0.3f, 0.3f, 0.3f));

	for(int s = 0; s < m_numSurfaces; s++)
	{
		dynDma.addFlush();

		texture = m_surfaceTextures[s] != 0;
		if(texture)
			UploadContext1(m_surfaceTextures[s]);
		dynDma.addUnpack(V4_32, VU_GIFTAG, 1);
		dynDma.add64(PS2_GIFTAG_SET_TOPHALF(1, 1, 1, 4+8+(texture ? 16 : 0), 0, 3));
		dynDma.add64(0x412UL);
		dynDma.call(m_surfaceChains[s]);
	}
}
