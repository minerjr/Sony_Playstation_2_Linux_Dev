#ifndef INTMDMODEL_H
#define INTMDMODEL_H

#include "math.h"

class CMeshIntmd;
class CSceneIntmd;
class VuCode;

class IntmdModel
{
public:
					IntmdModel();
					~IntmdModel();
	void			init(CSceneIntmd &scene, CMeshIntmd &mesh);
	void			render(const Matrix &matrix);
protected:
	void			addVertex(Vector pos, Vector normal, Vector color, float u, float v, bool kickFlag);
	void			flushChunk();
	int				log2(int v);
	int				m_numSurfaces;
	u32				*m_surfaceChains;
	int				*m_surfaceTextures;
	static VuCode	*m_vuCode;

	struct Vertex
	{
		Vector pos, normal, color;
		float u, v;
		bool kickFlag;
	}				*m_chunk;
	int				m_chunkIndex;
	bool			m_firstChunk;
};

#endif /* INTMDMODEL_H */
