#include "framework.h"
#include "camera.h"
#include "intmd/intmdloader.h"
#include "intmdmodel.h"
#include "math.h"
#include "glare.h"
#include "posteffecthelper.h"
#include "screen.h"
#include "blur.h"
#include "fadetogray.h"
#include "debug.h"

Camera camera;
IntmdModel *models;
int numModels;
int meshesFirstModel;
IntmdModel cameraModel;

float angle = 0;

FadeToGray *fadeToGrayFX;

void run()
{
	camera.freeCam();
	camera.begin();

	Matrix mat;
	mat.unitmatrix();
	for(int i = 0; i < numModels; i++)
	{
		if(i == meshesFirstModel)
		{
			mat.rotateY(angle);
			mat.scale(2.0f);
			mat.pos += Vector(0, 3, 0);
		}
		models[i].render(mat);
	}

	mat.unitmatrix();
	mat.scale(0.5f);
	mat.rotateY(angle*0.7f);
	mat.pos += Vector(4, 0, 8);
	cameraModel.render(mat);

	angle += 0.02f;
	
	camera.end();

	// posteffects

	fadeToGrayFX->render();
	
	glare(0.0f, 3, 1.0f, 1.0f, 0);
}

int main()
{
	framework.init(1024, 16, 512);
//	framework.setDmaDisas(3);	// disassemble, then exit
	camera.setBgColor(0, 0, 0);
	camera.setNearPlane(0.5f);
	camera.init();
	camera.setPosition(Vector(0, 1.5f, -3));

	CSceneCreatorIntmd scene;
	scene.LoadToScene("scene_test_white_polys.asc", "geomdata_test_white_polys.bin");
	CSceneCreatorIntmd scene2;
	scene2.LoadToScene("scene_puppet.asc", "geomdata_puppet.bin");
	CSceneCreatorIntmd scene3;
	scene3.LoadToScene("scene_cam_polys.asc", "geomdata_cam_polys.bin");

	meshesFirstModel = scene.GetSceneIntmd().GetNumMeshes();
	numModels = meshesFirstModel + scene2.GetSceneIntmd().GetNumMeshes();
	models = new IntmdModel[numModels];
	for(int i = 0; i < meshesFirstModel; i++)
		models[i].init(scene.GetSceneIntmd(), scene.GetSceneIntmd().GetMesh(i));
	for(int i = 0; i < scene2.GetSceneIntmd().GetNumMeshes(); i++)
		models[i + meshesFirstModel].init(scene2.GetSceneIntmd(), scene2.GetSceneIntmd().GetMesh(i));
	cameraModel.init(scene3.GetSceneIntmd(), scene3.GetSceneIntmd().GetMesh(0));

	fadeToGrayFX = new FadeToGray;
	
	framework.mainloop(run);
	
	return 0;
}
