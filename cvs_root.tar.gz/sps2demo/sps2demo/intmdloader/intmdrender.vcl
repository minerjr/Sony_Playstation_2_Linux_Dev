.include "../shared/vcl_sml.inc"
.include "../shared/vucamera.i"
.include "intmdvu.i"

.vu
.syntax new

--enter
	.init_vi_all
	.init_vf_all
--endenter

; setup
	MatrixLoad	cammat, VU_CAMMAT, vi0
	MatrixLoad	objmat, VU_OBJMAT, vi0
	MatrixMultiplyXYZ1	matrix, objmat, cammat
	MatrixLoad	invmat, VU_INVMAT, vi0

	lq			clipscale, VU_CLIPSCALE(vi0)
	lq			viewscale, VU_VIEWSCALE(vi0)
	mul.xy		viewscale, viewscale, clipscale

	lq			viewshift, VU_VIEWSHIFT(vi0)

	lq			clipvec, VU_CLIPVEC(vi0)

	iaddiu		obuf, vi0, INT_OUTBUFFER
	iaddiu		obuf2, obuf, (INT_MAXVERTICES * 3) + 1

; setup lights
	lq			lightvec0, (INT_LIGHTS+0)(vi0)
	lq			lightvec1, (INT_LIGHTS+1)(vi0)
	lq			lightvec2, (INT_LIGHTS+2)(vi0)
	MatrixMultiplyVector	lightvec0, invmat, lightvec0
	MatrixMultiplyVector	lightvec1, invmat, lightvec1
	MatrixMultiplyVector	lightvec2, invmat, lightvec2
	move		tmp1, lightvec1
	move		tmp2, lightvec2
	add.x		lightvec1, vf0, lightvec0[y]
	add.x		lightvec2, vf0, lightvec0[z]
	add.z		lightvec1, vf0, lightvec2[y]
	add.y		lightvec2, vf0, tmp1[z]
	add.y		lightvec0, vf0, tmp1[x]
	add.z		lightvec0, vf0, tmp2[x]

	lq			lightcol0, (INT_LIGHTS+3)(vi0)
	lq			lightcol1, (INT_LIGHTS+4)(vi0)
	lq			lightcol2, (INT_LIGHTS+5)(vi0)
	lq			lightcol3, (INT_LIGHTS+6)(vi0)

	iaddiu		kickmask, vi0, H'4000
	iaddiu		kickmask, kickmask, H'4000
	fcset		0

	iaddiu		alpha, vi0, 128
	mfir.w		color, alpha

	loi			255
	add.xyz		colorclamp, vf0, i

outer:
	xitop		vnum
	xtop		iptr
	iadd		iend, vnum, vnum
	iadd		iend, iend, iend
	iadd		iend, iend, iptr

	iaddiu		optr, obuf, 1
	lq			giftag, VU_GIFTAG(vi0)
	sq.yzw		giftag, 0(obuf)
	iaddiu		vnum, vnum, H'4000
	iaddiu		vnum, vnum, H'4000
	isw.x		vnum, 0(obuf)
	add.z		uv, vf0, vf0[w]

loop:
--loopCS 1,0
	lqi			pos, (iptr++)
	lqi			normal, (iptr++)
	lqi.xyz		color, (iptr++)
	lqi.xy		uv, (iptr++)

	MatrixMultiplyVertexXYZ1	pos, matrix, pos
	mul.xy		pos, pos, viewscale
	
	add.z		acc, vf0, clipvec[w]
	madd.z		clippos, clipvec, pos
	mul.xy		clippos, clipvec, pos
	mul.w		clippos, vf0, pos[z]
	clipw.xyz	clippos, clippos
	fcand		vi1, 0b111111111111111111
	iaddiu		vi1, vi1, H'7fff
;	iand		vi1, vi1, kickmask
	mtir		kickflag, normal[w]
	ior			vi1, vi1, kickflag
	mfir.w		opos, vi1
	
	div			q, vf0[w], pos[z]
	add.z		pos, vf0, vf0[w]
	mul			pos, pos, q
	mul.z		pos, pos, viewscale
	add			pos, pos, viewshift
	ftoi4.xyz	opos, pos

	mul.xyz		stq, uv, q

	mul			acc, lightvec0, normal[x]
	madd		acc, lightvec1, normal[y]
	madd		dots, lightvec2, normal[z]
	max			dots, dots, vf0[x]
	mul			acc, lightcol0, dots[x]
	madd		acc, lightcol1, dots[y]
	madd		acc, lightcol2, dots[z]
	madd.xyz	light, lightcol3, vf0[w]
	mul.xyz		color, color, light
	mini.xyz	color, color, colorclamp
	ftoi0.xyz	color, color

	sqi.yxz		stq, (optr++)	; uv
	sqi			color, (optr++)
	sqi			opos, (optr++)
	ibne		iptr, iend, loop
	
	xgkick		obuf
	iadd		tmp, vi0, obuf
	iadd		obuf, vi0, obuf2
	iadd		obuf2, vi0, tmp
--cont
	b		outer

.END
