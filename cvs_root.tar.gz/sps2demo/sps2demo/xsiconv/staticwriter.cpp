#include "staticwriter.h"
#include "outputstream.h"
#include "xsireader.h"
#include <stdio.h>

void writeStatic(const XSIReader &xsi, const char *path, int batchSize)
{
	StaticWriter wrt(path, batchSize);
	wrt.write(xsi);
}

StaticWriter::StaticWriter(const char *path, int batchSize)
{
	m_batchSize = batchSize;
	m_pPath = path;
	m_batch = new BatchElement[batchSize];
}

StaticWriter::~StaticWriter()
{
	delete [] m_batch;
}

void StaticWriter::write(const XSIReader &xsi)
{
	m_pXSI = &xsi;
	
	const XSIModel *pModel = xsi.getModels();

	while(pModel != NULL)
	{
		processModel(pModel);
		
		pModel = pModel->getNext();
	}
}

void StaticWriter::processModel(const XSIModel *pModel)
{
	if((pModel->isNull() && pModel->getModels() != NULL) || pModel->getMesh() != NULL)
		writeModelRoot(pModel);
	else
	{
		const XSIModel *pCur;
		pCur = pModel->getModels();
		while(pCur != NULL)
		{
			processModel(pCur);
			pCur = pCur->getNext();
		}
	}
}

void StaticWriter::writeModelRoot(const XSIModel *pModel)
{
	char name[256];
	sprintf(name, "%s%s.mdl", m_pPath, pModel->getName());
	printf("write model: %s\n", pModel->getName());
	m_numTriangles = 0;
	m_numStrips = 0;

	m_pOutputStream = new OutputStream(name);

	m_pOutputStream->add32(countLists(pModel));

	Matrix mat;
	mat.unitmatrix();
	writeModel(pModel, mat, true);

	printf("numTriangles: %d, numStrips: %d\n", m_numTriangles, m_numStrips);
	printf("Average strip length: %f\n", (float)m_numTriangles / m_numStrips);

	delete m_pOutputStream;
}

int StaticWriter::countLists(const XSIModel *pModel)
{
	int count = 0;
	const XSIModel *pCur = pModel->getModels();

	while(pCur != NULL)
	{
		count += countLists(pCur);
		
		pCur = pCur->getNext();
	}

	const XSIMesh *mesh = pModel->getMesh();

	if(mesh != NULL)
		count += mesh->getNumStripLists();

	return count;
}

void StaticWriter::writeModel(const XSIModel *pModel, const Matrix &mat, bool root)
{
	Matrix matrix = mat;

	if(!root)
		matrix = pModel->getMatrix();
	
	const XSIMesh *mesh = pModel->getMesh();

	if(mesh != NULL)
	{
		Matrix normalMat = matrix;
		normalMat.pos = Vector(0, 0, 0);
		normalMat.x *= 1.0f /normalMat.x.getSquareLength();
		normalMat.y *= 1.0f /normalMat.y.getSquareLength();
		normalMat.y *= 1.0f /normalMat.y.getSquareLength();
		
		const XSIShape *shape = mesh->getShape();
		const XSIStripList *slist = mesh->getStripLists();
		while(slist != NULL)
		{
			const char *pTextureName = findTexture(slist->getMaterialName());
			m_pOutputStream->addString(pTextureName);
			m_colorScale = (*pTextureName != 0) ? 128 : 255;
			
			m_elements = slist->getElements();
			m_firstBatch = true;
			m_batchPos = 0;
			m_stream = new MemoryStream;

			Vector pos, normal, color, uv0;

			color = Vector(1, 1, 1, 1);

			for(int i = 0; i < slist->getNumStrips(); i++)
			{
				const XSIStrip *strip = slist->getStrip(i);

				m_numStrips++;
				m_numTriangles += strip->getLength() - 2;

				for(int j = 0; j < strip->getLength(); j++)
				{
					if(m_elements & POSITION)
						pos = shape->getPosition(strip->getPosition(j));
					if(m_elements & NORMAL)
						normal = shape->getNormal(strip->getNormal(j));
					if(m_elements & COLOR)
						color = shape->getColor(strip->getColor(j));
					if(m_elements & TEX_COORD_UV0)
						uv0 = shape->getUV0(strip->getUV0(j));

					pos = matrix * pos;
					normal = normalMat * normal;
					normal.normalize();
					addToBatch(pos, normal, color, uv0, j < 2);
				}
			}

			flushBatch();
			m_pOutputStream->addMemoryStream(*m_stream);
			delete m_stream;
			
			slist = slist->getNext();
		}
	}

	const XSIModel *pCur = pModel->getModels();
	while(pCur != NULL)
	{
		writeModel(pCur, matrix);
		pCur = pCur->getNext();
	}
}

void StaticWriter::addToBatch(const Vector &pos, const Vector &normal,
		const Vector &color, const Vector &uv0, bool adc)
{
	m_batch[m_batchPos].pos = pos;
	m_batch[m_batchPos].normal = normal;
	m_batch[m_batchPos].color = color;
	m_batch[m_batchPos].uv0 = uv0;
	m_batch[m_batchPos].adc = adc;
	m_batchPos++;
	if(m_batchPos >= m_batchSize)
		flushBatch();
}

void StaticWriter::flushBatch()
{
	if(m_batchPos <= 2)
		return;

	if(m_elements & POSITION)
	{
		m_stream->addUnpack(V3_32, 0, m_batchPos, 1);
		for(int i = 0; i < m_batchPos; i++)
			m_stream->addVector3(m_batch[i].pos);
	}

	if(m_elements & NORMAL)
	{
		m_stream->addUnpack(V4_5, 1, m_batchPos, 1);
		for(int i = 0; i < m_batchPos; i++)
		{
			int x = (int)(m_batch[i].normal.x * 15.9f) + 16;
			int y = (int)(m_batch[i].normal.y * 15.9f) + 16;
			int z = (int)(m_batch[i].normal.z * 15.9f) + 16;
			m_stream->add16(x + y * 32 + z * 1024 +
					(m_batch[i].adc ? 0x8000 : 0));
		}
	}
	m_stream->align();

	if(true || m_elements & COLOR)
	{
		m_stream->addUnpack(V4_5, 2, m_batchPos, 1);
		for(int i = 0; i < m_batchPos; i++)
		{
			int r = (int)(m_batch[i].color.x * m_colorScale / 8);
			int g = (int)(m_batch[i].color.x * m_colorScale / 8);
			int b = (int)(m_batch[i].color.x * m_colorScale / 8);
			m_stream->add16(r + g * 32 + b * 1024);
		}
	}
	m_stream->align();

	if(m_elements & TEX_COORD_UV0)
	{
		m_stream->addUnpack(V2_32, 3, m_batchPos, 1);
		for(int i = 0; i < m_batchPos; i++)
		{
			m_stream->addFloat(m_batch[i].uv0.x);
			m_stream->addFloat(1.0f - m_batch[i].uv0.y);
		}
	}

	m_stream->addItop(m_batchPos);

	if(m_firstBatch)
		m_stream->addMscalf(0);
	else
		m_stream->addMscnt();

	m_firstBatch = false;

	m_batch[0] = m_batch[m_batchPos - 2];
	m_batch[1] = m_batch[m_batchPos - 1];
	m_batch[0].adc = true;
	m_batch[1].adc = true;

	m_batchPos = 2;
}

const char *StaticWriter::findTexture(const char *name)
{
	const XSIMaterial *mat = m_pXSI->findMaterial(name);

	if(mat != NULL && mat->getTexture() != NULL)
	{
		const XSIImage *im = m_pXSI->findImage(mat->getTexture());
		if(im != NULL)
		{
			return im->getFilename();
		}
	}

	return "";
}
