#include "xsireader.h"
#include "staticwriter.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char *argv[])
{
	if(argc != 4)
	{
		printf("blah, usage, blah\n");
		return 1;
	}
	XSIReader xsi;
	
	xsi.readXSI(argv[1]);

	writeStatic(xsi, argv[2], atoi(argv[3]));
	
	return 0;
}
