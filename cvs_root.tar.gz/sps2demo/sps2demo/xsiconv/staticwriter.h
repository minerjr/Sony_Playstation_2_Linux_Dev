#ifndef STATICWRITER_H
#define STATICWRITER_H

#include "math.h"

class XSIReader;
class XSIModel;
class MemoryStream;
class OutputStream;

void writeStatic(const XSIReader &xsi, const char *path, int batchSize);

class StaticWriter
{
	public:
					StaticWriter(const char *path, int batchSize);
					~StaticWriter();
		void		write(const XSIReader &xsi);
	
	protected:

		void		processModel(const XSIModel *pModel);
		int			countLists(const XSIModel *pModel);
		void		writeModelRoot(const XSIModel *pModel);
		void		writeModel(const XSIModel *pModel, const Matrix &mat, bool root = false);
		void		addToBatch(const Vector &pos, const Vector &normal,
				const Vector &color, const Vector &uv0, bool adc);
		void		flushBatch();
		const char	*findTexture(const char *name);

		struct	BatchElement
		{
			Vector	pos;
			Vector	normal;
			Vector	color;
			Vector	uv0;
			bool	adc;
		}			*m_batch;
		int			m_batchPos;
		int			m_batchSize;
		int			m_elements;
		bool		m_firstBatch;
		float		m_colorScale;
		const char	*m_pPath;
		int			m_numTriangles;
		int			m_numStrips;
		const XSIReader	*m_pXSI;
		MemoryStream	*m_stream;
		OutputStream	*m_pOutputStream;
};

#endif /* STATICWRITER_H */
