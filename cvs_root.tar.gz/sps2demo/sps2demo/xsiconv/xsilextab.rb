#!/usr/bin/env ruby

class State
	@@state_hash = {}
	@@states = []
	@@tokens = []

	attr_reader :index

	def initialize(name, transitions, default)
		@index = @@states.size
		@@states.push(self)
		@@state_hash[name] = self

		@name = name
		@transitions = transitions
		@default = default

		(transitions.values << default).each do |action|
			next unless action.kind_of? Array
			state = action[1].to_s
			@@tokens.push(state) if state.upcase == state
		end
	end

	def binaction(action)
		return binaction([action, @name]) unless action.kind_of? Array

		state = action[1]
		if state.to_s.upcase == state.to_s
			state = @@tokens.index(state.to_s) | 0x20
		else
			state = @@state_hash[state].index
		end
		
		case action[0]
		when :add
			state += 0x40
		when :back
			state += 0x80
		end
		
		return state
	end

	def write(file)
		file.puts "\t{\n"

		table = binaction(@default).chr * 256
		@transitions.each_pair do |chars, action|
			action = binaction(action)
			chars.each_byte {|c| table[c] = action}
		end

		(0...256).step(16) do |y|
			file.write "\t\t"
			(y...y+16).each do |x|
				file.printf "0x%02x, ", table[x]
			end
			file.puts
		end

		file.puts "\t},\n"
	end

	def State.dump(filename)
		File.open(filename, "w") do |f|
			define = filename.upcase.tr('.', '_')
			f.printf "#ifndef %s\n#define %s\n\n", define, define

			@@tokens.uniq!
			@@tokens.size.times do |i|
				f.printf "#define %s %d\n", @@tokens[i], i
			end

			f.puts
			f.puts "#define ACTION_MASK 0xc0"
			f.puts "#define ACTION_SKIP 0x00"
			f.puts "#define ACTION_ADD  0x40"
			f.puts "#define ACTION_BACK 0x80"
			f.puts
			f.puts "#define STATE_OR_TOKEN 0x20"
			f.puts "#define STATE 0x00"
			f.puts "#define TOKEN 0x20"
			f.puts

			f.printf "const unsigned char statemachine[%d][256] = {\n", @@states.size
			@@states.each {|s| s.write(f)}
			f.printf "};\n\n"

			f.printf "#endif // %s\n", define
		end
	end
end

SPACE = " \n\r\t"
IDENT = ('a'..'z').to_a.join + ('A'..'Z').to_a.join
NUM = ('0'..'9').to_a.join

State.new(:null, {
		SPACE 				=> :skip,
		IDENT 				=> [:add, :identifier],
		'"'					=> [:skip, :string],
		'-'					=> [:add, :minus],
		NUM					=> [:add, :numeric]
	},						[:add, :CHAR])

State.new(:identifier, {
		IDENT+NUM+"_-."		=> :add
	},						[:back, :IDENTIFIER])

State.new(:string, {
		'"'					=> [:skip, :STRING]
	},						:add)

State.new(:minus, {
		NUM					=> [:add, :numeric]
	},						[:back, :CHAR])

State.new(:numeric, {
		NUM					=> :add,
		'.'					=> [:add, :float]
	},						[:back, :INTEGER])

State.new(:float, {
		NUM					=> :add
	},						[:back, :FLOAT])

State.dump("xsilextab.h")
