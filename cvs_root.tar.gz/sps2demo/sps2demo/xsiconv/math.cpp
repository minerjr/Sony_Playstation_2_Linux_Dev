#include "math.h"
#include <stdio.h>

void Vector::print()
{
	printf("%f, %f, %f, %f\n", x, y, z, w);
}

Matrix Matrix::invert() const
{
	Matrix r;
	r.x.x = x.x; r.x.y = y.x; r.x.z = z.x;
	r.y.x = x.y; r.y.y = y.y; r.y.z = z.y;
	r.z.x = x.z; r.z.y = y.z; r.z.z = z.z;
	r.pos.x = -x.dot(pos);
	r.pos.y = -y.dot(pos);
	r.pos.z = -z.dot(pos);
	return r;
}

Matrix Matrix::lightMatrix() const
{
	Matrix r = *this;
	r.x.normalize();
	r.y.normalize();
	r.z.normalize();
	return r.invert();
}

void Matrix::rotateX(float a)
{
	float s, c;
	float t;
	s = sinf(a);
	c = cosf(a);
	t = c * x.y + s * x.z;
	x.z = c * x.z - s * x.y;
	x.y = t;
	t = c * y.y + s * y.z;
	y.z = c * y.z - s * y.y;
	y.y = t;
	t = c * z.y + s * z.z;
	z.z = c * z.z - s * z.y;
	z.y = t;
	t = c * pos.y + s * pos.z;
	pos.z = c * pos.z - s * pos.y;
	pos.y = t;
}

void Matrix::rotateY(float a)
{
	float s, c;
	float t;
	s = sinf(a);
	c = cosf(a);
	t = c * x.x + s * x.z;
	x.z = c * x.z - s * x.x;
	x.x = t;
	t = c * y.x + s * y.z;
	y.z = c * y.z - s * y.x;
	y.x = t;
	t = c * z.x + s * z.z;
	z.z = c * z.z - s * z.x;
	z.x = t;
	t = c * pos.x + s * pos.z;
	pos.z = c * pos.z - s * pos.x;
	pos.x = t;
}

void Matrix::rotateZ(float a)
{
	float s, c;
	float t;
	s = sinf(a);
	c = cosf(a);
	t = c * x.y - s * x.x;
	x.x = c * x.x + s * x.y;
	x.y = t;
	t = c * y.y - s * y.x;
	y.x = c * y.x + s * y.y;
	y.y = t;
	t = c * z.y - s * z.x;
	z.x = c * z.x + s * z.y;
	z.y = t;
	t = c * pos.y - s * pos.x;
	pos.x = c * pos.x + s * pos.y;
	pos.y = t;
}

void Matrix::unitmatrix()
{
	x.x = 1.0f; x.y = 0.0f; x.z = 0.0f; x.w = 0.0f;
	y.x = 0.0f; y.y = 1.0f; y.z = 0.0f; y.w = 0.0f;
	z.x = 0.0f; z.y = 0.0f; z.z = 1.0f; z.w = 0.0f;
	pos.x = 0.0f; pos.y = 0.0f; pos.z = 0.0f; pos.w = 0.0f;
}

void Matrix::scale(float scale)
{
	x = x * scale;
	y = y * scale;
	z = z * scale;
}

Matrix &Matrix::operator*=(const Matrix &m)
{
	x = m.x * x.x + m.y * x.y + m.z * x.z;
	y = m.x * y.x + m.y * y.y + m.z * y.z;
	z = m.x * z.x + m.y * z.y + m.z * z.z;
	pos = m.x * pos.x + m.y * pos.y + m.z * pos.z + m.pos;
	
	return *this;
}
