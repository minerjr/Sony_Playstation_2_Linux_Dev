#include "xsilex.h"
#include "xsilextab.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

XSILex::XSILex(const char *filename)
{
	m_file = (void*)fopen(filename, "r");
	assert(m_file != NULL);

	m_type = 0;
	m_fetchNew = true;
	m_charsInBuffer = 0;
	m_posInBuffer = 0;
	m_inputBuffer = new char[INPUT_BUFFER_SIZE];
}

XSILex::~XSILex()
{
	if(m_file != NULL)
		fclose((FILE*)m_file);
}

int XSILex::getC()
{
	if(m_posInBuffer >= m_charsInBuffer)
	{
		m_charsInBuffer = fread(m_inputBuffer, 1, INPUT_BUFFER_SIZE, (FILE*)m_file);

		if(m_charsInBuffer == 0)
			return EOF;
		
		m_posInBuffer = 0;
	}
	return m_inputBuffer[m_posInBuffer++];
}

void XSILex::ungetC()
{
	if(m_posInBuffer > 0)
		m_posInBuffer--;
}

void XSILex::nextToken()
{
	int index = 0;
	int state = 0;
	int c;
	int action;

	m_fetchNew = false;
	
	if(m_file == NULL)
	{
		m_token[0] = 0;
		m_type = 0;
		return;
	}

	while(1)
	{
		assert(m_file != NULL);
		c = getC();
		if(c == EOF)
		{
			fclose((FILE*)m_file);
			m_file = NULL;
			c = 0;
		}

		action = statemachine[state][c];
		
		switch(action & ACTION_MASK)
		{
			case ACTION_SKIP:
				break;
			case ACTION_ADD:
				assert(index < 255);
				m_token[index++] = c;
				break;
			case ACTION_BACK:
				if(m_file != NULL)
					ungetC();
				break;
		}

		if((action & STATE_OR_TOKEN) == TOKEN)
		{
			m_token[index] = 0;
			m_type = action & 0x1f;
			return;
		}

		state = action & 0x1f;
	}
}

void XSILex::fetchToken()
{
	if(m_fetchNew)
		nextToken();
}

bool XSILex::isType(int type)
{
	fetchToken();
	if(m_type == type)
		m_fetchNew = true;
	return m_fetchNew;
}

bool XSILex::isEnd()
{
	return isChar(0);
}

bool XSILex::isChar()
{
	return isType(CHAR);
}

bool XSILex::isIdentifier()
{
	return isType(IDENTIFIER);
}

bool XSILex::isString()
{
	return isType(STRING);
}

bool XSILex::isInt()
{
	return isType(INTEGER);
}

bool XSILex::isFloat()
{
	return isType(FLOAT);
}

bool XSILex::isChar(char value)
{
	if(isChar() && getChar() != value)
		m_fetchNew = false;
	return m_fetchNew;
}

bool XSILex::isIdentifier(const char *id)
{
	if(isIdentifier() && strcmp(getIdentifier(), id) != 0)
		m_fetchNew = false;
	return m_fetchNew;
}

bool XSILex::isString(const char *string)
{
	if(isString() && strcmp(getString(), string) != 0)
		m_fetchNew = false;
	return m_fetchNew;
}

void XSILex::expectType(int type)
{
	if(!isType(type))
	{
		printf("Type %d expected, type %d (%s) found\n", type, m_type, m_token);
		exit(1);
	}
}

char XSILex::expectChar()
{
	expectType(CHAR);
	return getChar();
}

const char *XSILex::expectIdentifier()
{
	expectType(IDENTIFIER);
	return getIdentifier();
}

const char *XSILex::expectString()
{
	expectType(STRING);
	return getString();
}

int XSILex::expectInt()
{
	expectType(INTEGER);
	return getInt();
}

float XSILex::expectFloat()
{
	expectType(FLOAT);
	return getFloat();
}

void XSILex::expectChar(char value)
{
	if(expectChar() != value)
	{
		printf("char '%c' expected\n", value);
		exit(1);
	}
}

void XSILex::expectIdentifier(const char *string)
{
	if(strcmp(expectIdentifier(), string) != 0)
	{
		printf("identifier \"%s\" expected\n", string);
		exit(1);
	}
}

void XSILex::expectString(const char *string)
{
	if(strcmp(expectString(), string) != 0)
	{
		printf("string \"%s\" expected\n", string);
		exit(1);
	}
}

char XSILex::getChar()
{
	assert(m_type == CHAR);
	return m_token[0];
}

const char *XSILex::getIdentifier()
{
	assert(m_type == IDENTIFIER);
	return m_token;
}

const char *XSILex::getString()
{
	assert(m_type == STRING);
	return m_token;
}

int XSILex::getInt()
{
	assert(m_type == INTEGER);
	return atoi(m_token);
}

float XSILex::getFloat()
{
	assert(m_type == FLOAT);
	return atof(m_token);
}

int XSILex::readInt()
{
	int result = expectInt();
	isChar(',');
	return result;
}

float XSILex::readFloat()
{
	float result = expectFloat();
	isChar(',');
	return result;
}

char *XSILex::readString()
{
	char *result = strdup(expectString());
	isChar(',');
	return result;
}

Vector XSILex::readVector()
{
	float x, y, z;
	x = readFloat();
	y = readFloat();
	z = readFloat();
	return Vector(x, y, z);
}

void XSILex::skipSection()
{
	int depth;
	
	printf("Skipping section '%s'", expectIdentifier());
	if(isIdentifier())
		printf(" (%s)", getIdentifier());
	printf("\n");
	expectChar('{');
	
	depth = 1;
	while(depth > 0)
	{
		if(isChar('{'))
			depth++;
		else if(isChar('}'))
			depth--;
		else
			nextToken();
	}
}
