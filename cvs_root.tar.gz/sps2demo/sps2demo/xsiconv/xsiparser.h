#ifndef XSIPARSER_H
#define XSIPARSER_H

enum XSISection
{
	SI_Ambience,
	SI_Angle,
	SI_Camera,
	SI_CoordinateSystem,
	SI_FileInfo,
	SI_GlobalMaterial,
	SI_Light,
	SI_MaterialLibrary,
	SI_Mesh,
	SI_Model,
	SI_Null,
	SI_Scene,
	SI_Shape,
	SI_Transform,
	SI_TriangleList,
	SI_TriStrip,
	SI_TriStripList,
	SI_Visibility,
	XSI_CustomPSet,
	XSI_Image,
	XSI_ImageFX,
	XSI_ImageLibrary,
	XSI_Material,
	XSI_MaterialInfo,
	XSI_Shader,
	NUM_SECTIONS
};

class XSIParser
{
	public:
						XSIParser();
						~XSIParser();
		void			open(const char *filename);
		bool			endOfFile();
		void			close();
		XSISection		readSection();
		const char		*getSectionName() const { return m_pSectionName; }
		void			skipSection();
		void			endSection();
		bool			endOfSection();
		int				readInt();
		float			readFloat();
		const char		*readString();
		void			expectString(const char *string);

	protected:

		void			skipWS();
		void			readIdentifier();
		void			*m_pFile;
		XSISection		m_lastSection;
		char			*m_pSectionName;
		char			m_Buffer[1024];
		static char		m_WS[256];
		static const char *m_Sections[];
};

extern XSIParser gXSI;

#endif /* XSIPARSER_H */
