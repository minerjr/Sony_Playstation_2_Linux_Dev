#ifndef XSILEX_H
#define XSILEX_H

#include "math.h"

class XSILex
{
public:
				XSILex(const char *file);
				~XSILex();

	void		nextToken();
	bool		isEnd();
	bool		isChar();
	bool		isIdentifier();
	bool		isString();
	bool		isInt();
	bool		isFloat();
	bool		isChar(char value);
	bool		isIdentifier(const char *id);
	bool		isString(const char *string);
	char		expectChar();
	const char	*expectIdentifier();
	const char	*expectString();
	int			expectInt();
	float		expectFloat();
	void		expectChar(char value);
	void		expectIdentifier(const char *string);
	void		expectString(const char *string);
	char		getChar();
	const char	*getIdentifier();
	const char	*getString();
	int			getInt();
	float		getFloat();

	int			readInt();
	float		readFloat();
	char		*readString();
	Vector		readVector();

	void		skipSection();
	
protected:

	void		fetchToken();
	bool		isType(int type);
	void		expectType(int type);
	int			getC();
	void		ungetC();

	enum {
		INPUT_BUFFER_SIZE = 1024*16,
	};

	void		*m_file;
	char		*m_inputBuffer;
	int			m_charsInBuffer;
	int			m_posInBuffer;
	char		m_token[256];
	int			m_type;
	bool		m_fetchNew;
};

#endif // XSILEX_H
