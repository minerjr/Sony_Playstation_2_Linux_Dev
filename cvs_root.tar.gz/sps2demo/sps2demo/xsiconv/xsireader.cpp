#include "xsireader.h"
#include "xsiparser.h"
#include <string.h>
#include <stdio.h>
#include <malloc.h>

/**************************************
 *
 * Root
 *
 **************************************/

XSIReader::XSIReader()
{
	m_pModels = NULL;
	m_pMaterials = NULL;
	m_pImages = NULL;
}

XSIReader::~XSIReader()
{
	{
		const XSIModel *pCur, *pNext;
		pCur = m_pModels;
		while(pCur != NULL)
		{
			pNext = pCur->getNext();
			delete pCur;
			pCur = pNext;
		}
	}

	{
		const XSIMaterial *pCur, *pNext;
		pCur = m_pMaterials;
		while(pCur != NULL)
		{
			pNext = pCur->getNext();
			delete pCur;
			pCur = pNext;
		}
	}

	{
		const XSIImage *pCur, *pNext;
		pCur = m_pImages;
		while(pCur != NULL)
		{
			pNext = pCur->getNext();
			delete pCur;
			pCur = pNext;
		}
	}
}

void XSIReader::readXSI(const char *filename)
{
	gXSI.open(filename);

	while(!gXSI.endOfFile())
	{
		switch(gXSI.readSection())
		{
			case SI_Model:
				m_pModels = new XSIModel(m_pModels);
				break;

			case SI_MaterialLibrary:
				gXSI.readInt();
				while(!gXSI.endOfSection())
				{
					switch(gXSI.readSection())
					{
						case XSI_Material:
							m_pMaterials = new XSIMaterial(m_pMaterials);
							break;

						default:
							gXSI.skipSection();
							break;
					}
				}
				break;
				
			case XSI_ImageLibrary:
				gXSI.readInt();
				while(!gXSI.endOfSection())
				{
					switch(gXSI.readSection())
					{
						case XSI_Image:
							m_pImages = new XSIImage(m_pImages);
							break;

						default:
							gXSI.skipSection();
							break;
					}
				}
				break;

			default:
				gXSI.skipSection();
				break;
		}
	}

	gXSI.close();
}

const XSIMaterial *XSIReader::findMaterial(const char *name) const
{
	const XSIMaterial *pCur = m_pMaterials;

	while(pCur != NULL && strcmp(pCur->getName(), name) != 0)
		pCur = pCur->getNext();

	return pCur;
}

const XSIImage *XSIReader::findImage(const char *name) const
{
	const XSIImage *pCur = m_pImages;

	while(pCur != NULL && strcmp(pCur->getName(), name) != 0)
		pCur = pCur->getNext();

	return pCur;
}

/**************************************
 *
 * Model
 *
 **************************************/

XSIModel::XSIModel(const XSIModel *pNext)
{
	m_pNext = pNext;

	m_pMesh = NULL;
	m_pModels = NULL;
	m_isNull = false;
	m_matrix.unitmatrix();
	
	const char *pName = gXSI.getSectionName();
	if(strncmp(pName, "MDL-", 4) == 0)
		m_pName = strdup(pName + 4);
	else
		m_pName = strdup(pName);
	printf("Reading Model '%s'\n", m_pName);

	while(!gXSI.endOfSection())
	{
		switch(gXSI.readSection())
		{
			case SI_Mesh:
				m_pMesh = new XSIMesh();
				break;

			case SI_Model:
				m_pModels = new XSIModel(m_pModels);
				break;

			case SI_Null:
				m_isNull = true;
				gXSI.endSection();
				break;

			case SI_Transform:
				m_matrix.scaleX(gXSI.readFloat());
				m_matrix.scaleY(gXSI.readFloat());
				m_matrix.scaleZ(gXSI.readFloat());
				m_matrix.rotateX(-gXSI.readFloat() * (PI / 180));
				m_matrix.rotateY(-gXSI.readFloat() * (PI / 180));
				m_matrix.rotateZ(-gXSI.readFloat() * (PI / 180));
				m_matrix.pos.x += gXSI.readFloat();
				m_matrix.pos.y += gXSI.readFloat();
				m_matrix.pos.z += gXSI.readFloat();
				gXSI.endSection();
				break;

			default:
				gXSI.skipSection();
				break;
		}
	}
}

XSIModel::~XSIModel()
{
	free(m_pName);

	if(m_pMesh != NULL)
		delete m_pMesh;

	{
		const XSIModel *pCur, *pNext;

		pCur = m_pModels;
		while(pCur != NULL)
		{
			pNext = pCur->getNext();
			delete pCur;
			pCur = pNext;
		}
	}
}

/**************************************
 *
 * Mesh
 *
 **************************************/

XSIMesh::XSIMesh()
{
	m_pShape = NULL;
	m_pStripLists = NULL;
	m_pTriLists = NULL;
	m_numStripLists = 0;
	m_numTriLists = 0;

	m_pName = strdup(gXSI.getSectionName());

	while(!gXSI.endOfSection())
	{
		switch(gXSI.readSection())
		{
			case SI_Shape:
				m_pShape = new XSIShape();
				break;

			case SI_TriStripList:
				m_numStripLists++;
				m_pStripLists = new XSIStripList(m_pStripLists);
				break;

			case SI_TriangleList:
				m_numTriLists++;
				m_pTriLists = new XSITriList(m_pTriLists);
				break;

			default:
				gXSI.skipSection();
				break;
		}
	}

	fixStrips();
}

XSIMesh::~XSIMesh()
{
	free(m_pName);
	if(m_pShape != NULL)
		delete m_pShape;

	{
		const XSIStripList *pCur, *pNext;
		pCur = m_pStripLists;
		while(pCur != NULL)
		{
			pNext = pCur->getNext();
			delete pCur;
			pCur = pNext;
		}
	}

	const XSITriList *pCur, *pNext;
	pCur = m_pTriLists;
	while(pCur != NULL)
	{
		pNext = pCur->getNext();
		delete pCur;
		pCur = pNext;
	}
}

void XSIMesh::fixStrips()
{
	// first iterate through trilists
	XSITriList *pTriList = m_pTriLists;

	while(pTriList != NULL)
	{
		int elements = pTriList->getElements();
		// now iterate through the striplists to find one with the same material and elements
		XSIStripList *pStripList = m_pStripLists;
		
		while(pStripList != NULL)
		{
			if(elements == pStripList->getElements() &&
				strcmp(pTriList->getMaterialName(), pStripList->getMaterialName()) == 0)
			{
				// now iterate through the triangles
				for(int t = 0; t < pTriList->getNumTriangles(); t++)
				{
					int s;
					// and try to find a strip with matching first two vertices
					for(s = 0; s < pStripList->getNumStrips(); s++)
					{
						XSIStrip *pStrip = pStripList->getStrip(s);
						int nMatches = 0;
						int nonMatch = 2;
						for(int v = 0; v < nMatches + 2 && nMatches < 2; v++)
						{
							bool match = false;
							for(int v2 = 0; v2 < 2; v2++)
							{
								if((!(elements & POSITION) ||
										m_pShape->getPosition(pTriList->getPosition(t, v)) == m_pShape->getPosition(pStrip->getPosition(v2))) &&
									(!(elements & NORMAL) ||
									 	m_pShape->getNormal(pTriList->getNormal(t, v)) == m_pShape->getNormal(pStrip->getNormal(v2))) &&
									(!(elements & COLOR) ||
									 	m_pShape->getColor(pTriList->getColor(t, v)) == m_pShape->getColor(pStrip->getColor(v2))) &&
									(!(elements & TEX_COORD_UV0) ||
									 	m_pShape->getUV0(pTriList->getUV0(t, v)) == m_pShape->getUV0(pStrip->getUV0(v2))))
									match = true;
							}
							if(match)
								nMatches++;
							else
								nonMatch = v;
						}

						if(nMatches == 2)
						{
							pStrip->addVertexFront(pTriList, t, nonMatch);
							break;
						}
					}

					if(s == pStripList->getNumStrips())
						pStripList->addStrip(pTriList, t);
				}

				pTriList->clear();
				
				break;
			}
			
			pStripList = pStripList->getNext();

			if(pStripList == NULL)
			{
				printf("Couldn't find Strip for TriList\n");
				exit(1);
			}
		}
		
		pTriList = pTriList->getNext();
	}
}

/**************************************
 *
 * Shape
 *
 **************************************/

XSIShape::XSIShape()
{
	m_numPositions = m_numNormals = m_numColors = 0;
	m_pPositions = m_pNormals = m_pColors = NULL;

	m_pName = strdup(gXSI.getSectionName());

	int numArrays = gXSI.readInt();

	gXSI.expectString("ORDERED");
	
	for(int i = 0; i < numArrays; i++)
	{
		int size = gXSI.readInt();
		
		const char *type = gXSI.readString();
		if(strcmp(type, "POSITION") == 0)
			readArray3(&m_pPositions, &m_numPositions, size);
		else if(strcmp(type, "NORMAL") == 0)
			readArray3(&m_pNormals, &m_numNormals, size);
		else if(strcmp(type, "COLOR") == 0)
			readArray4(&m_pColors, &m_numColors, size);
		else if(strcmp(type, "TEX_COORD_UV0") == 0)
			readArray2(&m_pUVs0, &m_numUVs0, size);
		else
		{
			printf("Unsupported arraytype '%s'\n", type);
			exit(1);
		}
	}

	gXSI.endSection();
}

XSIShape::~XSIShape()
{
	free(m_pName);
	if(m_pPositions != NULL)
		delete [] m_pPositions;
	if(m_pNormals != NULL)
		delete [] m_pNormals;
	if(m_pColors != NULL)
		delete [] m_pColors;
}

void XSIShape::readArray2(Vector **pArray, int *pNum, int size)
{
	*pNum = size;
	*pArray = new Vector[size];

	// skip name if there
	gXSI.readString();

	for(int i = 0; i < size; i++)
	{
		(*pArray)[i].x = gXSI.readFloat();
		(*pArray)[i].y = gXSI.readFloat();
	}
}

void XSIShape::readArray3(Vector **pArray, int *pNum, int size)
{
	*pNum = size;
	*pArray = new Vector[size];

	for(int i = 0; i < size; i++)
	{
		(*pArray)[i].x = gXSI.readFloat();
		(*pArray)[i].y = gXSI.readFloat();
		(*pArray)[i].z = gXSI.readFloat();
	}
}

void XSIShape::readArray4(Vector **pArray, int *pNum, int size)
{
	*pNum = size;
	*pArray = new Vector[size];

	for(int i = 0; i < size; i++)
	{
		(*pArray)[i].x = gXSI.readFloat();
		(*pArray)[i].y = gXSI.readFloat();
		(*pArray)[i].z = gXSI.readFloat();
		(*pArray)[i].w = gXSI.readFloat();
	}
}

/**************************************
 *
 * TriStripList
 *
 **************************************/

XSIStripList::XSIStripList(XSIStripList *pNext)
{
	m_pNext = pNext;
	
	m_numStrips = gXSI.readInt();

	m_elements = POSITION | readElements();
	m_pMaterial = strdup(gXSI.readString());

	m_pStrips = new XSIStrip*[m_numStrips];
	int i = 0;
	while(!gXSI.endOfSection())
	{
		if(gXSI.readSection() == SI_TriStrip)
			m_pStrips[i++] = new XSIStrip(m_elements);
		else
			gXSI.skipSection();
	}
}

XSIStripList::~XSIStripList()
{
	for(int i = 0; i < m_numStrips; i++)
		delete m_pStrips[i];
	delete [] m_pStrips;
}

void XSIStripList::addStrip(XSITriList *pTriList, int t)
{
	XSIStrip **pStrips = new XSIStrip*[m_numStrips + 1];

	for(int i = 0; i < m_numStrips; i++)
		pStrips[i] = m_pStrips[i];

	pStrips[m_numStrips] = new XSIStrip(pTriList, t);

	m_numStrips++;
	delete [] m_pStrips;
	m_pStrips = pStrips;
}

/**************************************
 *
 * TriStrip
 *
 **************************************/

XSIStrip::XSIStrip(int elements)
{
	m_pPositions = m_pNormals = m_pColors = m_pUVs0 = NULL;

	m_length = gXSI.readInt();

	if(elements & POSITION)
		readArray(&m_pPositions);
	if(elements & NORMAL)
		readArray(&m_pNormals);
	if(elements & COLOR)
		readArray(&m_pColors);
	if(elements & TEX_COORD_UV0)
		readArray(&m_pUVs0);

	gXSI.endOfSection();
}

XSIStrip::XSIStrip(XSITriList *pTriList, int t)
{
	m_pPositions = m_pNormals = m_pColors = m_pUVs0 = NULL;
	m_length = 3;
	int elements = pTriList->getElements();

	if(elements & POSITION)
	{
		m_pPositions = new int[3];
		for(int i = 0; i < 3; i++)
			m_pPositions[i] = pTriList->getPosition(t, i);
	}
	if(elements & NORMAL)
	{
		m_pNormals = new int[3];
		for(int i = 0; i < 3; i++)
			m_pNormals[i] = pTriList->getNormal(t, i);
	}
	if(elements & COLOR)
	{
		m_pColors = new int[3];
		for(int i = 0; i < 3; i++)
			m_pColors[i] = pTriList->getColor(t, i);
	}
	if(elements & TEX_COORD_UV0)
	{
		m_pUVs0 = new int[3];
		for(int i = 0; i < 3; i++)
			m_pUVs0[i] = pTriList->getUV0(t, i);
	}
}

XSIStrip::~XSIStrip()
{
	if(m_pPositions != NULL)
		delete [] m_pPositions;
	if(m_pNormals != NULL)
		delete [] m_pNormals;
	if(m_pColors != NULL)
		delete [] m_pColors;
	if(m_pUVs0 != NULL)
		delete [] m_pUVs0;
}

void XSIStrip::readArray(int **pArray)
{
	*pArray = new int[m_length];

	for(int i = 0; i < m_length; i++)
		(*pArray)[i] = gXSI.readInt();
}

void XSIStrip::addVertexFront(XSITriList *pTriList, int t, int v)
{
	int elements = pTriList->getElements();

	if(elements & POSITION)
	{
		int *list = new int[m_length + 1];
		list[0] = pTriList->getPosition(t, v);
		for(int i = 0; i < m_length; i++)
			list[i + 1] = m_pPositions[i];
		delete [] m_pPositions;
		m_pPositions = list;
	}

	if(elements & NORMAL)
	{
		int *list = new int[m_length + 1];
		list[0] = pTriList->getNormal(t, v);
		for(int i = 0; i < m_length; i++)
			list[i + 1] = m_pNormals[i];
		delete [] m_pNormals;
		m_pNormals = list;
	}

	if(elements & COLOR)
	{
		int *list = new int[m_length + 1];
		list[0] = pTriList->getColor(t, v);
		for(int i = 0; i < m_length; i++)
			list[i + 1] = m_pColors[i];
		delete [] m_pColors;
		m_pColors = list;
	}

	if(elements & TEX_COORD_UV0)
	{
		int *list = new int[m_length + 1];
		list[0] = pTriList->getUV0(t, v);
		for(int i = 0; i < m_length; i++)
			list[i + 1] = m_pUVs0[i];
		delete [] m_pUVs0;
		m_pUVs0 = list;
	}

	m_length++;
}

/**************************************
 *
 * TriList
 *
 **************************************/

XSITriList::XSITriList(XSITriList *pNext)
{
	m_pNext = pNext;
	m_pPositions = NULL;
	m_pNormals = NULL;
	m_pColors = NULL;
	m_pUVs0 = NULL;

	m_numTriangles = gXSI.readInt();

	m_elements = POSITION | readElements();

	m_pMaterial = strdup(gXSI.readString());

	if(m_elements & POSITION)
		readArray(&m_pPositions);
	if(m_elements & NORMAL)
		readArray(&m_pNormals);
	if(m_elements & COLOR)
		readArray(&m_pColors);
	if(m_elements & TEX_COORD_UV0)
		readArray(&m_pUVs0);

	gXSI.endSection();
}

XSITriList::~XSITriList()
{
	if(m_pPositions != NULL)
		delete [] m_pPositions;
	if(m_pNormals != NULL)
		delete [] m_pNormals;
	if(m_pColors != NULL)
		delete [] m_pColors;
	if(m_pUVs0 != NULL)
		delete [] m_pUVs0;
}

void XSITriList::readArray(int **pArray)
{
	*pArray = new int[m_numTriangles * 3];

	for(int i = 0; i < m_numTriangles * 3; i++)
		(*pArray)[i] = gXSI.readInt();
}

/**************************************
 *
 * Material
 *
 **************************************/

XSIMaterial::XSIMaterial(const XSIMaterial *pNext)
{
	m_pNext = pNext;
	m_pTexture = NULL;

	m_pName = strdup(gXSI.getSectionName());

	int nOutput = gXSI.readInt();
	for(int i = 0; i < nOutput; i++)
	{
		gXSI.readString();
		gXSI.readString();
	}

	while(!gXSI.endOfSection())
	{
		if(gXSI.readSection() == XSI_Shader)
		{
			gXSI.readString();					// skip path
			gXSI.readInt();					// skip output

			int nParam = gXSI.readInt();
			int nConnect = gXSI.readInt();

			for(int i = 0; i < nParam; i++)
			{
				gXSI.readString();
				const char *type = gXSI.readString();

				if(strcmp(type, "STRING") == 0)
					gXSI.readString();
				else if(strcmp(type, "INTEGER") == 0)
					gXSI.readInt();
				else if(strcmp(type, "BOOLEAN") == 0)
					gXSI.readInt();
				else if(strcmp(type, "FLOAT") == 0)
					gXSI.readFloat();
				else
				{
					printf("Unknown type: %s\n", type);
					exit(1);
				}
			}

			for(int i = 0; i < nConnect; i++)
			{
				char *param = strdup(gXSI.readString());
				char *name = strdup(gXSI.readString());
				const char *type = gXSI.readString();

				if(strcmp(param, "tex") == 0 && strcmp(type, "IMAGE") == 0)
					m_pTexture = name;
				else
					free(name);

				free(param);
			}

			gXSI.endSection();
		}
		else
			gXSI.skipSection();
	}
}

XSIMaterial::~XSIMaterial()
{
	free(m_pName);
	free(m_pTexture);
}

/**************************************
 *
 * Image
 *
 **************************************/

XSIImage::XSIImage(const XSIImage *pNext)
{
	m_pNext = pNext;

	m_pName = strdup(gXSI.getSectionName());

	m_pFilename = strdup(gXSI.readString());
	// find basename
	char *pTerm = m_pFilename;
	for(char *pCur = m_pFilename; *pCur != 0; pCur++)
		if(*pCur == '.')
			pTerm = pCur;
	*pTerm = 0;

	gXSI.readInt(); gXSI.readInt(); gXSI.readInt(); gXSI.readInt();
	gXSI.readFloat(); gXSI.readFloat(); gXSI.readFloat(); gXSI.readFloat();
	gXSI.readFloat(); gXSI.readInt(); gXSI.readInt(); gXSI.readInt();

	while(!gXSI.endOfSection())
	{
		gXSI.readSection();
		gXSI.skipSection();
	}
}

XSIImage::~XSIImage()
{
	free(m_pName);
	free(m_pFilename);
}

/**************************************
 *
 * Helper
 *
 **************************************/

int readElements()
{
	int m_elements = 0;
	char *elements = strdup(gXSI.readString());
	char *element = strtok(elements, "|");
	while(element != NULL)
	{
		if(strcmp(element, "NORMAL") == 0)
			m_elements |= NORMAL;
		else if(strcmp(element, "COLOR") == 0)
			m_elements |= COLOR;
		else if(strcmp(element, "TEX_COORD_UV0") == 0)
			m_elements |= TEX_COORD_UV0;
		else
		{
			printf("Unsupported element '%s'\n", element);
			exit(1);
		}
		element = strtok(NULL, "|");
	}
	free(elements);

	return m_elements;
}
