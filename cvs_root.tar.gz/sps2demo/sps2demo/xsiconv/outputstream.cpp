#include "outputstream.h"
#include "math.h"
#include <stdio.h>
#include <string.h>

OutputStream::OutputStream(const char *filename)
{
	m_file = fopen(filename, "wb");
	if(m_file == NULL)
	{
		printf("Unable to open '%s'\n", filename);
		exit(1);
	}
}

OutputStream::~OutputStream()
{
	fclose((FILE*)m_file);
}

void OutputStream::add8(u8 value)
{
	fwrite(&value, 1, 1, (FILE*)m_file);
}

void OutputStream::add32(u32 value)
{
	fwrite(&value, 4, 1, (FILE*)m_file);
}

void OutputStream::addFloat(float value)
{
	fwrite(&value, 4, 1, (FILE*)m_file);
}

void OutputStream::add64(u64 value)
{
	fwrite(&value, 8, 1, (FILE*)m_file);
}

void OutputStream::add128(u128 value)
{
	fwrite(&value, 16, 1, (FILE*)m_file);
}

void OutputStream::addMemoryStream(MemoryStream &stream)
{
	add32(stream.getSize());

	MemoryStream::Buffer *buffer = stream.getBuffers();
	while(buffer != NULL)
	{
		fwrite(buffer->mem, buffer->size, 1, (FILE*)m_file);
		buffer = buffer->next;
	}
}

void OutputStream::addString(const char *string)
{
	int size = strlen(string);
	
	add32(size);

	for(int i = 0; i < size; i++)
		add8(string[i]);
}

// MEM

MemoryStream::MemoryStream()
{
	m_buffers = new Buffer;
	m_curBuffer = m_buffers;
	m_size = 0;
	m_ptr = m_buffers->mem;
}

MemoryStream::~MemoryStream()
{
	Buffer *cur, *next;

	cur = m_buffers;
	while(cur != NULL)
	{
		next = cur->next;
		delete cur;
		cur = next;
	}
}

void MemoryStream::align()
{
	while((int)m_ptr & 3)
		add8(0);
}

void MemoryStream::add8(u8 value)
{
	if(m_ptr >= m_curBuffer->mem + 1024)
	{
		Buffer *n = new Buffer;
		m_curBuffer->next = n;
		m_curBuffer = n;
		m_ptr = n->mem;
	}

	*m_ptr++ = value;
	m_size++;
	m_curBuffer->size++;
}

void MemoryStream::addVector3(const Vector &vec)
{
	addFloat(vec.x);
	addFloat(vec.y);
	addFloat(vec.z);
}

void MemoryStream::addVector4(const Vector &vec)
{
	addFloat(vec.x);
	addFloat(vec.y);
	addFloat(vec.z);
	addFloat(vec.w);
}
