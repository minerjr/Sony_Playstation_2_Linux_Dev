#ifndef OUTPUTSTREAM_H
#define OUTPUTSTREAM_H

#include "types.h"

typedef enum {
	S_32 = 0, S_16 = 1, S_8 = 2,
	V2_32 = 4, V2_16 = 5, V2_8 = 6,
	V3_32 = 8, V3_16 = 9, V3_8 = 10,
	V4_32 = 12, V4_16 = 13, V4_8 = 14,
	V4_5 = 15} VUP_FORMAT;

class MemoryStream
{
	public:
					MemoryStream();
					~MemoryStream();
		void		align();
		void		add8(u8 value);
		void		add16(u16 value) { add8(value); add8(value >> 8); }
		void		add32(u32 value) { add16(value); add16(value >> 16); }
		void		add64(u64 value) { add32(value); add32(value >> 32); }
		void		add128(u128 value) { add64(value); add64(value >> 64); }
		void		addFloat(float value) { add32(*(u32*)&value); }
		void		addVector3(const class Vector &vec);
		void		addVector4(const class Vector &vec);
		void		addMatrix(const class Matrix &mat);
		void		addMscalf(int addr) { add32((0x15 << 24) + addr); }
		void		addMscnt() { add32(0x17 << 24); }
		void		addItop(int num) { add32((4 << 24) + num); }
		void		addStcycl(int cl, int wl) { add32((1 << 24) + cl + (wl << 8)); }
		void		addUnpack(VUP_FORMAT format, int addr, int num, int usetops = 0,
						int nosign = 1, int masking = 0)
			{
				add32((0x60 << 24) + (format << 24) + (masking << 28) + (usetops << 15) +
					(nosign << 14) + (num << 16) + addr);
			}

		struct Buffer
		{
			Buffer() { size = 0; next = NULL; }
			int		size;
			Buffer	*next;
			u8		mem[1024];
		};

		int			getSize() const { return m_size; }
		Buffer		*getBuffers() { return m_buffers; }

	protected:

		int			m_size;
		Buffer		*m_curBuffer;
		Buffer		*m_buffers;
		u8			*m_ptr;
};

class OutputStream
{
	public:
					OutputStream(const char *filename);
					~OutputStream();
		void		add8(u8 byte);
		void		add32(u32 value);
		void		addFloat(float value);
		void		add64(u64 value);
		void		add128(u128 value);
		void		addMemoryStream(MemoryStream &stream);
		void		addString(const char *string);

	protected:
		
		void		*m_file;
};

#endif /* OUTPUTSTREAM_H */
