#ifndef XSIREADER_H
#define XSIREADER_H

#include "math.h"

class XSIModel;
class XSIMesh;
class XSIShape;
class XSIStripList;
class XSIStrip;
class XSITriList;
class XSIMaterial;
class XSIImage;

enum {
	POSITION = 1,
	NORMAL = 2,
	COLOR = 4,
	TEX_COORD_UV0 = 8,
};

/**************************************
 * XSIReader
 **************************************/

class XSIReader
{
	public:
						XSIReader();
						~XSIReader();
		void			readXSI(const char *filename);
		const XSIModel	*getModels() const { return m_pModels; }
		const XSIMaterial *findMaterial(const char *pName) const;
		const XSIImage	*findImage(const char *pName) const;
	protected:

		const XSIModel	*m_pModels;
		const XSIMaterial *m_pMaterials;
		const XSIImage	*m_pImages;
};

/**************************************
 * XSIModel
 **************************************/

class XSIModel
{
	public:
						XSIModel(const XSIModel *pNext);
						~XSIModel();
		const char		*getName() const { return m_pName; }
		const XSIModel	*getNext() const { return m_pNext; }
		const XSIMesh	*getMesh() const { return m_pMesh; }
		const XSIModel	*getModels() const { return m_pModels; }
		const Matrix	&getMatrix() const { return m_matrix; }
		bool			isNull() const { return m_isNull; }
		
	protected:

		char			*m_pName;
		const XSIModel	*m_pNext;
		const XSIMesh	*m_pMesh;
		const XSIModel	*m_pModels;
		bool			m_isNull;
		Matrix			m_matrix;
};

/**************************************
 * XSIMesh
 **************************************/

class XSIMesh
{
	public:
						XSIMesh();
						~XSIMesh();
		const char		*getName() const { return m_pName; }
		const XSIShape	*getShape() const { return m_pShape; }
		const XSIStripList *getStripLists() const { return m_pStripLists; }
		int				getNumStripLists() const { return m_numStripLists; }
		const XSITriList *getTriLists() const { return m_pTriLists; }
		int				getNumTriLists() const { return m_numTriLists; }

	protected:

		void			fixStrips();

		char			*m_pName;
		const XSIShape	*m_pShape;
		XSIStripList	*m_pStripLists;
		XSITriList		*m_pTriLists;
		int				m_numStripLists;
		int				m_numTriLists;
};

/**************************************
 * XSIShape
 **************************************/

class XSIShape
{
	public:
						XSIShape();
						~XSIShape();
		const char		*getName() const { return m_pName; }
		const Vector	&getPosition(int index) const { return m_pPositions[index]; }
		const Vector	&getNormal(int index) const { return m_pNormals[index]; }
		const Vector	&getColor(int index) const { return m_pColors[index]; }
		const Vector	&getUV0(int index) const { return m_pUVs0[index]; }

	protected:

		void			readArray2(Vector **pArray, int *pNum, int size);
		void			readArray3(Vector **pArray, int *pNum, int size);
		void			readArray4(Vector **pArray, int *pNum, int size);

		int				m_numPositions;
		int				m_numNormals;
		int				m_numColors;
		int				m_numUVs0;
		Vector			*m_pPositions;
		Vector			*m_pNormals;
		Vector			*m_pColors;
		Vector			*m_pUVs0;
		char			*m_pName;
};

/**************************************
 * XSIStripList
 **************************************/

class XSIStripList
{
	public:
						XSIStripList(XSIStripList *pNext);
						~XSIStripList();
		const char		*getMaterialName() const { return m_pMaterial; }
		int				getElements() const { return m_elements; }
		int				getNumStrips() const { return m_numStrips; }
		XSIStrip		*getStrip(int index) const { return m_pStrips[index]; }
		XSIStripList	*getNext() const { return m_pNext; }
		void			addStrip(XSITriList *pTriList, int t);

	protected:

		XSIStripList	*m_pNext;
		char			*m_pMaterial;
		int				m_elements;
		int				m_numStrips;
		XSIStrip		**m_pStrips;
};

/**************************************
 * XSIStrip
 **************************************/

class XSIStrip
{
	public:
						XSIStrip(int elements);
						XSIStrip(XSITriList *pTriList, int t);
						~XSIStrip();
		int				getLength() const { return m_length; }
		int				getPosition(int index) const { return m_pPositions[index]; }
		int				getNormal(int index) const { return m_pNormals[index]; }
		int				getColor(int index) const { return m_pColors[index]; }
		int				getUV0(int index) const { return m_pUVs0[index]; }
		void			addVertexFront(XSITriList *pTriList, int t, int v);
	
	protected:
			
		void			readArray(int **pArray);

		int				m_length;
		int				*m_pPositions;
		int				*m_pNormals;
		int				*m_pColors;
		int				*m_pUVs0;
};

/**************************************
 * XSITriList
 **************************************/

class XSITriList
{
	public:
						XSITriList(XSITriList *pNext);
						~XSITriList();
		XSITriList		*getNext() const { return m_pNext; }
		int				getNumTriangles() const { return m_numTriangles; }
		int				getElements() const { return m_elements; }
		const char		*getMaterialName() const { return m_pMaterial; }
		int				getPosition(int index, int n) const { return m_pPositions[index*3 + n]; }
		int				getNormal(int index, int n) const { return m_pNormals[index*3 + n]; }
		int				getColor(int index, int n) const { return m_pColors[index*3 + n]; }
		int				getUV0(int index, int n) const { return m_pUVs0[index*3 + n]; }
		void			clear() { m_numTriangles = 0; }

	protected:

		void			readArray(int **pArray);

		XSITriList		*m_pNext;
		int				m_elements;
		char			*m_pMaterial;
		int				m_numTriangles;
		int				*m_pPositions;
		int				*m_pNormals;
		int				*m_pColors;
		int				*m_pUVs0;
};

/**************************************
 * Material
 **************************************/

class XSIMaterial
{
	public:
						XSIMaterial(const XSIMaterial *pNext);
						~XSIMaterial();
		const XSIMaterial	*getNext() const { return m_pNext; }
		const char		*getName() const { return m_pName; }
		const char		*getTexture() const { return m_pTexture; }

	protected:

		const XSIMaterial	*m_pNext;
		char			*m_pName;
		char			*m_pTexture;
};

/**************************************
 * Image
 **************************************/

class XSIImage
{
	public:
						XSIImage(const XSIImage *pNext);
						~XSIImage();
		const XSIImage	*getNext() const { return m_pNext; }
		const char		*getName() const { return m_pName; }
		const char		*getFilename() const { return m_pFilename; }

	protected:

		const XSIImage	*m_pNext;
		char			*m_pName;
		char			*m_pFilename;
};

/**************************************
 * Helper
 **************************************/

int readElements();

#endif /* XSIREADER_H */
