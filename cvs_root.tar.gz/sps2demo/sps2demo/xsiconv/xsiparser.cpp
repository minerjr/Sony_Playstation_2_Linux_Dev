#include "xsiparser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

XSIParser gXSI;

const char *XSIParser::m_Sections[] = {
	"SI_Ambience",
	"SI_Angle",
	"SI_Camera",
	"SI_CoordinateSystem",
	"SI_FileInfo",
	"SI_GlobalMaterial",
	"SI_Light",
	"SI_MaterialLibrary",
	"SI_Mesh",
	"SI_Model",
	"SI_Null",
	"SI_Scene",
	"SI_Shape",
	"SI_Transform",
	"SI_TriangleList",
	"SI_TriStrip",
	"SI_TriStripList",
	"SI_Visibility",
	"XSI_CustomPSet",
	"XSI_Image",
	"XSI_ImageFX",
	"XSI_ImageLibrary",
	"XSI_Material",
	"XSI_MaterialInfo",
	"XSI_Shader",
};

char XSIParser::m_WS[256];

XSIParser::XSIParser()
{
	m_pFile = NULL;
	m_pSectionName = NULL;

	for(int i = 0; i < 256; i++)
		m_WS[i] = 0;
	m_WS['\t'] = m_WS['\n'] = m_WS['\r'] = m_WS[' '] = m_WS[','] = 1;

	if(sizeof(m_Sections) != NUM_SECTIONS * 4)
	{
		for(int i = 0; i < NUM_SECTIONS; i++)
			printf("%d: %s\n", i, m_Sections[i]);
		printf("m_Sections and NUM_SECTIONS mismatch (%d, %d)\n", sizeof(m_Sections) / 4, NUM_SECTIONS);
		exit(1);
	}
}

XSIParser::~XSIParser()
{
	if(m_pFile != NULL)
		fclose((FILE*)m_pFile);

	free(m_pSectionName);
}

void XSIParser::open(const char *filename)
{
	m_pFile = fopen(filename, "rb");
	if(m_pFile == NULL)
	{
		printf("Unable to open file '%s'\n", filename);
		exit(1);
	}

	char tmp[256];
	fgets(tmp, 256, (FILE*)m_pFile);
	skipWS();
}

bool XSIParser::endOfFile()
{
	int c = fgetc((FILE*)m_pFile);

	if(c == EOF)
		return true;

	ungetc(c, (FILE*)m_pFile);
	return false;
}

void XSIParser::close()
{
	fclose((FILE*)m_pFile);
	m_pFile = NULL;
}

XSISection XSIParser::readSection()
{
	readIdentifier();

	int t = 0;
	while(t < NUM_SECTIONS && strcmp(m_Sections[t], m_Buffer))
		t++;

	if(t == NUM_SECTIONS)
	{
		printf("Unknown template '%s'\n", m_Buffer);
		exit(1);
	}

	int c = fgetc((FILE*)m_pFile);
	ungetc(c, (FILE*)m_pFile);
	if(c != '{')
	{
		readIdentifier();
		free(m_pSectionName);
		m_pSectionName = strdup(m_Buffer);
	}
	else
		m_pSectionName = strdup("");

	if(fgetc((FILE*)m_pFile) != '{')
	{
		printf("'{' expected after template name\n");
		char buffer[256];
		fgets(buffer, 256, (FILE*)m_pFile);
		printf("%s, '%s'", buffer, m_pSectionName);
		exit(1);
	}

	skipWS();

	m_lastSection = (XSISection)t;
	return (XSISection)t;
}

void XSIParser::skipWS()
{
	int c = fgetc((FILE*)m_pFile);

	while(c != EOF && m_WS[c] != 0)
		c = fgetc((FILE*)m_pFile);

	if(c != EOF)
		ungetc(c, (FILE*)m_pFile);
}

void XSIParser::readIdentifier()
{
	char *pBuf = m_Buffer;
	int c = fgetc((FILE*)m_pFile);
	
	while(c != EOF && m_WS[c] == 0)
	{
		*pBuf++ = c;
		c = fgetc((FILE*)m_pFile);
	}
	*pBuf = 0;
	
	if(c == EOF)
	{
		printf("Unexpected end of file while reading Identifier\n");
		exit(1);
	}

	ungetc(c, (FILE*)m_pFile);

	skipWS();
}

void XSIParser::skipSection()
{
	int depth = 1;
	bool string = false;
	int c;

//	printf("skipping Section %s ('%s')\n", m_Sections[m_lastSection], m_pSectionName);
	while(depth > 0)
	{
		c = fgetc((FILE*)m_pFile);
		
		if(c == EOF)
		{
			printf("Unexpected end of file while skipping template\n");
			exit(1);
		}

		if(c == '"')
			string = !string;
		else if(c == '{' && !string)
			depth++;
		else if(c == '}' && !string)
			depth--;
	}

	skipWS();
}

void XSIParser::endSection()
{
	if(fgetc((FILE*)m_pFile) != '}')
	{
		printf("Not at end of template\n");
		exit(1);
	}
	
	skipWS();
}

bool XSIParser::endOfSection()
{
	int c = fgetc((FILE*)m_pFile);

	if(c == '}')
	{
		skipWS();
		return true;
	}

	ungetc(c, (FILE*)m_pFile);
	return false;
}

int XSIParser::readInt()
{
	readIdentifier();
	return atoi(m_Buffer);
}

float XSIParser::readFloat()
{
	readIdentifier();
	return atof(m_Buffer);
}

const char *XSIParser::readString()
{
	if(fgetc((FILE*)m_pFile) != '"')
	{
		printf("String expected\n");
		exit(1);
	}

	char *pBuf = m_Buffer;
	int c = fgetc((FILE*)m_pFile);

	while(c != '"')
	{
		if(c == EOF)
		{
			printf("Unexpected end of file in string\n");
			exit(1);
		}

		*pBuf++ = c;

		c = fgetc((FILE*)m_pFile);
	}
	*pBuf = 0;

	skipWS();

	return m_Buffer;
}

void XSIParser::expectString(const char *string)
{
	if(strcmp(readString(), string))
	{
		printf("'%s' expected\n", string);
		exit(1);
	}
}
