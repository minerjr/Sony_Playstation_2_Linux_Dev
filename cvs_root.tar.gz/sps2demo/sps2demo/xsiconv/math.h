#ifndef MATH_H
#define MATH_H

#include "types.h"

class Vector
{
public:
	Vector() {}
	Vector(float _x, float _y, float _z, float _w = 0.0f)
		{x = _x; y = _y; z = _z; w = _w; }
//	~CVector();
	void normalize();
	float dot(const Vector &v) const
		{ return x * v.x + y * v.y + z * v.z; }
	Vector cross(const Vector &v) const
		{ return Vector(y * v.z - z * v.y,
				z * v.x - x * v.z, x * v.y - y * v.x); }
	Vector operator+(const Vector &v) const
		{ return Vector(x + v.x, y + v.y, z + v.z, w + v.w); }
	Vector operator-(const Vector &v) const
		{ return Vector(x - v.x, y - v.y, z - v.z, w - v.w); }
	float operator*(const Vector &v) const
		{ return x * v.x + y * v.y + z * v.z + w * v.w; }
	Vector operator*(const float s) const
		{ return Vector(x * s, y * s, z * s, w * s); }
	Vector &operator+=(const Vector &v)
		{ x += v.x; y += v.y; z += v.z; w += v.w; return *this; }
	Vector &operator*=(float s)
		{ x *= s; y *= s; z *= s; w *= s; return *this; }
	bool operator==(const Vector &v) const
		{ return (x == v.x && y == v.y && z == v.z && w == v.w); }
	float getSquareLength() const { return x*x + y*y + z*z; }
	float getLength() const { return sqrtf(x*x + y*y + z*z); }
	void print();
	float x, y, z, w;
protected:
} QALIGN;

inline void Vector::normalize()
{
	float f = 1.0f / sqrtf(x*x + y*y + z*z);
	x *= f; y *= f; z *= f;
}

class Matrix
{
public:
	Matrix() {}
	~Matrix() {}
	Vector x, y, z, pos;
	Matrix invert() const;
	Matrix lightMatrix() const;
	void rotateX(float a);
	void rotateY(float a);
	void rotateZ(float a);
	void unitmatrix();
	void scale(float scale);
	void scaleX(float scale)
		{ x.x *= scale; y.x *= scale; z.x *= scale; }
	void scaleY(float scale)
		{ x.y *= scale; y.y *= scale; z.y *= scale; }
	void scaleZ(float scale)
		{ x.z *= scale; y.z *= scale; z.z *= scale; }
	void print() { x.print(); y.print(); z.print(); pos.print(); }
	Vector operator*(const Vector &v) const
		{ return x * v.x + y * v.y + z * v.z + pos; }
	Matrix &operator*=(const Matrix &m);
protected:
} QALIGN;

#endif /* MATH_H */
