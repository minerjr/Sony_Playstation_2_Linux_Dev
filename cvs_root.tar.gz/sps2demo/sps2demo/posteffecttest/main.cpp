#include "sps2.h"
#include "screen.h"
#include "dma.h"
#include "signalhandler.h"
#include "posteffecthelper.h"
#include "sps2registers.h"
#include <linux/ps2/dev.h>
#include <stdio.h>
#include <math.h>
#include "blur.h"
#include "crashzoom.h"
#include "glare.h"
#include "framework.h"
#include "camera.h"

bool end = false;
float time = 0;
Camera camera;

void render()
{
	int i;
	float x0, y0;

	x0 = sinf(time*2.4f) * 160*16 + 32768;
	y0 = 32768;

	camera.begin();

	dynDma.startDirect();
	dynDma.startAD();

	/*
	dynDma.addAD(PS2_GS_XYOFFSET_1, PS2_GS_SETREG_XYOFFSET(32768 - 320*16, 32768 - 240*16));
	dynDma.addAD(PS2_GS_SCISSOR_1, PS2_GS_SETREG_SCISSOR(0, 639, 0, 479));
	dynDma.addAD(PS2_GS_FRAME_1, PS2_GS_SETREG_FRAME(screen.getCurrentBuffer() * 150, 10, 0, 0));

	dynDma.addAD(PS2_GS_PRIM, PS2_GS_SETREG_PRIM(6, 0, 0, 0, 0, 0, 0, 0, 0));
	dynDma.addAD(PS2_GS_RGBAQ, PS2_GS_SETREG_RGBAQ(0, 0, 0, 0, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2(32768 - 320*16, 32768 - 240*16, 0));
	dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2(32768 + 320*16, 32768 + 240*16, 0));
	*/
	
	dynDma.addAD(PS2_GS_PRIM, PS2_GS_SETREG_PRIM(3, 1, 0, 0, 0, 0, 0, 0, 0));
	
	for(i = 0; i < 3; i++)
	{
		dynDma.addAD(PS2_GS_RGBAQ, PS2_GS_SETREG_RGBAQ((i == 0) ? 255 : 0,
			(i == 1) ? 255 : 0, (i == 2) ? 255 : 0, 0, 0));
		dynDma.addAD(PS2_GS_XYZ2, PS2_GS_SETREG_XYZ2(
			sinf((float)i / 1.5f * PI + time) * 3000 + x0,
			cosf((float)i / 1.5f * PI + time) * 3000 + y0,
			100));
	}
	dynDma.endAD();
	dynDma.endDirect();

	camera.end();

#if 1
	glare(0.0f, 3, -1.9f, 1.2f);
	glare(0.0f, 4, 1.0f, 1.2f);
	glare(0.0f, 5, 1.0f, 1.2f);
#endif

#if 0
	glare(0.5f, 4, 1.99f, 1.4f);
	crashzoom(9, 1.005f, 0.99f, 320.0f + 320.0f * sinf(time*1.123f),
			240.0f + 240.0f * sinf(time * 0.94547f), 1.05f);
#endif

#if 0
	{
		Posteffecthelper hlp;

		hlp.setFrame(300, 5);
		hlp.downSample(0, 0, 320, 240);
		hlp.setAlpha(2, 0, 2, 1, 128);
		hlp.blit(0, 0, 320, 240, true);
		crashzoom(hlp, 300, 385, 5, 320, 240, 8, 1.01f, 0.98f, 160, 120, 1.25f);
		hlp.setTex0(300, 5);
		hlp.setFrame();
		hlp.setRgba(128, 128, 128, 128);
		hlp.setAlpha(0, 2, 2, 1, 128);
		hlp.setClamp(320, 240);
		hlp.upSample(0, 0, 640, 480, true);
	}
#endif
			
	time += 0.01f;
}

int sigHandler(int signal)
{
	if(end)
		return 0;
	end = true;
	return 1;
}

int main()
{
	framework.init(16, 32);
	camera.init();

	framework.mainloop(render);
	return 0;
}

int mainOld()
{
	sps2.open();
	sps2.alloc(128);
	dynDma.init(32);
	staticDma.init(16);
	screen.open();
	signalHandler.registerHandler(sigHandler);
	
	while(!end)
	{
		screen.writeBgcolor(255, 0, 0);
		render();
		
		sps2.waitForDma(1);
		while((*EE_VIF1_STAT & (3 | 8 | (31 << 24))));
		while((*EE_GIF_STAT & (0xfc0 | (31 << 24))));
		screen.writeBgcolor(0, 0, 0);
		
		screen.vblankWait();
		screen.flipBuffers();
		screen.writePmode(1, 0, 1, 1, 0, 1, 224);
		
		dynDma.send();
	}

	return 0;
}
