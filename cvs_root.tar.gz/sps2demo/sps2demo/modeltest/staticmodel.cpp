#include "staticmodel.h"
#include "vucamera.h"
#include "vucode.h"
#include "math.h"
#include "intmdvu.h"
#include "dma.h"
#include "texturemanager.h"
#include "texture.h"
#include "debug.h"
#include "file.h"
#include <stdio.h>
#include <linux/ps2/dev.h>

extern "C" u64 intmdrender_vu[];

VuCode *StaticModel::m_pVuCode = (VuCode*)0;

StaticModel::StaticModel()
{
	m_pSurfaceChains = NULL;
}

StaticModel::~StaticModel()
{
	if(m_pSurfaceChains != NULL)
		delete [] m_pSurfaceChains;
}

void StaticModel::load(const char *pName)
{
	if(m_pVuCode == NULL)
		m_pVuCode = vumanager.createVuCode(intmdrender_vu, INT_MAXVERTICES * 4);

	File file(pName, "mdl");

	file.read(&m_numSurfaces, 4);
	m_pSurfaceChains = new u32[m_numSurfaces];
	m_pSurfaceTextures = new int[m_numSurfaces];

	for(int s = 0; s < m_numSurfaces; s++)
	{
		m_pSurfaceTextures[s] = readTexture(file);
		
		m_pSurfaceChains[s] = staticDma.getPtr();
		staticDma.addFlush();
		staticDma.addStcycl(4, 1);

		u32 size, tmp;
		file.read(&size, 4);
		for(u32 i = 0; i*4 < size; i++)
		{
			file.read(&tmp, 4);
			staticDma.add32(tmp);
		}

		staticDma.addStcycl(1, 1);
		staticDma.ret();
	}
}

void StaticModel::render(const Matrix &matrix)
{
	bool texture;
	m_pVuCode->send();

	dynDma.startDirect();
	dynDma.startAD();
	dynDma.addAD(PS2_GS_CLAMP_1, 0);
	dynDma.endAD();
	dynDma.endDirect();

	dynDma.addStcycl(1, 1);

	dynDma.addUnpack(V4_32, VU_INVMAT, 8);
	Matrix inv = matrix.lightMatrix();
	dynDma.addMatrix(inv);
	dynDma.addMatrix(matrix);

	// unpack lights
	dynDma.addUnpack(V3_32, INT_LIGHTS, 7);
	dynDma.addVector3(Vector(-0.25f, 0.5f, -0.5f));
	dynDma.addVector3(Vector(0.4f, 0.1f, -0.2f));
	dynDma.addVector3(Vector(0, -0.3, 0.4f));
	dynDma.addVector3(Vector(0.8f, 0.7f, 0.7f));
	dynDma.addVector3(Vector(0.7f, 0.8f, 0.7f));
	dynDma.addVector3(Vector(0.7f, 0.7f, 0.8f));
	dynDma.addVector3(Vector(0.3f, 0.3f, 0.3f));

	for(int s = 0; s < m_numSurfaces; s++)
	{
		dynDma.addFlush();

		texture = false;
		
		texture = m_pSurfaceTextures[s] != 0;
		if(texture)
			UploadContext1(m_pSurfaceTextures[s]);
		
		dynDma.addUnpack(V4_32, VU_GIFTAG, 1);
		dynDma.add64(PS2_GIFTAG_SET_TOPHALF(1, 1, 1, 4+8+(texture ? 16 : 0), 0, 3));
		dynDma.add64(0x412UL);
		dynDma.call(m_pSurfaceChains[s]);
	}
}

int StaticModel::readTexture(File &file)
{
	int len;
	file.read(&len, 4);					// read length of texture name

	if(len == 0)
		return 0;

	char pTextureName[len + 1];
	file.read(pTextureName, len);
	pTextureName[len] = 0;

	return textureManager.loadTexture(pTextureName);
}
