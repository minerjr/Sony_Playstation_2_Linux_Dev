#ifndef STATICMODEL_H
#define STATICMODEL_H

#include "types.h"

class Matrix;
class VuCode;
class File;

class StaticModel
{
	public:
						StaticModel();
						~StaticModel();
		void			load(const char *filename);
		void			render(const Matrix &mat);

	protected:

		int				readTexture(File &file);
		int				m_numSurfaces;
		u32				*m_pSurfaceChains;
		int				*m_pSurfaceTextures;
		static VuCode	*m_pVuCode;
};

#endif /* STATICMODEL_H */
