#include "framework.h"
#include "camera.h"
#include "intmd/intmdloader.h"
#include "staticmodel.h"
#include "math.h"
#include "glare.h"
#include "posteffecthelper.h"
#include "screen.h"
#include "blur.h"
#include "fadetogray.h"
#include "depthoffield.h"
#include "debug.h"

Camera camera;
StaticModel room, sphere, puppet;

float angle = 0;

FadeToGray *fadeToGrayFX;
DepthOfField *depthOfFieldFX;

void run()
{
	camera.freeCam();
	camera.begin();

	Matrix mat;
	mat.unitmatrix();

	room.render(mat);
	sphere.render(mat);
	mat.scale(2.0f);
	mat.pos += Vector(12, 0, 0);
	puppet.render(mat);

	angle += 0.02f;
	
	camera.end();

	// posteffects

//	fadeToGrayFX->render();
	depthOfFieldFX->render();	


//	glare(0.65f, 2, 1.0f / 0.65f, 1.3f, 0.0f);
	glare(0.6f, 3, 1.0f / 0.65f, 1.2f, 0);
}

int main()
{
	framework.init(1024, 16, 512);
//	framework.setDmaDisas(3);	// disassemble, then exit
	camera.setBgColor(0, 0, 0);
	camera.setNearPlane(0.5f);
	camera.init();
	camera.setPosition(Vector(0, 1.5f, -3));

	room.load("cube");
	sphere.load("sphere");
	puppet.load("puppet");

//	fadeToGrayFX = new FadeToGray;
	depthOfFieldFX = new DepthOfField;
	
	framework.mainloop(run);
	
	return 0;
}
