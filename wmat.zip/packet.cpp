#include <sps2lib.h>
#include <sps2tags.h>
#include <sps2util.h>
#include <assert.h>
#include "PS2Defines.h"
#include "PS2Types.h"
#include "AddRegisters.h"
#include "vecmaths.h"


int BuildSprite2D(PS2Sprite_t * pSprite, char *& pMem)
{
	//Get a Temporary identity matrix used for rotation
	FMatrix Temp;
	IdentityMatrix(&Temp);
	
	//There are the transformed coordinates of the sprite
	FVector TR, TL, BR, BL;

	//get the world positional matrix for the sprite
	
	//first the rotation
	RotMatrix(&pSprite->World, &Temp, pSprite->RotZ, pSprite->RotY, pSprite->RotX);
		
	//now the position
	pSprite->World.m[0][3] = pSprite->Pos.v[0];
	pSprite->World.m[1][3] = pSprite->Pos.v[1];
	pSprite->World.m[2][3] = pSprite->Pos.v[2];	//this is the z depth
		
	//apply World matrix to the untransformed coordinates
	ApplyMatrix(&TR, &pSprite->World, &pSprite->TR);
	ApplyMatrix(&TL, &pSprite->World, &pSprite->TL);
	ApplyMatrix(&BR, &pSprite->World, &pSprite->BR);
	ApplyMatrix(&BL, &pSprite->World, &pSprite->BL);
	
	/*
	//print out some stats
	DumpFVector("Top Left", &TL);
	DumpFVector("Top Right", &TR);
	DumpFVector("Bottom Left", &BL);
	DumpFVector("Bottom Right", &BR);
	DumpMatrix("Sprite", &pSprite->World);
	*/

		
	// Create a textured tristrip
	sps2GIFTag_t * pGIFTag = (sps2GIFTag_t *)pMem;
	pGIFTag->i128 = 0;
	pGIFTag->s.NLOOP = 1;	// Only one of them
	pGIFTag->s.PRE = 1;		// Transfer PRIM to the GS
	pGIFTag->s.EOP = 1;		// This is the last giftag in the packet
	 
	pGIFTag->s.PRIM = GS_PRIM(PRIM_TRI_STRIP, 
							PRIM_IIP_FLAT, 
							PRIM_TME_ON,
							PRIM_FGE_OFF, 
							PRIM_ABE_ON, 
							PRIM_AA1_OFF, 
							PRIM_FST_UV, 
							PRIM_CTXT_CONTEXT1, 
							PRIM_FIX_NOFIXDDA);
							
	pGIFTag->s.FLG = GIF_FLG_PACKED;
	pGIFTag->s.NREG = 9; 
	// Since we are putting 9 registers, this is a faster way of setting
	// the REGS field (1 = RGBA, 3 = UV, 5 = XYZ2)
	pGIFTag->s.REGS = (uint64(0x5) << 32) | (uint64(0x35353531));
	
	// Set the register pointer to the memory just after the GIFTag
	// pGIFTag + 1 will move the address of the pointer
	// ahead by the sizeof(sps2GIFTag_t) which is 1 quadword (128 bits)
	sps2GIFPackedRegister_t	* pRegister = (sps2GIFPackedRegister_t *)(pGIFTag + 1);

	AddColour(pRegister, pSprite->r, pSprite->g, pSprite->b, pSprite->a);
	
	//multiply coordinates by 16 before converting to int to preserve accuracy
	//top left
	AddUV(pRegister, pSprite->u, pSprite->v);
	AddVertexFP(pRegister, (int)(TL.v[0]*16.0f), (int)(TL.v[1]*16.0f), (int)(TL.v[2]), 0);
	
	//bottom left
	AddUV(pRegister, pSprite->u, pSprite->v + pSprite->h);
	AddVertexFP(pRegister,  (int)(BL.v[0]*16.0f), (int)(BL.v[1]*16.0f), (int)(BL.v[2]), 0);
	
	//top right
	AddUV(pRegister, pSprite->u + pSprite->w, pSprite->v);
	AddVertexFP(pRegister,  (int)(TR.v[0]*16.0f), (int)(TR.v[1]*16.0f), (int)(TR.v[2]), 0);
	
	//bottom right
	AddUV(pRegister, pSprite->u + pSprite->w, pSprite->v + pSprite->h);
	AddVertexFP(pRegister,  (int)(BR.v[0]*16.0f), (int)(BR.v[1]*16.0f), (int)(BR.v[2]), 0);

	// Work out how much we just wrote
	int iWC = (int)pRegister - (int)pMem;
	//int iQWC = iWC >> 4;

	// Assert that we haven't written more data than we allocated
	assert(iWC < 4096);
	
	//Set the memory pointer we used to the next free location
	pMem = (char *)pRegister;
	
	//return the number of bytes written to memory
	return iWC;
}

