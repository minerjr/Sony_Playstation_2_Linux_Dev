Move the character using the controller.

The rotation of the sprite is controlled with the left hand side of the controller: 
left and right control rotation round the local z axis, 
up and down control rotation round the local y axis
L1 and L2 control rotation round the local x axis. 

The translation of the sprite is controlled with the right hand half of the controller: 
Circle and square control movement in the local x axis, 
Triangle and cross control movement in the local y axis 
R1 and R2 control movement in the local z axis


Press select and start together to end the program.

All the button presses are pressure sensitive - 
the harder you press the more the effect.
