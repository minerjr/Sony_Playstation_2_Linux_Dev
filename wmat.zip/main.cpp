#include <sps2lib.h>
#include <sps2tags.h>
#include <sps2util.h>
#include <assert.h>
#include "PS2Defines.h"
#include "PS2Types.h"
#include "AddRegisters.h"
#include "texture.h"
#include "packet.h"
#include "pad.h"
#include "vecmaths.h"

// Work out how we are going to allocate SPS2 to each use:
// Here we have 4K allocated for primitives, that is right at the start of the memory
// Next, 256K allocated for the texture.
// Finally 4K allocated for the texture upload function to use for DMAing
// (The KILOBYTES macro just multiplies the number by 1024)
#define PRIMITIVEMEM_4K		0
#define TEXTUREMEM_256K		(KILOBYTES(4))
#define TEXTUREDMAMEM_4K	(KILOBYTES(260))
#define TOTALMEMNEEDED		(KILOBYTES(264))

// Function Prototypes
void MoveSprite(PS2Sprite_t * pSP, float Delta, int Axis);
void AnimateSprite(PS2Sprite_t * pSP, float Count);
void GameLogic(PS2Sprite_t * pSP);

//globals
sps2Memory_t * pMemCached;	//pointer to allocated memory structure
int iSPS2Desc;				//the SPS2 handle

int main(void)
{
	char * pcMemory;			//pointer to start of allocated memory
	char * pPrimitiveMem;		//pointer to the start of primitive memory
	Dn_CHCR_t chcr;				// The DMA registers we will be using. 
	Dn_MADR_t madr;
	PS2Sprite_t Sprite[2];		//some sprite structures to play with
	
	//initialise the pads
	if(pad_init (PAD_0, PAD_INIT_LOCK |PAD_INIT_ANALOGUE | PAD_INIT_PRESSURE) == 0)
		{
		printf("Unable to initialise the pads\n");
		pad_cleanup (PAD_0);
		exit(0);
		}
	
	//initialise the SPS2 module
	iSPS2Desc = sps2Init();
	// Initialise the screen
	sps2UScreenInit(0);

	// Allocate the SPS2 memory
	pMemCached = sps2Allocate(TOTALMEMNEEDED, 
							SPS2_MAP_BLOCK_4K |	SPS2_MAP_CACHED, 
							iSPS2Desc);

	// Get a char pointer, we can use this to access memory addresses
	// relative to the start of SPS2 memory
	pcMemory = (char *)pMemCached->pvStart;
	
	//pointer to the start of primitive memory
	pPrimitiveMem = &pcMemory[PRIMITIVEMEM_4K];

	// Load the 256*256 bitmap into SPS2 memory
	// The final parameter says whether or not to make RGB(0,0,0)
	// transparent
	if(!LoadBitmap("game.bmp", &pcMemory[TEXTUREMEM_256K], true))
	{
		printf("Failed to load texture.");
		return -1;
	}

	// Upload the texture from SPS2 memory into the first free
	// page of GS Memory. 
	// The second parameter is the address of the texture in SPS2 memory
	// The final parameter is 4K of memory that the Upload function can use
	// for creating its own DMA chain.
	Upload(sps2UScreenGetFirstFreeGSPage(), 
			&pcMemory[TEXTUREMEM_256K], 
			&pcMemory[TEXTUREDMAMEM_4K]);

	
	// Configure the Sprite Structures
	
	// Set identity matrix to identity
	IdentityMatrix(&Sprite[0].World);
	
	Sprite[0].Pos.v[0] = 0.0f;
	Sprite[0].Pos.v[1] = 0.0f;
	Sprite[0].Pos.v[2] = 100.0f;
	Sprite[0].Pos.v[3] = 1.0f;
	Sprite[0].w = 32;
	Sprite[0].h = 32;
	
	
	// Untransformed Sprite positions
	// Top Left
	Sprite[0].TL.v[0] = -(float)(Sprite[0].w/2);;
	Sprite[0].TL.v[1] = -(float)(Sprite[0].h/2);
	Sprite[0].TL.v[2] = 0.0f;
	Sprite[0].TL.v[3] = 1.0f;
	// Bottom Left
	Sprite[0].BL.v[0] = -(float)(Sprite[0].w/2);
	Sprite[0].BL.v[1] =  (float)(Sprite[0].h/2);
	Sprite[0].BL.v[2] = 0.0f;
	Sprite[0].BL.v[3] = 1.0f;
	// Top Right
	Sprite[0].TR.v[0] =  (float)(Sprite[0].w/2);
	Sprite[0].TR.v[1] = -(float)(Sprite[0].h/2);
	Sprite[0].TR.v[2] = 0.0f;
	Sprite[0].TR.v[3] = 1.0f;
	// Bottom Right
	Sprite[0].BR.v[0] = (float)(Sprite[0].w/2);
	Sprite[0].BR.v[1] = (float)(Sprite[0].h/2);
	Sprite[0].BR.v[2] = 0.0f;
	Sprite[0].BR.v[3] = 1.0f;
	// UV Texture offsets
	Sprite[0].u = 32;
	Sprite[0].v = 0;
	// Colour
	Sprite[0].r = 0x80;
	Sprite[0].g = 0x80;
	Sprite[0].b = 0x80;
	Sprite[0].a = 0x80;
	// Animation parameters
	Sprite[0].FCountMax = 5;	
	Sprite[0].FCount = 0;
	Sprite[0].NFrames = 8;
	// Rotation angle
	Sprite[0].RotX = 0.0f;
	Sprite[0].RotY = 0.0f;
	Sprite[0].RotZ = 0.0f;

	//get the required register values
	// Clear the register to zero	
	madr.i32 = 0;		
	// Set the address field to the physical address of the allocated mem
	madr.s.ADDR = sps2GetPhysicalAddress(pPrimitiveMem, pMemCached);
	
	// The channel control register
	chcr.i32 = 0;
	chcr.s.MOD = CHCR_MOD_NORMAL;	// Normal mode transfer
	chcr.s.STR = 1;					// Start the transfer

	// We want to send the packet to the GS every frame
	do
	{	
		//update the pad structure
		pad_update (PAD_0);
		
		//reset the pointer to the start of primitive memory
		pPrimitiveMem = &pcMemory[PRIMITIVEMEM_4K]; 
		
		//clear the screen to the specified colour
		sps2UScreenClear(0x20, 0x00, 0x10);
		
		// Perform the logic for the game
		GameLogic(Sprite);
		
		//build the GS packet
		//BuildSprite2D(&Sprite[1], pPrimitiveMem);
		BuildSprite2D(&Sprite[0], pPrimitiveMem);
		
		//calculate how many qwords have been written
		int iQWC = ((int)pPrimitiveMem - (int)&pcMemory[PRIMITIVEMEM_4K]) >> 4;
	
		// Assert that we haven't written more data than we allocated
		assert(iQWC < (4096 >> 4));	
	
		// Important: Make sure all the data is written to the physical memory
		sps2FlushCache(iSPS2Desc);
				
		// DMA Channel 2 is the one we want, it goes to the GS
		// Amount of data to be transmitted
		*EE_D2_QWC = iQWC;	

		// Set the memory address register
		*EE_D2_MADR = madr.i32;
		
		// Set the register to start the transfer
		*EE_D2_CHCR = chcr.i32;	

		// Wait for it to complete
		sps2WaitForDMA(2, iSPS2Desc);

		// Display the buffer we were just drawing to
		sps2UScreenSwap();
		
	}while(!((pad[0].buttons & PAD_START)&&(pad[0].buttons & PAD_SELECT)));
	
	pad_cleanup (PAD_0);
	
	// Shutdown the screen
	sps2UScreenShutdown();

	// Release SPS2
	sps2Release(iSPS2Desc);

	return 0;
}

// Perform the logic for the game
void GameLogic(PS2Sprite_t * pSP)
{
	//rotate the sprite round z axis
	if(pad[0].buttons & PAD_RIGHT)pSP[0].RotZ += pad[0].pressures[PAD_PRIGHT] * 0.2f;
	if(pad[0].buttons & PAD_LEFT) pSP[0].RotZ -= pad[0].pressures[PAD_PLEFT] * 0.2f;
	
	//rotate the sprite round y axis
	if(pad[0].buttons & PAD_UP)pSP[0].RotY += pad[0].pressures[PAD_PUP] * 0.2f;
	if(pad[0].buttons & PAD_DOWN) pSP[0].RotY -= pad[0].pressures[PAD_PDOWN] * 0.2f;
	
	//rotate the sprite round x axis
	if(pad[0].buttons & PAD_L1)pSP[0].RotX += pad[0].pressures[PAD_PL1] * 0.2f;
	if(pad[0].buttons & PAD_L2) pSP[0].RotX -= pad[0].pressures[PAD_PL2] * 0.2f;

	//move along local x and animate the sprite
	if(pad[0].buttons & PAD_SQUARE)
	{
		MoveSprite(&pSP[0], -pad[0].pressures[PAD_PSQUARE] * 3.0f, XAXIS);
		AnimateSprite(&pSP[0], pad[0].pressures[PAD_PSQUARE]);
	}
		
	if(pad[0].buttons & PAD_CIRCLE)
	{
		MoveSprite(&pSP[0], pad[0].pressures[PAD_PCIRCLE] * 3.0f, XAXIS);
		AnimateSprite(&pSP[0], pad[0].pressures[PAD_PCIRCLE]);
	}
		
	//move along local y and animate the sprite
	if(pad[0].buttons & PAD_TRI)
	{
		MoveSprite(&pSP[0], pad[0].pressures[PAD_PTRI] * 3.0f, YAXIS);
		AnimateSprite(&pSP[0], pad[0].pressures[PAD_PTRI]);
	}
		
	if(pad[0].buttons & PAD_CROSS)
	{
		MoveSprite(&pSP[0], -pad[0].pressures[PAD_PCROSS] * 3.0f, YAXIS);
		AnimateSprite(&pSP[0], pad[0].pressures[PAD_PCROSS]);
	}
	
	//move along local z and animate the sprite
	if(pad[0].buttons & PAD_R1)
	{
		MoveSprite(&pSP[0], pad[0].pressures[PAD_PR1] * 3.0f, ZAXIS);
		AnimateSprite(&pSP[0], pad[0].pressures[PAD_PR1]);
	}
	
	if(pad[0].buttons & PAD_R2)
	{
		MoveSprite(&pSP[0], -pad[0].pressures[PAD_PR2] * 3.0f, ZAXIS);
		AnimateSprite(&pSP[0], pad[0].pressures[PAD_PR2]);
	}
}

//move sprite in the direction it is pointing
void MoveSprite(PS2Sprite_t * pSP, float Delta, int Axis)
{
	//this moves the sprite along its local "Axis" axis
	// by an amount Delta
	pSP->Pos.v[0] += pSP->World.m[0][Axis]* Delta;
	pSP->Pos.v[1] += pSP->World.m[1][Axis]* Delta;
	pSP->Pos.v[2] += pSP->World.m[2][Axis]* Delta;
}

//some very simple animation
void AnimateSprite(PS2Sprite_t * pSP, float Count)
{
	int FCountMax = 8 - (int)(6.0f * Count);
	if((pSP->FCount++)%FCountMax == 0)
		{
			pSP->v += pSP->h;
			if(pSP->v > (pSP->NFrames - 1) * pSP->h)pSP->v = 0;
		}
}