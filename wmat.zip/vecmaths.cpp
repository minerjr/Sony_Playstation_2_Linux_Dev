// 
// Some standard vector and matrix mathematics functions
// Using Fast Mathematics functions
//

// Define this in order to use the hand crafted "FAST" assembly maths
// Remove this line to use standard maths functions
#define PS2Maths


#include <stdio.h>
#include <math.h>
#include "vecmaths.h"


#ifdef PS2Maths

	#include "PS2Maths.h"
	
	// PS2 Maths functions
	#define _cos_(x) (Cos(x))
	#define _sin_(x) (Sin(x))
	#define _sqrt_(x) (Sqrt(x))

#else

	// Maths.h functions
	#define _cos_(x) (cosf(x))
	#define _sin_(x) (sinf(x))
	#define _sqrt_(x) (sqrtf(x))

#endif




// ==========================================================================
// void CopyFVector(FVector * v0, FVector * v1)
// Input: v1
// Output v0
// vector v1 is copied unchanged to vector v0
// --------------------------------------------------------------------------
void CopyFVector(FVector * v0, FVector * v1)
{
  v0->v[0] = v1->v[0];
  v0->v[1] = v1->v[1];
  v0->v[2] = v1->v[2];
  v0->v[3] = v1->v[3];
}


// ==========================================================================
// void IdentityMatrix(FMatrix * m)
// Input: m 
// Output: m
// Identity matrix is produced
// --------------------------------------------------------------------------
void IdentityMatrix(FMatrix * m)
{
  int i,j;
  for(i=0; i<4; i++){
    for(j=0; j<4; j++){
      m->m[i][j] = (i==j)? 1.0f : 0.0f;
    }
  }
}


// ==========================================================================
// void ApplyMatrix(FVector * v0, FMatrix * m0, FVector * v1)
// Input: m0, v1
// Output v0
// v0=m0*v1
// vector v1 is multiplied by matrix m0
// --------------------------------------------------------------------------
void ApplyMatrix(FVector * v0, FMatrix * m0, FVector * v1)
{
  FVector v;
  v.v[0] = v1->v[0]*m0->m[0][0] + v1->v[1]*m0->m[0][1] + v1->v[2]*m0->m[0][2] + v1->v[3]*m0->m[0][3];
  v.v[1] = v1->v[0]*m0->m[1][0] + v1->v[1]*m0->m[1][1] + v1->v[2]*m0->m[1][2] + v1->v[3]*m0->m[1][3];
  v.v[2] = v1->v[0]*m0->m[2][0] + v1->v[1]*m0->m[2][1] + v1->v[2]*m0->m[2][2] + v1->v[3]*m0->m[2][3];
  v.v[3] = v1->v[0]*m0->m[3][0] + v1->v[1]*m0->m[3][1] + v1->v[2]*m0->m[3][2] + v1->v[3]*m0->m[3][3];
  CopyFVector(v0, &v);
}


// ==========================================================================
// 	void SubVector(FVector * v0, FVector * v1, FVector * v2)
// Input: v1, v2
// Output v0
// v0 = v1 - v2
// --------------------------------------------------------------------------
void SubVector(FVector * v0, FVector * v1, FVector * v2)
{
  v0->v[0] = v1->v[0] - v2->v[0];
  v0->v[1] = v1->v[1] - v2->v[1];
  v0->v[2] = v1->v[2] - v2->v[2];
  v0->v[3] = v1->v[3] - v2->v[3];
}


// ==========================================================================
// void Normalise(FVector * v0, FVector * v1)
// Input v1
// Output v0
// v0 is normalised version of v1
// --------------------------------------------------------------------------
void Normalise(FVector * v0, FVector * v1)
{
  	float norm, dnorm;
  	norm = _sqrt_( v1->v[0] * v1->v[0] + v1->v[1] * v1->v[1] + v1->v[2] * v1->v[2] );
  	if(norm > 0.0f)
  	{
    	dnorm = 1.0f/norm;
    	v0->v[0] = v1->v[0]*dnorm;
    	v0->v[1] = v1->v[1]*dnorm;
    	v0->v[2] = v1->v[2]*dnorm;
    	v0->v[3] = v1->v[3];
  	}
}


// ==========================================================================
// void CrossProduct(FVector * v0, FVector * v1, FVector * v2)
// Input v1, v2
// Output v0
// v0 = v1 x v2
// --------------------------------------------------------------------------
void CrossProduct(FVector * v0, FVector * v1, FVector * v2)
{
  v0->v[0] = v1->v[1] * v2->v[2] - v1->v[2] * v2->v[1];
  v0->v[1] = v1->v[2] * v2->v[0] - v1->v[0] * v2->v[2];
  v0->v[2] = v1->v[0] * v2->v[1] - v1->v[1] * v2->v[0];
  v0->v[3] = 1.0f;
}


// ==========================================================================
// float DotProduct(FVector * v0, FVector * v1)
// Input v0, v1
// returns dot product v0.v1
// --------------------------------------------------------------------------
float DotProduct(FVector * v0, FVector * v1)
{
  return (v0->v[0]*v1->v[0] + v0->v[1]*v1->v[1] + v0->v[2]*v1->v[2]);
}



// ==========================================================================
// void MulMatrix(FMatrix * m0, FMatrix * m1, FMatrix * m2)
// Input m1, m2
// Output mo
// m0=m1*m2
// --------------------------------------------------------------------------
void MulMatrix(FMatrix * m0, FMatrix * m1, FMatrix * m2)
{

  int i, j;
  FMatrix m;
   for(i=0; i<4; i++){
     for(j=0; j<4; j++){
       m.m[i][j] = m1->m[i][0] * m2->m[0][j] + m1->m[i][1] * m2->m[1][j]
	 + m1->m[i][2] * m2->m[2][j] + m1->m[i][3] * m2->m[3][j];
     }
   }
   CopyMatrix(m0, &m);
}

// ==========================================================================
// void CopyMatrix(FMatrix * m0, FMatrix * m1)
// Input m1
// Output m0
// m0 os made a copy of m1
// --------------------------------------------------------------------------
void CopyMatrix(FMatrix * m0, FMatrix * m1)
{
  int i,j;
  for(i=0; i<4; i++){
    for(j=0; j<4; j++){
      m0->m[i][j] = m1->m[i][j];
    }
  }
}


// ==========================================================================
// void DumpFVector(char *s, FVector * v)
// Input v, s
// Output 
// Dump vector contents to the console
// --------------------------------------------------------------------------
void DumpFVector(char *s, FVector * v)
{
	printf(s);
	printf("\t\t[%f,\t%f,\t%f,\t%f]\n\n",  v->v[0], v->v[1], v->v[2], v->v[3]);
}

// ==========================================================================
// void DumpFVector(char *s, IVector * v)
// Input v, s
// Output 
// Dump vector contents to the console
// --------------------------------------------------------------------------
void DumpIVector(char *s, IVector * v)
{
	printf(s);
	printf("\t\t[%d,\t%d,\t%d,\t%d]\n\n",  v->v[0], v->v[1], v->v[2], v->v[3]);
}

// ==========================================================================
// void DumpMatrix(char *s, FMatrix * m)
// Input m, s
// Output 
// Dump matrix contents to the console
// --------------------------------------------------------------------------
void DumpMatrix(char *s, FMatrix * m)
{
	printf(s);
	printf("\t\t[%f,\t%f,\t%f,\t%f]\n",   m->m[0][0], m->m[0][1], m->m[0][2], m->m[0][3]);
	printf("\t\t[%f,\t%f,\t%f,\t%f]\n",   m->m[1][0], m->m[1][1], m->m[1][2], m->m[1][3]);
	printf("\t\t[%f,\t%f,\t%f,\t%f]\n",   m->m[2][0], m->m[2][1], m->m[2][2], m->m[2][3]);
	printf("\t\t[%f,\t%f,\t%f,\t%f]\n\n", m->m[3][0], m->m[3][1], m->m[3][2], m->m[3][3]);	

}


// ==========================================================================
// void RotMatrixY(FMatrix * m0, FMatrix * m1, float ry)
// Input m1, ry
// Output m0
// Rotate matrix m1 by ry radians round y axis and output result in m0
// --------------------------------------------------------------------------
void RotMatrixY(FMatrix * m0, FMatrix * m1, float ry)
{
	float cost, sint;	
  	FMatrix rot;

  	cost = _cos_(ry);
  	sint = _sin_(ry);  	
  	
  	IdentityMatrix(&rot);

	rot.m[0][0] = cost; 
  	rot.m[2][0] = sint;
  	rot.m[0][2] = -sint; 
  	rot.m[2][2] = cost;
  	MulMatrix(m0, &rot, m1);
}

// ==========================================================================
// void RotMatrixX(FMatrix * m0, FMatrix * m1, float ry)
// Input m1, ry
// Output m0
// Rotate matrix m1 by rx radians round x axis and output result in m0
// --------------------------------------------------------------------------
void RotMatrixX(FMatrix * m0, FMatrix * m1, float rx)
{
	float cost, sint;	
  	FMatrix rot;
  	
  	cost = _cos_(rx);
  	sint = _sin_(rx);
  	
  	IdentityMatrix(&rot);
  
  	rot.m[1][1] = cost; 
  	rot.m[1][2] = -sint;
  	rot.m[2][1] = sint; 
  	rot.m[2][2] = cost;
  	MulMatrix(m0, &rot, m1);
}

// ==========================================================================
// void RotMatrixZ(FMatrix * m0, FMatrix * m1, float ry)
// Input m1, rz
// Output m0
// Rotate matrix m1 by rz radians round x axis and output result in m0
// --------------------------------------------------------------------------
void RotMatrixZ(FMatrix * m0, FMatrix * m1, float rz)
{
	float cost, sint;	
  	FMatrix rot;
  
  	cost = _cos_(rz);
  	sint = _sin_(rz);
  
  	IdentityMatrix(&rot);
  	rot.m[0][0] = cost; 
  	rot.m[0][1] = -sint;
  	rot.m[1][0] = sint; 
  	rot.m[1][1] = cost;
  	MulMatrix(m0, &rot, m1);
}

// ==========================================================================
// void RotMatrix(FMatrix * m0, FMatrix * m1, float rz, float ry, float rx)
// Input m1, rx, ry, rz
// Output m0
// Rotate matrix m1 by specified amount round all axes and output result in m0
// --------------------------------------------------------------------------
void RotMatrix(FMatrix * m0, FMatrix * m1, float rz, float ry, float rx)
{
  RotMatrixZ(m0, m1, rz);
  RotMatrixY(m0, m0, ry);
  RotMatrixX(m0, m0, rx);
}

// ==========================================================================
// void ScaleMatrix(FMatrix * m0, FMatrix * m1, float Scl)
// Input m1, Sci
// Output m0
// Scale matrix m1 by amount Sci and output result in m0
// --------------------------------------------------------------------------
void ScaleMatrix(FMatrix * m0, FMatrix * m1, float Scl)
{
	FMatrix Scale;
    
  	IdentityMatrix(&Scale);
  	
  	Scale.m[0][0] = Scl; 
  	Scale.m[1][1] = Scl;
  	Scale.m[2][2] = Scl; 

  	MulMatrix(m0, &Scale, m1);
}