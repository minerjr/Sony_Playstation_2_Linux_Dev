		*******	JAYTEEMASTER *******
		jayteemaster2003@yahoo.com.br
             www.geocities.com/jayteemaster2003

			  presents           



         	   * CDLOADER FOR PS2 V7 *
			   (BETA 3)
			 08/09/2003

       	!!!!! BYE BYE DOUBLE CHECK PROTECTION !!!!!!



DESCRIPTION:
	This is the famous CDLOADER now working on V7.

FEATURES:
	1. Now it should boot every single elf game
	1. Compatible with multiple elf games
	2. No PAL/NTSC selector


SUPPORT:
	You may support by providing me FAST FTPs with PS2 Rips!




??? DO YOU WANT TO HAVE PUBLICITY OF YOUR COMPANY IN FUTURE RELEASE ???
			  * Just contact me *
