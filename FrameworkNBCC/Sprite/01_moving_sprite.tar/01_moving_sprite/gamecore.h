

#ifndef _GAME_CORE_H_
#define _GAME_CORE_H_

class CGameCore
{
	public:
	CGameCore();
	~CGameCore();

	int MoveSprite(int dx, int dy);
	int DisplaySprite();

	private:
	float angle;
	int centerx, centery, width, height;
	__u64 *bgpkt;
};

#endif

