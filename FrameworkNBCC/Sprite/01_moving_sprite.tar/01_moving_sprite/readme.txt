

01_moving_sprite
2002-08-18
Lionel Lemarie - hikey@playstation2-linux.com

First installement of a series of tutorials.
This aims to show basic setup of the devices on the PlayStation2 and provide a
framework to build your application without having to worry about initialising
everything, which can turn out to be very annoying. It has been designed in a
way that allows the programmer to keep his code separate from the actual
harness.


This first sample demonstrate how to easily:
- Set up the different devices: GS, VUs, PAD, SPR...
- Automatically setup the display in PAL, NTSC or VESA depending on the current
  mode of the console.
- Setup the frame buffers and Z buffer, swap the buffer, clear the screen.
- Access the hardware without using the expensive libps2dev library.
- Build a simple packet to send to the GIF.
- No DMA in this sample (this is a bad thing).
- Simple use of the controller though joypad lib (*).


IMPORTANT NOTICE:

The frame buffers are not setup properly at all and there are display problems
that I am aware of. They all will be corrected in the second version, but in
the meantime, do not use that framework for your applications, unless you want
to correct the problems it has, which isn't hard really.



(*) The joypad library has been developed by Derek Nedelman and can be found
here : http://playstation2-linux.com/projects/joypadlib

