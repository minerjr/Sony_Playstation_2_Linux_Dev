
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <malloc.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <linux/ps2/dev.h>

#include "gamecore.h"
#include "harness/harness.h" // temporary, to be removed when code is better

#define _DPRINTF 1
#define DPRINTF if (_DPRINTF) printf


char *format_number(int number); // implemented in main.c

CGameCore::CGameCore()
{
	bgpkt=(__u64*)memalign(16, 16*1024); // that's far too much, but can't be arsed counting it
	angle=0;
	centerx=0;
	centery=0;
}

CGameCore::~CGameCore()
{
	free(bgpkt);
}

int CGameCore::MoveSprite(int dx, int dy)
{
	centerx+=dx;
	centery+=dy;

	return 1;
}


int CGameCore::DisplaySprite()
{

	width=(int)(100.0f*cosf(angle+=M_PI/200.0f));
	height=(int)(100.0f*cosf(angle*2.0f));

	int bglen=0;

	*(bgpkt+bglen++)= 0; // top half of GIF tag to be filled at the end to get the size

	*(bgpkt+bglen++)= PS2_GIFTAG_REGS_AD; // bottom half of the GIF tag

	*(bgpkt+bglen++)=
		PS2_GS_SETREG_RGBAQ( 0x50,0x50,0x50,0x0,0x0 );
	*(bgpkt+bglen++)=
		PS2_GS_RGBAQ;

	*(bgpkt+bglen++)=
		PS2_GS_SETREG_PRIM( 	PS2_GS_PRIM_PRIM_SPRITE,
				PS2_GS_PRIM_IIP_FLAT ,
				PS2_GS_PRIM_TME_OFF,
				PS2_GS_PRIM_FGE_OFF,
				PS2_GS_PRIM_ABE_OFF,
				PS2_GS_PRIM_AA1_OFF,
				PS2_GS_PRIM_FST_UV,
				PS2_GS_PRIM_CTXT_CONTEXT1,
				PS2_GS_PRIM_FIX_NOFIXDDA );
	*(bgpkt+bglen++)= PS2_GS_PRIM;

	*(bgpkt+bglen++)=
		PS2_GS_SETREG_XYZ2( 32768-(width*8)+centerx*16,32768-(height*8)+centery*16,1 );
	*(bgpkt+bglen++)= PS2_GS_XYZ2;

	*(bgpkt+bglen++)=
		PS2_GS_SETREG_XYZ2( 32768+(width*8)+centerx*16,32768+(height*8)+centery*16,1 );
	*(bgpkt+bglen++)= PS2_GS_XYZ2;

	// write the top half of the GIF tag with calculated size
	*(bgpkt)=
		PS2_GIFTAG_SET_TOPHALF( (bglen*8/16) -1,
				1,1,
				PS2_GS_SETREG_PRIM(	PS2_GS_PRIM_PRIM_SPRITE,
							PS2_GS_PRIM_IIP_FLAT ,
							PS2_GS_PRIM_TME_ON,
							PS2_GS_PRIM_FGE_OFF,
							PS2_GS_PRIM_ABE_OFF,
							PS2_GS_PRIM_AA1_OFF,
							PS2_GS_PRIM_FST_UV,
							PS2_GS_PRIM_CTXT_CONTEXT1,
							PS2_GS_PRIM_FIX_NOFIXDDA ),
				PS2_GIFTAG_FLG_PACKED,1 );

	// ooh, so not the right way to do it...
	if (-1==write( gs_fd, bgpkt, bglen*8 ))
	{
		DPRINTF("write in draw sprite: %s\n", strerror(errno));
		return 0;
	}
	fsync(gs_fd);

	return 1;
}

