
#include <stdio.h>
#include <unistd.h>
#include <linux/ps2/dev.h>
#include "harness/harness.h"
#include "harness/joypadlib.h"
#include "gamecore.h"

#define _DPRINTF 1
#define DPRINTF if (_DPRINTF) printf

int loop_again=1;
int frame_cnt=0;
vucode_t basic = { "basic vu code", "vucode.bin", NULL };
unsigned long pad_buttons;
unsigned char pad_button_pressures[PS2PAD_NUM_PRESSURE_BUTTONS];
float pad_left_stick[2], pad_right_stick[2];
int pad_active_joypad = 0;

CGameCore *gamecore=NULL;

typedef struct
{
	qword_t position;
	float direction;
	float steering;
	float speed;
} car_t;

void game_init();
void game_update_pad();
void game_deinit(int sig);
int main(int argc, char **argv);

int main(int argc, char **argv)
{
	har_init();

	har_load_vu1_mpg(&basic);

	game_init();

	har_set_quit_callback(game_deinit);

	while (loop_again>0)
	{
		har_wait_vsync();
		har_setup_gs(!frame_cnt);
		har_clear_screen(frame_cnt);
		frame_cnt++;

		game_update_pad();

		// game code

		gamecore->DisplaySprite();

	}

	game_deinit(0);

	har_deinit();

	return 0;
}

void game_update_pad()
{
	joypadlib_update();
	pad_buttons = joypadlib_get_joypad_buttons(pad_active_joypad, pad_button_pressures, PRESSURE_TYPE_BYTE);
	joypadlib_get_joypad_sticks(pad_active_joypad, pad_left_stick, pad_right_stick);

	// update variables

	if (pad_buttons & PS2PAD_BUTTON_START) loop_again=0;

	{
		int dx=0, dy=0;

		if (pad_buttons & PS2PAD_BUTTON_DOWN) dy++;
		if (pad_buttons & PS2PAD_BUTTON_UP) dy--;
		if (pad_buttons & PS2PAD_BUTTON_RIGHT) dx++;
		if (pad_buttons & PS2PAD_BUTTON_LEFT) dx--;

		gamecore->MoveSprite(dx, dy);
	}
}

void game_init()
{
	DPRINTF("initing controllers: "); fflush(stdout);
	joypadlib_initialize();
	DPRINTF("Ok\n");


	// game init

	gamecore=new CGameCore();
}

void game_deinit(int sig)
{
	DPRINTF("deiniting controllers: "); fflush(stdout);
	joypadlib_shutdown();
	DPRINTF("Ok\n");

	// game deinit

	delete gamecore;
	gamecore=NULL;
}

char *format_number(int number)
{
	static int idx=0;
	static char buffer[8][16];
	int cnt2, cnt3;

	idx=(idx+1)%8;

	sprintf(buffer[idx], "%d", number);
	for (cnt2=strlen(buffer[idx])-3; cnt2>0; cnt2-=3)
	{
		for (cnt3=strlen(buffer[idx])+1; cnt3>cnt2; cnt3--)
		{
			buffer[idx][cnt3]=buffer[idx][cnt3-1];
		}
		buffer[idx][cnt2]=',';
	}

	return buffer[idx];
}

