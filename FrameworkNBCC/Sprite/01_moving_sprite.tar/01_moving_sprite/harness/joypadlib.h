/*
FILE: joypadlib.h
DESCRIPTION: The joypad library header (and documentation) file
WRITTEN BY: Derek Nedelman (nedelman@netzero.net)
DATE: June 19, 2002
*/

#ifndef JOYPADLIB_INCLUDED
#define JOYPADLIB_INCLUDED

#include <linux/ps2/pad.h>

void joypadlib_initialize(void);		//Call first to set up joypad library
void joypadlib_shutdown(void);			//Call before closing program

int joypadlib_num_supported_joypads(void);	//Returns the number of supported joypads

void joypadlib_update(void);			//Call at the beginning of each frame to update all the joypad data


//	Function: joypadlib_get_joypad_buttons - Retrieves the button press information for the specified joypad. 
//	In: joypad - Index of the joypad for which button info should be obtained. Typically 0 or 1.
//	Out: button_pressures - Optional array of unsigned chars or floats that will receive the button pressures. May be NULL
//		If non-NULL, the array MUST contain PS2PAD_NUM_PRESSURE_BUTTONS entries
//	In: type - The type of array that 'button_pressures' points to
//		PRESSURE_TYPE_NONE - No array passed in
//		PRESSURE_TYPE_BYTE - 'button_pressures' points to an array of unsigned chars (range: 0 through 255)
//		PRESSURE_TYPE_FLOAT - 'button_pressures' points to an array of floats (range: -1 through 1)
//	Return value: An unsigned long that contains the on/off state of the joypad buttons. The individual states may
//		      be masked off by the PS2PAD_BUTTON_* constants in the linux/ps2/pad.h header file

//Used to access the array of pressures returned by joypadlib_get_joypad_buttons()
#define PS2PAD_PRESSURE_DIGITAL_RIGHT	0
#define PS2PAD_PRESSURE_DIGITAL_LEFT	1
#define PS2PAD_PRESSURE_DIGITAL_UP	2
#define PS2PAD_PRESSURE_DIGITAL_DOWN	3
#define PS2PAD_PRESSURE_TRIANGLE	4
#define PS2PAD_PRESSURE_CIRCLE		5
#define PS2PAD_PRESSURE_CROSS		6
#define PS2PAD_PRESSURE_SQUARE		7
#define PS2PAD_PRESSURE_L1		8
#define PS2PAD_PRESSURE_R1		9
#define PS2PAD_PRESSURE_L2		10
#define PS2PAD_PRESSURE_R2		11
#define PS2PAD_NUM_PRESSURE_BUTTONS	12

//For the 'type' parameter of joypadlib_get_joypad_buttons()
#define PRESSURE_TYPE_NONE	0	//No array passed in
#define PRESSURE_TYPE_BYTE	1	//'button_pressures' points to an array of unsigned chars (range: 0 through 255)
#define PRESSURE_TYPE_FLOAT	2	//'button_pressures' points to an array of floats (range: -1 through 1)

unsigned long joypadlib_get_joypad_buttons(int joypad, void* button_pressures, int type);


//	Function: joypadlib_get_joypad_sticks - Retrieves the analog stick information for the specified joypad. 
//	In: joypad - Index of the joypad for which stick info should be obtained. Typically 0 or 1.
//	Out: left_stick, right_stick - Arrays of 2-floats that receive the stick information.
//		Entry 0 contains the X-axis info, Entry 1 contains the Y-axis info
//		All returned values are in the range -1 through 1
void joypadlib_get_joypad_sticks(int joypad, float left_stick[2], float right_stick[2]);


//	Function: joypadlib_joypad_supports_pressure - Indicates whether or not the specified joypad supports
//		pressure-sensitive buttons.
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	Return value: 
//		0 - The joypad doesn't support pressure-sensitive buttons
//		1 - The joypad supports pressure-sensitive buttons
int joypadlib_joypad_supports_pressure(int joypad);

//	Function: joypadlib_get_joypad_status - Retrieves the status of the specified joypad.
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	Return value: (These values are defined in the linux/ps2/pad.h header file)
// 		PS2PAD_STAT_NOTCON - Joypad not connected
//		PS2PAD_STAT_READY - Joypad ready
//		PS2PAD_STAT_BUSY - Joypad busy
//		PS2PAD_STAT_ERROR - Error
int joypadlib_get_joypad_status(int joypad);


//	Function: joypadlib_get_joypad_type - Retrieves the type of the specified joypad.
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	Return value: (These values are defined in the linux/ps2/pad.h header file)
//		PS2PAD_TYPE_NEJICON - Namco Nejicon
//		PS2PAD_TYPE_DIGITAL - Old-style Playstation 1 controller. No analog support
//		PS2PAD_TYPE_ANALOG - Old-style "Dual-shock" controller. No vibration function
//		PS2PAD_TYPE_DUALSHOCK - Either the Playstation 1 or 2 Dual Shock controller
int joypadlib_get_joypad_type(int joypad);


//	Function: joypadlib_get_joypad_num_modes - Retrieves the number of modes supported by the specified joypad.
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	Return value: The number of modes supported by the joypad
int joypadlib_get_joypad_num_modes(int joypad);


//	Function: joypadlib_get_joypad_mode - Retrieves the ID of the specified mode_index for the specified joypad
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	In: mode_index - Index of the mode ID that should be obtained. 
//		Ranges from 0 to joypadlib_get_joypad_num_modes(joypad) - 1
//	Return value: 
//		MODE_DIGITAL - Analog-less mode
//		MODE_ANALOG - Analog and digital mode

#define MODE_DIGITAL	4
#define MODE_ANALOG	7

int joypadlib_get_joypad_mode(int joypad, int mode_index);


//	Function: joypadlib_set_joypad_mode - Sets the mode for the specified joypad
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	In: mode - The mode ID that should be selected for the joypad. Either MODE_DIGITAL or MODE_ANALOG
//	In: lock_unlock - Indicates how the mode should be locked into the joypad
//		MODE_UNLOCK - The mode is unlocked. The user may toggle the "Analog" button on the joypad
//		MODE_LOCK - The mode is locked. The user can't toggle the "Analog" button on the joypad
//	Return value: 
//		0 - The joypad doesn't support the specified mode
//		1 - The joypad supports the specified mode

#define MODE_UNLOCK	1
#define MODE_LOCK	2

int joypadlib_set_joypad_mode(int joypad, int mode, int lock_unlock);


//	Function: joypadlib_get_joypad_num_actuators - Retrieves the number of actuators available in the joypad
//	In: joypad - Index of the joypad for which info should be obtained. Typically 0 or 1.
//	Return value: The number of actuators the joypad has. 
//		0 - The joypad has no vibration capability
//		2 - The most usual value
int joypadlib_get_joypad_num_actuators(int joypad);


//	Function: joypadlib_enable_joypad_actuators - Enables or disables the joypad's actuators. This doesn't
//		cause a vibration, it simply allows for the vibration
//	In: joypad - Index of the joypad that should have its actuators enabled or disabled. Typically 0 or 1.
//	In: enable_small - 0 to disable or 1 to enable the "small" actuator. This actuator has a smooth
//		constant vibration that can be turned on or off
//	In: enable_big - 0 to disable or 1 to enable the "big" actuator. This actuator has a rough vibration
//		that can have varying intensity
void joypadlib_enable_joypad_actuators(int joypad, int enable_small, int enable_big);


//	Function: joypadlib_set_joypad_actuators - Sets the vibration for the joypad
//	In: joypad - Index of the joypad for which vibration should be set. Typically 0 or 1.
//	In: small_intensity - 0 for off, 1 for on
//	In: big_intensity - Between 0 and 255 to vary the "big" actuator's intensity
void joypadlib_set_joypad_actuators(int joypad, unsigned char small_intensity, unsigned char big_intensity);


#endif
