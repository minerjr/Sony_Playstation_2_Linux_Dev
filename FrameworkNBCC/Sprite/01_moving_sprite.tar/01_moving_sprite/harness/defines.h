
#ifndef __DEFINES_HIK_H__
#define __DEFINES_HIK_H__


typedef unsigned int u_long128 __attribute__ ((mode(TI)));
typedef   signed int   long128 __attribute__ ((mode(TI)));
typedef unsigned int u_long64  __attribute__ ((mode(DI)));

#define GIF_SET_TAG(nloop, eop, pre, prim, flg, nreg) \
	((u_long128)(nloop) | ((u_long128)(eop)<<15) | ((u_long128)(pre) << 46) | \
	 ((u_long128)(prim)<<47) | ((u_long128)(flg)<<58) | ((u_long128)(nreg)<<60))

#define GOURAUD(x) (x)
#define TEXTURED(x) (x)
#define EOP(x) (x)
#define PRE(x) (x)
#define NREG(x) (x)
#define NLOOP(x) (x)

#define FLOAT_ONE (0x3f800000)

#define GIF_PACKED  (0x00)

#define V2_32 (0x64)
#define V3_32 (0x68)
#define V4_32 (0x6C)

#define VIF1_SET_MSCAL(vuaddr, irq) ((u_int)(vuaddr) | ((u_int)0x14 << 24) | ((u_int)(irq) << 31))
#define VIF1_SET_MSCNT(irq) (((u_int)0x17 << 24) | ((u_int)(irq) << 31))
#define VIF1_SET_MSCALF(vuaddr, irq) ((u_int)(vuaddr) | ((u_int)0x15 << 24) | ((u_int)(irq) << 31))

#define VIF1_SET_STCYCL(wl, cl, irq) ((u_int)(cl) | ((u_int)(wl) << 8)  | ((u_int)0x01 << 24) | ((u_int)(irq) << 31))
#define VIF1_SET_UNPACK(vuaddr, num, cmd, irq) ((u_int)(vuaddr) | ((u_int)(num) << 16) | ((u_int)(0x60 | (cmd)) << 24) | ((u_int)(irq) << 31))



#ifndef M_PI
#define M_PI (3.1415926)
#endif

#define T_MODE_CLKS_M (0x03<< 0)
#define T_MODE_GATE_M (0x01<< 2)
#define T_MODE_GATS_M (0x01<< 3)
#define T_MODE_GATM_M (0x03<< 4)
#define T_MODE_ZRET_M (0x01<< 6)
#define T_MODE_CUE_M  (0x01<< 7)
#define T_MODE_CMPE_M (0x01<< 8)
#define T_MODE_OVFE_M (0x01<< 9)
#define T_MODE_EQUF_M (0x01<<10)
#define T_MODE_OVFF_M (0x01<<11)

#define T_MODE_CLKS_O ( 0)
#define T_MODE_GATE_O ( 2)
#define T_MODE_GATS_O ( 3)
#define T_MODE_GATM_O ( 4)
#define T_MODE_ZRET_O ( 6)
#define T_MODE_CUE_O  ( 7)
#define T_MODE_CMPE_O ( 8)
#define T_MODE_OVFE_O ( 9)
#define T_MODE_EQUF_O (10)
#define T_MODE_OVFF_O (11)



#if 0

#define GS_SET_PRIM(prim, iip, tme, fge, abe, aa1, fst, ctxt, fix) \
	((u_long64)(prim)      | ((u_long64)(iip) << 3)  | ((u_long64)(tme) << 4) | \
	 ((u_long64)(fge) << 5) | ((u_long64)(abe) << 6)  | ((u_long64)(aa1) << 7) | \
	 ((u_long64)(fst) << 8) | ((u_long64)(ctxt) << 9) | ((u_long64)(fix) << 10))


#define GS_SET_ALPHA(a, b, c, d, fix) \
	((u_long64)(a) | ((u_long64)(b) << 2) | ((u_long64)(c) << 4) | \
	 ((u_long64)(d) << 6) | ((u_long64)(fix) << 32))

#define GS_SET_CLAMP(wms, wmt, minu, maxu, minv, maxv) \
	((u_long64)(wms)         | ((u_long64)(wmt) << 2) | \
	 ((u_long64)(minu) << 4)  | ((u_long64)(maxu) << 14) | \
	 ((u_long64)(minv) << 24) | ((u_long64)(maxv) << 34))

#define GS_SET_TEX0(tbp, tbw, psm, tw, th, tcc, tfx, \
		cbp, cpsm, csm, csa, cld) \
		((u_long64)(tbp)         | ((u_long64)(tbw) << 14) | \
		 ((u_long64)(psm) << 20)  | ((u_long64)(tw) << 26) | \
		 ((u_long64)(th) << 30)   | ((u_long64)(tcc) << 34) | \
		 ((u_long64)(tfx) << 35)  | ((u_long64)(cbp) << 37) | \
		 ((u_long64)(cpsm) << 51) | ((u_long64)(csm) << 55) | \
		 ((u_long64)(csa) << 56)  | ((u_long64)(cld) << 61))


#define GS_SET_FBA(fba) ((u_long64)(fba))

#define GS_SET_PABE(pabe) ((u_long64)(pabe))

#define GS_ALPHA_1 (0x42)
#define GS_PABE    (0x49)
#define GS_FBA_1   (0x4A)
#define GS_CLAMP_1 (0x08)
#define GS_TEX0_1 (0x06)

#define GS_PSMCT32   (0)
#define GS_PSMCT24   (1)
#define GS_PSMCT16   (2)
#define GS_PSMCT16S  (10)

#define GS_PRIM_TRI      (3)
#define GS_PRIM_TRISTRIP (4)

#define GS_MODULATE 0

#define D1_CHCR         ((int *)(geniomem+((0x10009000-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D1_MADR         ((int *)(geniomem+((0x10009010-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D1_QWC          ((int *)(geniomem+((0x10009020-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D1_TADR         ((int *)(geniomem+((0x10009030-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D1_ASR0         ((int *)(geniomem+((0x10009040-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D1_ASR1         ((int *)(geniomem+((0x10009050-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))

#define D2_CHCR         ((int *)(geniomem+((0x1000a000-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D2_MADR         ((int *)(geniomem+((0x1000a010-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D2_QWC          ((int *)(geniomem+((0x1000a020-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D2_TADR         ((int *)(geniomem+((0x1000a030-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D2_ASR0         ((int *)(geniomem+((0x1000a040-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D2_ASR1         ((int *)(geniomem+((0x1000a050-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))

#define D_CTRL          ((int *)(geniomem+((0x1000e000-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_STAT          ((int *)(geniomem+((0x1000e010-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_PCR           ((int *)(geniomem+((0x1000e020-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_SQWC          ((int *)(geniomem+((0x1000e030-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_RBSR          ((int *)(geniomem+((0x1000e040-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_RBOR          ((int *)(geniomem+((0x1000e050-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_STADR         ((int *)(geniomem+((0x1000e060-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_ENABLER       ((int *)(geniomem+((0x1000f520-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))
#define D_ENABLEW       ((int *)(geniomem+((0x1000f590-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))

#define D_PCR_CPC1_M    (0x01<<1)
#define D_STAT_CIS1_M   (0x01<<1)

#define RESERVE_MEMORY_START (0x1000000)
#define PORT_OFFSET 0x0000000

#define GS_BGCOLOR ((int *)(geniomem+((0x120000E0-PS2_DEV_GENIO_OFFSET)-PORT_OFFSET)))

#endif

#endif

