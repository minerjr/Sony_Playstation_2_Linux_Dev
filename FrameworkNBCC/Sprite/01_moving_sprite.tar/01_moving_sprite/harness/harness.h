
#ifndef __HIK_HARNESS_H__
#define __HIK_HARNESS_H__

#include <sys/types.h>
#include "defines.h"

#define VU0_Reset() asm __volatile__ ( " .set noat ;cfc2. $1,$28; ctc2. %0,$28 ; sync.p ; or $1,$1,12 ; ctc2. $1,$28 ; sync.p ;.set at " : : "r"( 2 ) ); 
static inline void VU1_Reset()
{
	register u_int reg;
	asm __volatile__ ( "cfc2 %0, $vi28" : "=r"(reg):);
	reg |= 0x200;
	asm __volatile__ ( "ctc2 %0, $vi28" : : "r"(reg));
}

static inline void VU1_Start(u_int addr)
{
	register u_int reg;
	reg = addr;
	asm __volatile__ ( "ctc2 %0, $vi31" : : "r"(reg));
}

static inline int VU1_Sync()
{
	int status=0;
	register u_int reg;
	asm __volatile__ ( "cfc2 %0, $vi29" : "=r"(reg):);
	if (reg&0x200) status=1;
	else if (reg&0x400) status=2;
	else if (reg&0x800) status=3;
	else if (reg&0x100) status=4;
	return status;
}

typedef struct {
	char *name;
	char *bin;
	char *dat;
} vucode_t;

typedef union
{
	u_long128     ul128;
	u_long        ul64[2];
	u_int         ui32[4];
	float         f32[4];
} qword_t;


extern struct ps2_screeninfo screeninfo[];
extern ps2_gsreg_smode2 pgs;
extern ps2_gssreg_display display1[];
extern int gs_fd, vu0_fd, vu1_fd, spr_fd, event_fd;

void har_init();
void har_deinit();
void har_quit_now(int sig);
void har_load_vu1_mpg(vucode_t *code);
void har_setup_gs(int frame);
void har_wait_vsync();
void har_clear_screen(int frame);
void (*har_set_quit_callback(void (*handler)(int)))(int);

#endif
