

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <malloc.h>
#include <fcntl.h>
#include <linux/ps2/dev.h>

#include "harness.h"

#define _DPRINTF 1
#define DPRINTF if (_DPRINTF) printf

__u64 *clearscreen[2];
int clearscreen_size;
time_t TT;
int gs_fd, vu0_fd, vu1_fd, spr_fd, event_fd;
char *vu0mem, *vu1mem, *sprmem;
struct ps2_screeninfo old_screeninfo;
void (*har_quit_callback)(int)=NULL;

struct ps2_screeninfo screeninfo[] = {
	{ PS2_GS_VESA, PS2_GS_640x480, 640, 480, 0, 0 },
	{ PS2_GS_DTV, PS2_GS_480P, 640, 448, 0, 0 },
	{ PS2_GS_NTSC, PS2_GS_INTERLACE, 640, 448, 0, 0 },
	{ PS2_GS_PAL, PS2_GS_INTERLACE, 640, 448, 0, 0 },
};

ps2_gsreg_smode2 pgs = { 0, 0, 0, 0 };

ps2_gssreg_display display1[] = {
	{ 365, 30, 1, 1, 0, 1279, 447, 0 },
	{ 632, 50, 3, 0, 0, 0, 0, 0 },
	{ 632, 50, 3, 0, 0, 2559, 479, 0 },
	{ 652, 72, 3, 0, 0, 2559, 575, 0 }
};

void har_build_clear_packet(int frame);

void har_init()
{
	void (*sig_handle)(int)=SIG_ERR;
	int err;

	time( &TT );
	DPRINTF("\nstart: %s", asctime(localtime(&TT)));

	DPRINTF("opening %s: ", PS2_DEV_VPU0); fflush(stdout);
	vu0_fd = open( PS2_DEV_VPU0,O_RDWR );				
	DPRINTF("%s\n", strerror(errno));
	if ( vu0_fd == -1 ) exit(-1);

	DPRINTF("opening %s: ", PS2_DEV_VPU1); fflush(stdout);
	vu1_fd = open( PS2_DEV_VPU1,O_RDWR );
	DPRINTF("%s\n", strerror(errno));
	if ( vu1_fd == -1 ) exit(-1);

	DPRINTF("opening %s: ", PS2_DEV_SPR); fflush(stdout);
	spr_fd = open( PS2_DEV_SPR, O_RDWR );
	DPRINTF("%s\n", strerror(errno));
	if ( spr_fd == -1 ) exit(-1);

	DPRINTF("opening %s: ", PS2_DEV_GS); fflush(stdout);
	gs_fd = open( PS2_DEV_GS, O_RDWR );
	DPRINTF("%s\n", strerror(errno));
	if ( gs_fd == -1 ) exit(-1);

	DPRINTF("opening %s: ", PS2_DEV_EVENT); fflush(stdout);
	event_fd = open( PS2_DEV_EVENT, O_RDWR );
	DPRINTF("%s\n", strerror(errno));
	if ( event_fd == -1 ) exit(-1);

	DPRINTF("mmapping vu0mem: "); fflush(stdout);
	vu0mem = (char*) mmap( 0, 8192, PROT_READ|PROT_WRITE, MAP_SHARED, vu0_fd, 0 );
	DPRINTF("%s\n", strerror(errno));
	if ( vu0mem == (void*)-1 ) exit(-1);

	DPRINTF("mmapping vu1mem: "); fflush(stdout);
	vu1mem = (char*) mmap( 0, 32768, PROT_READ|PROT_WRITE, MAP_SHARED, vu1_fd, 0 );
	DPRINTF("%s\n", strerror(errno));
	if ( vu1mem == (void*)-1 ) exit(-1);

	DPRINTF("mmapping spr: "); fflush(stdout);
	sprmem = (char*) mmap( (void*)0x70000000, 16384, PROT_READ|PROT_WRITE, MAP_SHARED, spr_fd, 0 );
	DPRINTF("%s\n", strerror(errno));
	if ( sprmem == (void*)-1 ) exit(-1);

	DPRINTF("saving current screen info: "); fflush(stdout);
	err=ioctl( gs_fd, PS2IOC_GSCREENINFO, &old_screeninfo);
	DPRINTF("%s\n", strerror(errno));
	if (err==-1) exit(-1);

	DPRINTF("resetting GS: "); fflush(stdout);
	err=ioctl( gs_fd, PS2IOC_GSRESET, PS2_GSRESET_FULL);
	DPRINTF("%s\n", strerror(errno));
	if (err==-1) exit(-1);

	DPRINTF("setting new screen info (%dx%d): ", screeninfo[old_screeninfo.mode].w, screeninfo[old_screeninfo.mode].h); fflush(stdout);
	err=ioctl( gs_fd, PS2IOC_SSCREENINFO, &screeninfo[old_screeninfo.mode]);
	DPRINTF("%s\n", strerror(errno));
	if (err==-1) exit(-1);

	DPRINTF("setting ps2 event: "); fflush(stdout);
	err=ioctl( event_fd, PS2IOC_ENABLEEVENT, PS2EV_VBSTART );
	DPRINTF("%s\n", strerror(errno));
	if (err==-1) exit(-1);

	har_setup_gs(0&1);

	DPRINTF("Trapping SIGINT: ");
	sig_handle=signal(SIGINT, har_quit_now );
	if (sig_handle==SIG_ERR) { DPRINTF("Could not trap signal\n"); exit(-1); }
	DPRINTF("Ok\n");

	DPRINTF("allocation memory for packets: "); fflush(stdout);
	clearscreen[0]=(__u64*)memalign(64,64*16);
	DPRINTF("%s - ", strerror(errno)); fflush(stdout);
	clearscreen[1]=(__u64*)memalign(64,64*16);
	DPRINTF("%s\n", strerror(errno));
	if ( clearscreen[0] == NULL ) exit(-1);

	DPRINTF("building clearscreen packet: "); fflush(stdout);
	har_build_clear_packet(0);
	har_build_clear_packet(1);
	DPRINTF("%d bytes\n", clearscreen_size*8);

	DPRINTF("\n");
}

void har_deinit()
{
	DPRINTF("\n");

	DPRINTF("setting back screen info: "); fflush(stdout);
	ioctl( gs_fd, PS2IOC_SSCREENINFO,&old_screeninfo );
	DPRINTF("%s\n", strerror(errno));

	DPRINTF("munmapping sprmem: " ); fflush(stdout);
	munmap( sprmem, 16384 );
	DPRINTF("%s\n", strerror( errno ) );

	DPRINTF("munmapping vu1mem: " ); fflush(stdout);
	munmap( vu1mem, 32768 );
	DPRINTF("%s\n", strerror( errno ) );

	DPRINTF("munmapping vu0mem: "); fflush(stdout);
	munmap( vu0mem, 8192 );
	DPRINTF("%s\n", strerror(errno));

	DPRINTF("closing event device: "); fflush(stdout);
	close( event_fd );
	DPRINTF("%s\n", strerror(errno) );

	DPRINTF("closing gs device: "); fflush(stdout);
	close( gs_fd );
	DPRINTF("%s\n", strerror(errno) );

	DPRINTF("closing spr device: "); fflush(stdout);
	close( spr_fd );
	DPRINTF("%s\n", strerror(errno));

	DPRINTF("closing vu1 device: "); fflush(stdout);
	close( vu1_fd );
	DPRINTF("%s\n", strerror(errno));

	DPRINTF("closing vu0 device: "); fflush(stdout);
	close( vu0_fd );
	DPRINTF("%s\n", strerror(errno) );

	time( &TT );
	DPRINTF( "end:   %s", asctime(localtime(&TT)) );
}

void (*har_set_quit_callback(void (*handler)(int)))(int)
{
	void (*old_callback)(int)=har_quit_callback;
	har_quit_callback=handler;
	return old_callback;
}

void har_quit_now(int sig)
{
	signal(SIGINT, SIG_DFL );
	DPRINTF("got signal %d, quitting...\n", sig);
	if (har_quit_callback!=NULL) har_quit_callback(sig);
	har_deinit();
	exit(sig);
}

void har_load_vu1_mpg(vucode_t *vucode)
{
	int vbin_fd, vbin_size;

	memset(vu1mem, 0, 2048*16);

	if ( vucode->bin != NULL )
	{
		DPRINTF("opening %s: ", vucode->bin); fflush(stdout);
		vbin_fd = open( vucode->bin, O_RDONLY );
		DPRINTF("%s\n", strerror(errno));
		if ( vbin_fd == -1 ) exit(-1);

		DPRINTF("reading vu1 mpg: "); fflush(stdout);
		vbin_size = read( vbin_fd, vu1mem, 16384 );
		DPRINTF("%d bytes read (%d lines)\n", vbin_size, vbin_size/8);

		DPRINTF("closing %s: ", vucode->bin); fflush(stdout);
		close( vbin_fd );
		DPRINTF("%s\n", strerror(errno));
	}

	if ( vucode->dat != NULL )
	{
		DPRINTF("opening %s: ", vucode->dat); fflush(stdout);
		vbin_fd = open( vucode->dat, O_RDONLY );
		DPRINTF("%s\n", strerror(errno));
		if ( vbin_fd == -1 ) exit(-1);

		DPRINTF("reading vu1 data: "); fflush(stdout);
		vbin_size = read( vbin_fd, vu1mem+16384, 16384 );
		DPRINTF("%d bytes read (%d qwords)\n", vbin_size, vbin_size/16);

		DPRINTF("closing %s: ", vucode->dat); fflush(stdout);
		close( vbin_fd );
		DPRINTF("%s\n\n", strerror(errno));
	}
}

void har_wait_vsync()
{
	if (-1==ioctl( event_fd, PS2IOC_WAITEVENT, PS2EV_VBSTART ))
	{
		DPRINTF("ioctl in wait vsync: %s\n", strerror(errno));
		har_deinit();
		exit(-1);
	}
}

void har_clear_screen(int frame)
{
	if (-1==write( gs_fd, clearscreen[frame&1], clearscreen_size*8 ))
	{
		DPRINTF("write in clear screen: %s\n", strerror(errno));
		har_deinit();
		exit(-1);
	}
}

void har_setup_gs(int frame)
{
	int width=screeninfo[old_screeninfo.mode].w;
	//int height=screeninfo[old_screeninfo.mode].h;
	int err;
	int fbp=(!(frame&1))*0x46;
	ps2_gssreg_dispfb pgdf = { fbp, width/64, PS2_GS_PSMCT32, 0, 0 };
	ps2_gssreg_display *pgd = &display1[old_screeninfo.mode];
	struct ps2_gssreg pg;

	pg.val=*(__u64*)&pgs;
	pg.reg=PS2_GSSREG_SMODE2;
	err=ioctl( gs_fd, PS2IOC_SGSSREG,&pg );
	if (err==-1) { DPRINTF("setting new smode2: %s\n", strerror(errno)); exit(-1); }

	pg.val=*(__u64*)&pgdf;
	pg.reg=PS2_GSSREG_DISPFB1;
	err=ioctl( gs_fd, PS2IOC_SGSSREG,&pg );
	if (err==-1) { DPRINTF("setting new dispfb1: %s\n", strerror(errno)); exit(-1); }

//	pgd->DW=width*1-1;
//	pgd->DH=height-1;

	pg.val=*(__u64*)pgd;
	pg.reg=PS2_GSSREG_DISPLAY1;
	err=ioctl( gs_fd, PS2IOC_SGSSREG,&pg );
	if (err==-1) { DPRINTF("setting new display1: %s\n", strerror(errno)); exit(-1); }
}

void har_build_clear_packet(int frame)
{
	int width=screeninfo[old_screeninfo.mode].w;
	int height=screeninfo[old_screeninfo.mode].h/2;
	int fbp=(frame&1)*0x46;

	frame&=1;
	clearscreen_size=0;

	*(clearscreen[frame]+clearscreen_size++)= 0; // to be filled at the end

	*(clearscreen[frame]+clearscreen_size++)= PS2_GIFTAG_REGS_AD;

	/*
		Initialise drawing registers, this should only be done once, but it's safer to do every frame just in case....
	*/

	*(clearscreen[frame]+clearscreen_size++)= 1;
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_PRMODECONT;

	*(clearscreen[frame]+clearscreen_size++)= 1;
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_COLCLAMP;

	*(clearscreen[frame]+clearscreen_size++)= 0;
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_DTHE;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_XYOFFSET( 32768-(width*8),32768-(height*8) );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_XYOFFSET_1;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_SCISSOR( 0,width,0,height );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_SCISSOR_1;

	/*
		Now clear draw buffer using untextured sprite
	*/

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_TEST(	PS2_GS_TEST_ATE_OFF,
				PS2_GS_TEST_ATST_ALWAYS,
				0,
				PS2_GS_TEST_AFAIL_KEEP,
				PS2_GS_TEST_DATE_OFF,
				PS2_GS_TEST_DATM_PASS1,
				PS2_GS_TEST_ZTE_ON,
				PS2_GS_TEST_ZTST_ALWAYS );
	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_TEST_1;
			
	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_FRAME( fbp,(width/64),PS2_GS_PSMCT32,0 );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_FRAME_1;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_ZBUF( 0x46*2,PS2_GS_PSMZ32,0 );
	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_ZBUF_1;
 
	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_RGBAQ( 0x00,0x50,0x50,0x0,0x0 );
	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_RGBAQ;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_PRIM( 	PS2_GS_PRIM_PRIM_SPRITE,
				PS2_GS_PRIM_IIP_FLAT ,
				PS2_GS_PRIM_TME_OFF,
				PS2_GS_PRIM_FGE_OFF,
				PS2_GS_PRIM_ABE_OFF,
				PS2_GS_PRIM_AA1_OFF,
				PS2_GS_PRIM_FST_UV,
				PS2_GS_PRIM_CTXT_CONTEXT1,
				PS2_GS_PRIM_FIX_NOFIXDDA );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_PRIM;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_XYZ2( 32768-(width*8),32768-(height*8),0 );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_XYZ2;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_XYZ2( 32768+(width*8),32768+(height*8),0 );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_XYZ2;

	/*
		Set test mode for Normal polygons
	*/

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_TEST(	PS2_GS_TEST_ATE_OFF,
				PS2_GS_TEST_ATST_ALWAYS,
				0,
				PS2_GS_TEST_AFAIL_KEEP,
				PS2_GS_TEST_DATE_OFF,
				PS2_GS_TEST_DATM_PASS1,
				PS2_GS_TEST_ZTE_ON,
				PS2_GS_TEST_ZTST_GREATER );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_TEST_1;

	*(clearscreen[frame]+clearscreen_size++)=
		PS2_GS_SETREG_ALPHA(	0, 1, 0, 1, 0x80 );
	*(clearscreen[frame]+clearscreen_size++)= PS2_GS_ALPHA_1;

	*(clearscreen[frame])=
		PS2_GIFTAG_SET_TOPHALF( (clearscreen_size*8/16) -1,
				1,1,
				PS2_GS_SETREG_PRIM(	PS2_GS_PRIM_PRIM_SPRITE,
							PS2_GS_PRIM_IIP_FLAT ,
							PS2_GS_PRIM_TME_ON,
							PS2_GS_PRIM_FGE_OFF,
							PS2_GS_PRIM_ABE_OFF,
							PS2_GS_PRIM_AA1_OFF,
							PS2_GS_PRIM_FST_UV,
							PS2_GS_PRIM_CTXT_CONTEXT1,
							PS2_GS_PRIM_FIX_NOFIXDDA ),
				PS2_GIFTAG_FLG_PACKED,1 );
}

