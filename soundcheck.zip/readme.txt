
Sound Check
by Vzzrzzn


How to run:

1. Make the fileserving root directory of your link program (Naplink, Proview)
   to the directory containing the demo files.
2. Put a copy of "libsd.irx" (with that exact name) in the directory
   containing the demo files.  You can find this file (copyright Sony) on
   most game discs, or in your PS2 BIOS if you don't own an SCPH-10000/15000.
3. Simply run the file "soundchk.elf", and use the menu to choose between
   No Sound, Proview, Naplink, or CDROM (I think it'll work if you burn this
   onto a CD-R).



Some History:

I decided I needed to write a fully-featured modplayer back in February, so I
spent around two weeks writing it in Windows.  It took an extra week to make
an IRX module that ran the entire modplayer (software mixed), and this was
done by early March.  But, I wanted to release a spiffy graphical demo along
with it.  This, unfortunately, was delayed until now (MONTHS later, argh);
I just cannot seem to find the time to dedicate to PS2 projects at the moment.

Anyways, hope you enjoy.




Credits:

Gustavo Scotti wrote the ps2lib which I used for EE<->IOP communication.
Pukko wrote the pad library and _sifLoadModule.


Greets (in no particular order):

Duke, AndrewK / Napalm.
Druckluft & Gibson / Soopadoopa
Nagra
Jules
Sjeep
adresd
Oobles
Price
Extimes
Chewie_
Ravi
Hanto

